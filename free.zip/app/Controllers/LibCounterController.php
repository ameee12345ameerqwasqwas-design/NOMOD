<?php

namespace App\Controllers;

use App\Models\LibCounterModel;

class LibCounterController extends BaseController
{
    protected LibCounterModel $model;

    public function __construct()
    {
        $this->model = new LibCounterModel();
    }

    public function index()
    {
        $counters = $this->model->orderBy('id', 'DESC')->findAll();
        $stats    = $this->model->getStats();

        return view('LibCounter/index', [
            'title'    => 'Library Counters',
            'counters' => $counters,
            'stats'    => $stats,
        ]);
    }

    public function create()
    {
        if (!$this->request->isAJAX() && !$this->request->getPost()) {
            return redirect()->to(site_url('lib-counter'));
        }

        $rules = [
            'lib_name'     => 'required|min_length[2]|max_length[100]',
            'package_name' => 'required|min_length[3]|max_length[255]',
            'max_uses'     => 'required|is_natural',
            'note'         => 'permit_empty|max_length[500]',
        ];

        if (!$this->validate($rules)) {
            if ($this->request->isAJAX()) {
                return $this->response->setJSON(['success' => false, 'message' => implode(' ', $this->validator->getErrors())]);
            }
            return redirect()->back()->withInput()->with('error', implode(' ', $this->validator->getErrors()));
        }

        $unique_code = $this->request->getPost('unique_code') ?: $this->model->generateUniqueCode();

        if ($this->model->where('package_name', $this->request->getPost('package_name'))->countAllResults() > 0) {
            if ($this->request->isAJAX()) {
                return $this->response->setJSON(['success' => false, 'message' => 'Package name already exists!']);
            }
            return redirect()->back()->withInput()->with('error', 'Package name already registered!');
        }

        $this->model->insert([
            'lib_name'     => $this->request->getPost('lib_name'),
            'package_name' => $this->request->getPost('package_name'),
            'unique_code'  => $unique_code,
            'status'       => 1,
            'max_uses'     => (int) $this->request->getPost('max_uses'),
            'current_uses' => 0,
            'note'         => $this->request->getPost('note') ?? '',
        ]);

        if ($this->request->isAJAX()) {
            return $this->response->setJSON(['success' => true, 'message' => 'Counter created successfully!', 'code' => $unique_code]);
        }

        return redirect()->to(site_url('lib-counter'))->with('success', 'Library counter created!');
    }

    public function generateCode()
    {
        return $this->response->setJSON([
            'success' => true,
            'code'    => $this->model->generateUniqueCode(),
        ]);
    }

    public function toggle($id = null)
    {
        $row = $this->model->find($id);
        if (!$row) {
            return $this->response->setJSON(['success' => false, 'message' => 'Not found']);
        }

        $newStatus = $row['status'] == 1 ? 0 : 1;
        $this->model->update($id, ['status' => $newStatus]);

        return $this->response->setJSON([
            'success' => true,
            'status'  => $newStatus,
            'message' => $newStatus ? 'Activated' : 'Deactivated',
        ]);
    }

    public function resetUses($id = null)
    {
        $row = $this->model->find($id);
        if (!$row) {
            return $this->response->setJSON(['success' => false, 'message' => 'Not found']);
        }

        $this->model->update($id, ['current_uses' => 0]);

        return $this->response->setJSON(['success' => true, 'message' => 'Uses reset to 0']);
    }

    public function delete($id = null)
    {
        $row = $this->model->find($id);
        if (!$row) {
            return $this->response->setJSON(['success' => false, 'message' => 'Not found']);
        }

        $this->model->delete($id);

        return $this->response->setJSON(['success' => true, 'message' => 'Deleted successfully']);
    }

    public function verify()
    {
        $packageName = $this->request->getPost('package_name');
        $code        = $this->request->getPost('unique_code');

        if (!$packageName || !$code) {
            return $this->response->setJSON(['valid' => false, 'reason' => 'Missing parameters']);
        }

        $result = $this->model->verifyLib($packageName, $code);

        return $this->response->setJSON($result);
    }
}
