<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>

<style>
    body {
        background-image: url('<?= base_url('assets/images/backround1.avif') ?>');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        background-color: #24193d;
        font-family: 'Poppins', sans-serif;
    }

    .lib-container { padding: 20px; }

    .stat-card {
        background: rgba(93, 63, 159, 0.55);
        backdrop-filter: blur(12px);
        border: 1px solid rgba(255,255,255,0.15);
        border-radius: 18px;
        padding: 22px 24px;
        color: white;
        transition: all 0.3s ease;
        text-align: center;
        margin-bottom: 20px;
    }
    .stat-card:hover { transform: translateY(-5px); box-shadow: 0 12px 35px rgba(0,0,0,0.35); }
    .stat-number { font-size: 2.2rem; font-weight: 700; color: #a78bfa; }
    .stat-label  { font-size: 0.85rem; opacity: 0.75; margin-top: 4px; }

    .main-card {
        background: rgba(93, 63, 159, 0.65);
        backdrop-filter: blur(12px);
        border: 1px solid rgba(255,255,255,0.15);
        border-radius: 18px;
        overflow: hidden;
        margin-bottom: 30px;
        box-shadow: 0 8px 32px rgba(0,0,0,0.3);
    }
    .main-card .card-header {
        background: linear-gradient(135deg, rgba(93,63,159,0.7), rgba(80,50,140,0.9));
        border-bottom: 1px solid rgba(255,255,255,0.12);
        color: white;
        font-weight: 600;
        padding: 18px 24px;
        font-size: 1.15rem;
    }
    .main-card .card-body { padding: 24px; color: white; }

    .form-control, .form-select {
        background: rgba(255,255,255,0.08);
        border: 1px solid rgba(255,255,255,0.2);
        color: white;
        border-radius: 12px;
        padding: 11px 16px;
    }
    .form-control:focus, .form-select:focus {
        background: rgba(255,255,255,0.13);
        border-color: #a78bfa;
        box-shadow: 0 0 0 0.2rem rgba(167,139,250,0.3);
        color: white;
    }
    .form-control::placeholder { color: rgba(255,255,255,0.4); }
    .form-label { color: rgba(255,255,255,0.85); font-size: 0.9rem; margin-bottom: 6px; }

    .btn-generate {
        background: linear-gradient(135deg,#7e5bef,#a78bfa);
        border: none; color: white; font-weight: 600;
        border-radius: 12px; padding: 12px 22px;
        transition: all 0.3s ease;
    }
    .btn-generate:hover { background: linear-gradient(135deg,#6a4cc7,#8e6ee0); transform: translateY(-2px); color: white; }

    .btn-submit {
        background: linear-gradient(135deg,#0dcaf0,#0a9bb7);
        border: none; color: white; font-weight: 600;
        border-radius: 12px; padding: 12px 28px;
        transition: all 0.3s ease; width: 100%;
    }
    .btn-submit:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(13,202,240,0.35); color: white; }

    .counter-table { width: 100%; border-collapse: separate; border-spacing: 0 10px; }
    .counter-table thead th {
        color: rgba(255,255,255,0.6); font-size: 0.8rem;
        text-transform: uppercase; letter-spacing: 1px;
        padding: 0 14px 6px; border: none; font-weight: 600;
    }
    .counter-row td {
        background: rgba(255,255,255,0.06);
        padding: 14px;
        border: none;
        color: white;
        font-size: 0.92rem;
        vertical-align: middle;
    }
    .counter-row td:first-child { border-radius: 12px 0 0 12px; padding-left: 18px; }
    .counter-row td:last-child  { border-radius: 0 12px 12px 0; padding-right: 18px; }
    .counter-row:hover td { background: rgba(255,255,255,0.1); }

    .code-badge {
        font-family: 'Courier New', monospace;
        background: rgba(167,139,250,0.18);
        color: #d0bcff;
        border: 1px solid rgba(167,139,250,0.3);
        border-radius: 8px;
        padding: 4px 10px;
        font-size: 0.8rem;
        cursor: pointer;
        transition: all 0.2s;
        display: inline-flex;
        align-items: center;
        gap: 6px;
    }
    .code-badge:hover { background: rgba(167,139,250,0.3); }

    .pkg-badge {
        background: rgba(13,202,240,0.12);
        color: #67e8f9;
        border: 1px solid rgba(13,202,240,0.25);
        border-radius: 8px;
        padding: 3px 10px;
        font-size: 0.78rem;
        font-family: monospace;
        word-break: break-all;
    }

    .status-badge {
        display: inline-block;
        padding: 4px 14px;
        border-radius: 50px;
        font-size: 0.78rem;
        font-weight: 600;
    }
    .status-active   { background: rgba(16,185,129,0.18); color: #34d399; border: 1px solid rgba(16,185,129,0.3); }
    .status-inactive { background: rgba(239,68,68,0.18);  color: #f87171; border: 1px solid rgba(239,68,68,0.3); }

    .uses-bar {
        height: 6px;
        background: rgba(255,255,255,0.1);
        border-radius: 10px;
        overflow: hidden;
        margin-top: 4px;
    }
    .uses-fill {
        height: 100%;
        background: linear-gradient(90deg,#7e5bef,#0dcaf0);
        border-radius: 10px;
        transition: width 0.6s ease;
    }

    .btn-icon {
        width: 34px; height: 34px;
        border-radius: 10px;
        border: 1px solid rgba(255,255,255,0.15);
        background: rgba(255,255,255,0.06);
        color: white;
        display: inline-flex; align-items: center; justify-content: center;
        cursor: pointer;
        transition: all 0.2s ease;
        font-size: 0.85rem;
    }
    .btn-icon:hover { background: rgba(255,255,255,0.15); transform: scale(1.1); }
    .btn-icon.danger:hover  { background: rgba(220,53,69,0.3); border-color: rgba(220,53,69,0.5); }
    .btn-icon.success:hover { background: rgba(16,185,129,0.3); border-color: rgba(16,185,129,0.5); }
    .btn-icon.warning:hover { background: rgba(245,158,11,0.3); border-color: rgba(245,158,11,0.5); }

    .search-input {
        background: rgba(255,255,255,0.08);
        border: 1px solid rgba(255,255,255,0.18);
        color: white;
        border-radius: 12px;
        padding: 10px 16px;
        width: 240px;
        font-size: 0.9rem;
    }
    .search-input:focus { outline: none; border-color: #a78bfa; background: rgba(255,255,255,0.12); color: white; }
    .search-input::placeholder { color: rgba(255,255,255,0.35); }

    .toast-container {
        position: fixed; top: 20px; right: 20px;
        z-index: 9999; display: flex; flex-direction: column; gap: 10px;
    }
    .toast-alert {
        min-width: 280px;
        background: rgba(36,25,61,0.97);
        backdrop-filter: blur(10px);
        border-left: 4px solid #a78bfa;
        border-radius: 12px;
        padding: 14px 18px;
        color: white;
        box-shadow: 0 10px 30px rgba(0,0,0,0.4);
        animation: slideIn 0.35s ease-out forwards;
        font-size: 0.92rem;
    }
    .toast-alert.danger  { border-left-color: #f87171; }
    .toast-alert.success { border-left-color: #34d399; }
    @keyframes slideIn { from { transform: translateX(110%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }

    .empty-state { text-align: center; padding: 60px 20px; color: rgba(255,255,255,0.5); }
    .empty-state i { font-size: 52px; color: rgba(255,255,255,0.2); margin-bottom: 16px; display: block; }

    .animate-in { animation: fadeUp 0.55s ease-out forwards; opacity: 0; }
    @keyframes fadeUp { from { opacity: 0; transform: translateY(25px); } to { opacity: 1; transform: translateY(0); } }

    @media (max-width: 768px) {
        .search-input { width: 100%; }
        .counter-table thead { display: none; }
        .counter-row td { display: block; padding: 8px 14px; }
        .counter-row td:first-child { border-radius: 12px 12px 0 0; }
        .counter-row td:last-child  { border-radius: 0 0 12px 12px; }
    }
</style>

<div class="toast-container" id="toastContainer"></div>

<div class="lib-container">
    <div class="row justify-content-center mt-2">
        <div class="col-12"><?= $this->include('Layout/msgStatus') ?></div>
    </div>

    <!-- Stats Row -->
    <div class="row g-3 mb-4 animate-in" style="animation-delay:0.05s">
        <div class="col-6 col-md-3">
            <div class="stat-card">
                <div class="stat-number"><?= $stats['total'] ?></div>
                <div class="stat-label"><i class="fas fa-layer-group me-1"></i>Total</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="stat-card">
                <div class="stat-number" style="color:#34d399"><?= $stats['active'] ?></div>
                <div class="stat-label"><i class="fas fa-check-circle me-1"></i>Active</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="stat-card">
                <div class="stat-number" style="color:#f87171"><?= $stats['inactive'] ?></div>
                <div class="stat-label"><i class="fas fa-times-circle me-1"></i>Inactive</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="stat-card">
                <div class="stat-number" style="color:#0dcaf0"><?= $stats['total_uses'] ?></div>
                <div class="stat-label"><i class="fas fa-chart-bar me-1"></i>Total Uses</div>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <!-- Create Form -->
        <div class="col-lg-4 col-12">
            <div class="main-card animate-in" style="animation-delay:0.1s">
                <div class="card-header">
                    <i class="fas fa-plus-circle me-2"></i> New Library Counter
                </div>
                <div class="card-body">
                    <form id="createForm">
                        <?= csrf_field() ?>

                        <div class="mb-3">
                            <label class="form-label">Library Name</label>
                            <input type="text" name="lib_name" id="lib_name"
                                   class="form-control" placeholder="e.g. MySDK" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Package Name</label>
                            <input type="text" name="package_name" id="package_name"
                                   class="form-control" placeholder="e.g. com.example.app" required>
                            <small class="text-muted" style="color:rgba(255,255,255,0.4)!important">
                                Exact Android package name of the app
                            </small>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Unique Code
                                <button type="button" onclick="generateCode()" class="btn btn-sm ms-2"
                                    style="background:rgba(167,139,250,0.2);color:#d0bcff;border:1px solid rgba(167,139,250,0.3);border-radius:8px;padding:2px 10px;font-size:0.78rem;">
                                    <i class="fas fa-sync-alt me-1"></i>Generate
                                </button>
                            </label>
                            <input type="text" name="unique_code" id="unique_code"
                                   class="form-control" placeholder="Auto-generated or custom"
                                   style="font-family:monospace">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Max Uses <small style="opacity:0.55">(0 = unlimited)</small></label>
                            <input type="number" name="max_uses" id="max_uses"
                                   class="form-control" value="0" min="0">
                        </div>

                        <div class="mb-4">
                            <label class="form-label">Note <small style="opacity:0.55">(optional)</small></label>
                            <textarea name="note" class="form-control" rows="2"
                                      placeholder="Client name or notes..."></textarea>
                        </div>

                        <button type="submit" class="btn-submit">
                            <i class="fas fa-plus me-2"></i>Create Counter
                        </button>
                    </form>
                </div>
            </div>

            <!-- API Verify Card -->
            <div class="main-card animate-in" style="animation-delay:0.15s">
                <div class="card-header">
                    <i class="fas fa-plug me-2"></i> API Endpoint
                </div>
                <div class="card-body">
                    <p style="color:rgba(255,255,255,0.7);font-size:0.88rem;margin-bottom:12px;">
                        Your library calls this endpoint to verify:
                    </p>
                    <div class="code-badge d-block mb-3" style="border-radius:10px;padding:10px 14px;width:100%;font-size:0.8rem;cursor:default;">
                        POST <span style="color:#67e8f9"><?= site_url('lib-counter/verify') ?></span>
                    </div>
                    <p style="color:rgba(255,255,255,0.6);font-size:0.82rem;margin-bottom:6px;">Required fields:</p>
                    <ul style="color:rgba(255,255,255,0.55);font-size:0.82rem;padding-left:16px;">
                        <li><code style="color:#d0bcff">package_name</code> — app package</li>
                        <li><code style="color:#d0bcff">unique_code</code> — counter code</li>
                    </ul>
                    <p style="color:rgba(255,255,255,0.6);font-size:0.82rem;margin-top:10px;">Returns JSON:</p>
                    <pre style="background:rgba(0,0,0,0.3);border-radius:10px;padding:12px;color:#a5f3fc;font-size:0.78rem;overflow-x:auto">{"valid": true, "lib_name": "...", "uses": 1}</pre>
                </div>
            </div>
        </div>

        <!-- Counters Table -->
        <div class="col-lg-8 col-12">
            <div class="main-card animate-in" style="animation-delay:0.12s">
                <div class="card-header d-flex justify-content-between align-items-center flex-wrap gap-3">
                    <span><i class="fas fa-database me-2"></i>Library Counters (<?= count($counters) ?>)</span>
                    <input type="text" id="searchInput" class="search-input" placeholder="Search...">
                </div>
                <div class="card-body">
                    <?php if (empty($counters)): ?>
                        <div class="empty-state">
                            <i class="fas fa-cube"></i>
                            <h5>No counters yet</h5>
                            <p>Create your first library counter using the form</p>
                        </div>
                    <?php else: ?>
                    <div class="table-responsive">
                        <table class="counter-table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Library</th>
                                    <th>Package</th>
                                    <th>Code</th>
                                    <th>Uses</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="countersBody">
                            <?php foreach ($counters as $i => $c): ?>
                                <?php
                                    $pct = ($c['max_uses'] > 0) ? min(100, round(($c['current_uses'] / $c['max_uses']) * 100)) : 0;
                                ?>
                                <tr class="counter-row" data-search="<?= esc(strtolower($c['lib_name'] . ' ' . $c['package_name'] . ' ' . $c['unique_code'])) ?>">
                                    <td style="color:rgba(255,255,255,0.4);font-size:0.8rem"><?= $c['id'] ?></td>
                                    <td>
                                        <span style="font-weight:600;color:#e2d9f3"><?= esc($c['lib_name']) ?></span>
                                        <?php if ($c['note']): ?>
                                            <br><small style="color:rgba(255,255,255,0.4);font-size:0.75rem"><?= esc($c['note']) ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td><span class="pkg-badge"><?= esc($c['package_name']) ?></span></td>
                                    <td>
                                        <span class="code-badge" onclick="copyText('<?= esc($c['unique_code']) ?>')" title="Click to copy">
                                            <i class="fas fa-copy" style="font-size:0.7rem"></i>
                                            <?= esc($c['unique_code']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span style="font-weight:600"><?= $c['current_uses'] ?></span>
                                        <span style="color:rgba(255,255,255,0.4);font-size:0.8rem">
                                            / <?= $c['max_uses'] == 0 ? '∞' : $c['max_uses'] ?>
                                        </span>
                                        <?php if ($c['max_uses'] > 0): ?>
                                        <div class="uses-bar"><div class="uses-fill" style="width:<?= $pct ?>%"></div></div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="status-badge <?= $c['status'] ? 'status-active' : 'status-inactive' ?>" id="status-<?= $c['id'] ?>">
                                            <?= $c['status'] ? 'Active' : 'Inactive' ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="d-flex gap-2">
                                            <button class="btn-icon success" onclick="toggleCounter(<?= $c['id'] ?>)" title="Toggle status">
                                                <i class="fas fa-power-off"></i>
                                            </button>
                                            <button class="btn-icon warning" onclick="resetUses(<?= $c['id'] ?>)" title="Reset uses">
                                                <i class="fas fa-undo"></i>
                                            </button>
                                            <button class="btn-icon danger" onclick="deleteCounter(<?= $c['id'] ?>)" title="Delete">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
const BASE = '<?= site_url("lib-counter") ?>';
const CSRF_NAME  = '<?= csrf_token() ?>';
const CSRF_HASH  = '<?= csrf_hash() ?>';

function toast(msg, type = 'success') {
    const c = document.getElementById('toastContainer');
    const t = document.createElement('div');
    t.className = 'toast-alert ' + type;
    t.innerHTML = `<strong>${type === 'danger' ? 'Error' : 'Done'}</strong><br>${msg}`;
    c.appendChild(t);
    setTimeout(() => { t.style.opacity = '0'; t.style.transform = 'translateX(110%)'; t.style.transition = '0.3s'; setTimeout(() => t.remove(), 300); }, 3500);
}

function copyText(text) {
    navigator.clipboard.writeText(text).then(() => toast('Code copied!')).catch(() => toast('Copy failed', 'danger'));
}

async function generateCode() {
    const btn = document.querySelector('[onclick="generateCode()"]');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Generating...';
    try {
        const res  = await fetch(BASE + '/generate-code');
        const data = await res.json();
        document.getElementById('unique_code').value = data.code;
        toast('New code generated!');
    } catch(e) {
        toast('Failed to generate code', 'danger');
    } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-sync-alt me-1"></i>Generate';
    }
}

document.getElementById('createForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const btn = this.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Creating...';

    const fd = new FormData(this);
    if (!fd.get('unique_code')) {
        const r = await fetch(BASE + '/generate-code');
        const d = await r.json();
        fd.set('unique_code', d.code);
    }

    try {
        const res  = await fetch(BASE + '/create', { method: 'POST', body: fd });
        const data = await res.json();
        if (data.success) {
            toast(data.message);
            setTimeout(() => location.reload(), 1200);
        } else {
            toast(data.message, 'danger');
        }
    } catch(e) {
        toast('Server error', 'danger');
    } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-plus me-2"></i>Create Counter';
    }
});

async function toggleCounter(id) {
    const fd = new FormData(); fd.append(CSRF_NAME, CSRF_HASH);
    try {
        const res  = await fetch(BASE + '/toggle/' + id, { method: 'POST', body: fd });
        const data = await res.json();
        if (data.success) {
            const badge = document.getElementById('status-' + id);
            badge.textContent = data.status ? 'Active' : 'Inactive';
            badge.className = 'status-badge ' + (data.status ? 'status-active' : 'status-inactive');
            toast(data.message);
        }
    } catch(e) { toast('Failed', 'danger'); }
}

async function resetUses(id) {
    if (!confirm('Reset uses to 0?')) return;
    const fd = new FormData(); fd.append(CSRF_NAME, CSRF_HASH);
    try {
        const res  = await fetch(BASE + '/reset/' + id, { method: 'POST', body: fd });
        const data = await res.json();
        if (data.success) { toast(data.message); setTimeout(() => location.reload(), 800); }
    } catch(e) { toast('Failed', 'danger'); }
}

async function deleteCounter(id) {
    if (!confirm('Delete this counter? This cannot be undone.')) return;
    const fd = new FormData(); fd.append(CSRF_NAME, CSRF_HASH);
    try {
        const res  = await fetch(BASE + '/delete/' + id, { method: 'POST', body: fd });
        const data = await res.json();
        if (data.success) {
            toast(data.message);
            setTimeout(() => location.reload(), 800);
        } else {
            toast(data.message, 'danger');
        }
    } catch(e) { toast('Failed', 'danger'); }
}

document.getElementById('searchInput')?.addEventListener('input', function() {
    const q = this.value.toLowerCase();
    document.querySelectorAll('.counter-row').forEach(row => {
        row.style.display = row.dataset.search.includes(q) ? '' : 'none';
    });
});

document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.animate-in').forEach((el, i) => {
        el.style.animationDelay = (0.05 + i * 0.07) + 's';
    });
    generateCode();
});
</script>

<?= $this->endSection() ?>
