<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<style>
    body {
        background-image: url('<?= base_url('assets/images/backround1.avif') ?>');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        background-color: #2d1b4e;
    }

    .card {
        background-color: rgba(80, 50, 140, 0.55) !important;
        backdrop-filter: blur(15px);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 18px;
        box-shadow: 0 10px 35px rgba(0, 0, 0, 0.4);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        overflow: hidden;
        margin-bottom: 25px;
    }

    .card:hover {
        transform: translateY(-8px);
        box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
    }

    .card-header {
        background-color: rgba(80, 50, 140, 0.6) !important;
        border-bottom: 1px solid rgba(255, 255, 255, 0.15);
        color: white !important;
        font-weight: 600;
        padding: 18px 25px;
        font-size: 1.1rem;
    }

    .card-body {
        padding: 30px;
        color: white;
    }

    .form-control, .form-select {
        background-color: rgba(255, 255, 255, 0.12);
        border: 1px solid rgba(255, 255, 255, 0.25);
        color: white;
        border-radius: 10px;
        padding: 10px 12px;
    }

    .form-control:focus, .form-select:focus {
        background-color: rgba(255, 255, 255, 0.18);
        border-color: rgba(167, 139, 250, 0.7);
        color: white;
        box-shadow: 0 0 0 0.25rem rgba(167, 139, 250, 0.3);
    }

    .form-control::placeholder {
        color: rgba(255, 255, 255, 0.7);
    }

    .form-select option {
        background-color: #5d3f9f;
        color: white;
    }

    .form-label {
        color: white;
        font-weight: 500;
        margin-bottom: 8px;
    }

    .btn-gradient {
        background: linear-gradient(135deg, #7e5bef, #a78bfa);
        border: none;
        color: white;
        font-weight: 600;
        border-radius: 10px;
        padding: 12px 20px;
        transition: all 0.3s ease;
    }

    .btn-gradient:hover {
        background: linear-gradient(135deg, #6a4cc7, #9470db);
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(126, 91, 239, 0.4);
        color: white;
    }

    .btn-back {
        background: transparent;
        border: 1px solid rgba(255, 255, 255, 0.4);
        color: white;
        border-radius: 8px;
        padding: 8px 16px;
        font-size: 0.9rem;
        transition: all 0.3s ease;
    }

    .btn-back:hover {
        background: rgba(255, 255, 255, 0.1);
        border-color: rgba(255, 255, 255, 0.6);
        color: white;
    }

    .text-danger {
        font-size: 0.875rem;
        margin-top: 5px;
    }

    .animate-in {
        animation: fadeIn 0.6s ease-out forwards;
        opacity: 0;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(25px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>

<div class="row justify-content-center pt-4">
    <div class="col-lg-9">
        <?= $this->include('Layout/msgStatus') ?>
    </div>

    <div class="col-lg-9 mb-5 animate-in" style="animation-delay: 0.1s">
        <div class="card">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <i class="bi bi-person-badge me-2"></i> Account Info &middot; <?= esc(getName($target)) ?>
                    </div>
                    <div>
                        <a class="btn btn-back" href="<?= site_url('admin/manage-users') ?>">
                            <i class="bi bi-arrow-left me-2"></i> Back
                        </a>
                    </div>
                </div>
            </div>

            <div class="card-body">
                <?= form_open() ?>
                <input type="hidden" name="user_id" value="<?= esc($target->id_users) ?>">

                <div class="row">
                    <div class="col-md-6 mb-4">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" name="username" id="username" class="form-control" 
                               placeholder="Enter username" 
                               value="<?= esc($username_value) ?>">
                        <?php if (!empty($errors['username'])) : ?>
                            <small class="text-danger"><?= esc($errors['username']) ?></small>
                        <?php endif; ?>
                    </div>

                    <div class="col-md-6 mb-4">
                        <label for="fullname" class="form-label">Fullname</label>
                        <input type="text" name="fullname" id="fullname" class="form-control" 
                               placeholder="Enter full name" 
                               value="<?= esc($fullname_value) ?>">
                        <?php if (!empty($errors['fullname'])) : ?>
                            <small class="text-danger"><?= esc($errors['fullname']) ?></small>
                        <?php endif; ?>
                    </div>

                    <div class="col-md-6 mb-4">
                        <label for="level" class="form-label">Roles</label>
                        <?= form_dropdown(['class' => 'form-select', 'name' => 'level', 'id' => 'level'], $sel_level, esc($level_value)) ?>
                    </div>

                    <div class="col-md-6 mb-4">
                        <label for="status" class="form-label">Status</label>
                        <?= form_dropdown(['class' => 'form-select', 'name' => 'status', 'id' => 'status'], $sel_status, esc($status_value)) ?>
                    </div>

                    <div class="col-md-6 mb-4">
                        <label for="saldo" class="form-label">Saldo</label>
                        <input type="number" name="saldo" id="saldo" class="form-control" 
                               placeholder="Enter saldo amount" 
                               value="<?= esc($saldo_value) ?>">
                        <?php if (!empty($errors['saldo'])) : ?>
                            <small class="text-danger"><?= esc($errors['saldo']) ?></small>
                        <?php endif; ?>
                    </div>

                    <div class="col-md-6 mb-4">
                        <label for="uplink" class="form-label">Uplink</label>
                        <input type="text" name="uplink" id="uplink" class="form-control" 
                               placeholder="Enter uplink" 
                               value="<?= esc($uplink_value) ?>">
                        <?php if (!empty($errors['uplink'])) : ?>
                            <small class="text-danger"><?= esc($errors['uplink']) ?></small>
                        <?php endif; ?>
                    </div>

                    <div class="col-md-6 mb-4">
                        <label for="expiration" class="form-label">Expiration Date</label>
                        <input type="text" name="expiration" id="expiration" class="form-control" 
                               placeholder="YYYY-MM-DD HH:MM:SS" 
                               value="<?= esc($expiration_value) ?>">
                        <?php if (!empty($errors['expiration'])) : ?>
                            <small class="text-danger"><?= esc($errors['expiration']) ?></small>
                        <?php endif; ?>
                    </div>

                    <div class="col-12 mt-4">
                        <button type="submit" class="btn-gradient">
                            <i class="bi bi-save me-2"></i> Update Account Information
                        </button>
                    </div>
                </div>

                <?= form_close() ?>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const animatedElements = document.querySelectorAll('.animate-in');
        animatedElements.forEach(element => {
            element.style.animationPlayState = 'running';
        });
    });
</script>
<?= $this->endSection() ?>