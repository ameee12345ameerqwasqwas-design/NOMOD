<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<style>
    body {
        background-image: url('<?= base_url('assets/images/backround1.avif') ?>');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        background-color: #24193d;
    }
    
    .users-container {
        padding: 15px;
    }
    
    .card {
        background-color: rgba(80, 50, 140, 0.55) !important;
        backdrop-filter: blur(15px);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 18px;
        box-shadow: 0 10px 35px rgba(0, 0, 0, 0.4);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        overflow: hidden;
        margin-bottom: 30px;
    }
    
    .card:hover {
        transform: translateY(-8px);
        box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
    }
    
    .card-header {
        background-color: rgba(80, 50, 140, 0.6) !important;
        border-bottom: 1px solid rgba(255, 255, 255, 0.15);
        color: white !important;
        font-weight: 600;
        padding: 20px 25px;
        font-size: 1.3rem;
        text-align: center;
    }
    
    .card-body {
        padding: 30px;
        color: white;
    }
    
    .alert-info-custom {
        background-color: rgba(80, 50, 140, 0.7);
        border: 1px solid rgba(167, 139, 250, 0.4);
        color: white;
        backdrop-filter: blur(10px);
        border-radius: 12px;
        padding: 15px 20px;
        margin-bottom: 25px;
        font-size: 1rem;
    }
    
    .table {
        color: #e0e0ff !important;
        margin-bottom: 0;
    }
    
    .table thead th {
        background-color: rgba(80, 50, 140, 0.7);
        border-color: rgba(255, 255, 255, 0.2) !important;
        font-weight: 600;
        padding: 15px;
        font-size: 1rem;
    }
    
    .table-bordered {
        border-color: rgba(255, 255, 255, 0.15) !important;
    }
    
    .table-hover tbody tr:hover {
        background-color: rgba(255, 255, 255, 0.15) !important;
    }
    
    .table td {
        padding: 14px;
        vertical-align: middle;
    }
    
    .badge {
        padding: 8px 14px;
        font-size: 0.9rem;
        border-radius: 8px;
    }
    
    .btn-edit {
        background: linear-gradient(135deg, #7e5bef, #a78bfa);
        border: none;
        color: white;
        padding: 10px 16px;
        border-radius: 8px;
        transition: all 0.3s ease;
        font-size: 0.95rem;
    }
    
    .btn-edit:hover {
        background: linear-gradient(135deg, #6a4cc7, #9470db);
        transform: translateY(-2px);
        box-shadow: 0 6px 15px rgba(126, 91, 239, 0.4);
        color: white;
    }
    
    .animate-in {
        animation: fadeIn 0.6s ease-out forwards;
        opacity: 0;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(25px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    @media (max-width: 992px) {
        .users-container {
            padding: 15px;
        }
    }
    
    @media (max-width: 768px) {
        .card-header {
            font-size: 1.2rem;
            padding: 18px 20px;
        }
        
        .card-body {
            padding: 25px;
        }
        
        .table-responsive {
            font-size: 0.9rem;
        }
        
        .btn-edit {
            padding: 8px 12px;
            font-size: 0.9rem;
        }
    }
    
    @media (max-width: 576px) {
        .users-container {
            padding: 10px;
        }
        
        .card-header {
            font-size: 1.1rem;
            padding: 16px 18px;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .table {
            font-size: 0.85rem;
        }
        
        .alert-info-custom {
            padding: 12px 16px;
            font-size: 0.95rem;
        }
    }
</style>

<div class="users-container">
    <div class="row justify-content-center mt-3">
        <div class="col-12 animate-in" style="animation-delay: 0.1s">
            <div class="alert-info-custom" role="alert">
                <strong>INFO :</strong> Search specify user by their (username, fullname, saldo or uplink).
            </div>

            <div class="card">
                <div class="card-header">
                    <div class="d-flex align-items-center justify-content-center">
                        <i class="bi bi-people-fill me-3"></i>
                        <h2 class="mb-0">𝐌𝐚𝐧𝐚𝐠𝐞 𝐔𝐬𝐞𝐫𝐬</h2>
                    </div>
                </div>

                <div class="card-body">
                    <?php if ($user_list) : ?>
                        <div class="table-responsive">
                            <table id="usersTable" class="table table-bordered table-hover text-center" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Username</th>
                                        <th>Fullname</th>
                                        <th>Level</th>
                                        <th>Saldo</th>
                                        <th>Status</th>
                                        <th>Uplink</th>
                                        <th>Expiration</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($user_list as $u) : ?>
                                        <tr>
                                            <td><?= esc($u->id_users) ?></td>
                                            <td><?= esc($u->username) ?></td>
                                            <td><?= esc($u->fullname) ?></td>
                                            <td>
                                                <span class="badge <?= esc($u->level_badge) ?>"><?= esc($u->level_text) ?></span>
                                            </td>
                                            <td>
                                                <?= $u->saldo_display ?>
                                            </td>
                                            <td>
                                                <span class="badge <?= esc($u->status_badge) ?>"><?= esc($u->status_text) ?></span>
                                            </td>
                                            <td><?= esc($u->uplink) ?></td>
                                            <td><?= esc($u->expiration_date) ?></td>
                                            <td>
                                                <a href="user/<?php echo $u->id_users ?>" class="btn btn-edit btn-sm">
                                                    <i class="bi bi-pencil-square"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else : ?>
                        <div class="text-center py-5">
                            <p class="text-muted">No users found.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('css') ?>
<?= link_tag("https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap5.min.css") ?>
<?= $this->endSection() ?>

<?= $this->section('js') ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js") ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js") ?>

<script>
    $(document).ready(function() {
        $('#usersTable').DataTable({
            "order": [[0, "desc"]],
            "pageLength": 25,
            "language": {
                "search": "Search users:",
                "lengthMenu": "Show _MENU_ users"
            },
            responsive: true
        });

        const animatedElements = document.querySelectorAll('.animate-in');
        animatedElements.forEach(element => {
            element.style.animationPlayState = 'running';
        });
    });
</script>
<?= $this->endSection() ?>