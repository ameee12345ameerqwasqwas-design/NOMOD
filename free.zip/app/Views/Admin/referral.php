<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<style>
    body {
        background-image: url('<?= base_url('assets/images/backround1.avif') ?>');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        background-color: #24193d;
    }
    
    .referral-container {
        padding: 15px;
    }
    
    .card {
        background-color: rgba(80, 50, 140, 0.55) !important;
        backdrop-filter: blur(15px);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 18px;
        box-shadow: 0 10px 35px rgba(0, 0, 0, 0.4);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        overflow: hidden;
        margin-bottom: 25px;
    }
    
    .card:hover {
        transform: translateY(-8px);
        box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
    }
    
    .card-header {
        background-color: rgba(80, 50, 140, 0.6) !important;
        border-bottom: 1px solid rgba(255, 255, 255, 0.15);
        color: white !important;
        font-weight: 600;
        padding: 18px 25px;
        font-size: 1.1rem;
        text-align: center;
    }
    
    .card-body {
        padding: 25px;
        color: white;
    }
    
    .form-control, .form-select {
        background-color: rgba(255, 255, 255, 0.12);
        border: 1px solid rgba(255, 255, 255, 0.25);
        color: white;
        border-radius: 10px;
    }
    
    .form-control:focus, .form-select:focus {
        background-color: rgba(255, 255, 255, 0.18);
        border-color: rgba(167, 139, 250, 0.7);
        color: white;
        box-shadow: 0 0 0 0.25rem rgba(167, 139, 250, 0.3);
    }
    
    .form-control::placeholder {
        color: rgba(255, 255, 255, 0.7);
    }
    
    .form-select option {
        background-color: #5d3f9f;
        color: white;
    }
    
    .form-label {
        color: white;
        font-weight: 500;
        margin-bottom: 8px;
    }
    
    .input-group-text {
        background-color: rgba(80, 50, 140, 0.9);
        border: 1px solid rgba(255, 255, 255, 0.25);
        color: white;
        border-radius: 10px 0 0 10px;
    }
    
    .btn-create {
        background: linear-gradient(135deg, #7e5bef, #a78bfa);
        border: none;
        color: white;
        font-weight: 600;
        border-radius: 10px;
        padding: 14px;
        transition: all 0.3s ease;
        width: 100%;
        font-size: 1.05rem;
    }
    
    .btn-create:hover {
        background: linear-gradient(135deg, #6a4cc7, #9470db);
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(126, 91, 239, 0.4);
        color: white;
    }
    
    .table {
        color: #e0e0ff !important;
        margin-bottom: 0;
    }
    
    .table thead th {
        background-color: rgba(80, 50, 140, 0.7);
        border-color: rgba(255, 255, 255, 0.2) !important;
        font-weight: 600;
    }
    
    .table-bordered {
        border-color: rgba(255, 255, 255, 0.15) !important;
    }
    
    .table-hover tbody tr:hover {
        background-color: rgba(255, 255, 255, 0.15) !important;
    }
    
    .badge.bg-primary {
        background-color: #a78bfa !important;
        padding: 6px 12px;
        font-size: 0.9rem;
    }
    
    .animate-in {
        animation: fadeIn 0.6s ease-out forwards;
        opacity: 0;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(25px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    @media (max-width: 992px) {
        .referral-container {
            padding: 15px;
        }
    }
    
    @media (max-width: 768px) {
        .card-header {
            font-size: 1.05rem;
            padding: 16px 20px;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .table-responsive {
            font-size: 0.9rem;
        }
        
        .btn-create {
            padding: 14px;
            font-size: 1rem;
        }
    }
    
    @media (max-width: 576px) {
        .referral-container {
            padding: 10px;
        }
        
        .card-header {
            font-size: 1rem;
            padding: 14px 16px;
        }
        
        .card-body {
            padding: 18px;
        }
        
        .table {
            font-size: 0.85rem;
        }
    }
</style>

<div class="referral-container">
    <div class="row justify-content-center mt-3">
        <div class="col-12">
            <?= $this->include('Layout/msgStatus') ?>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-lg-4 col-md-6 col-12 animate-in" style="animation-delay: 0.1s">
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-ticket-perforated me-2"></i> Generate <?= $title ?>
                </div>
                <div class="card-body">
                    <?= form_open() ?>

                    <div class="form-group mb-3">
                        <label for="set_saldo" class="form-label">You can set with multiple saldo</label>
                        <div class="input-group mt-2">
                            <span class="input-group-text"><i class="bi bi-currency-dollar"></i></span>
                            <input type="number" class="form-control" name="set_saldo" id="set_saldo" minlength="1" maxlength="11" value="5">
                        </div>
                        <?php if (!empty($errors['set_saldo'])) : ?>
                            <small class="text-danger"><?= esc($errors['set_saldo']) ?></small>
                        <?php endif; ?>
                    </div>

                    <div class="form-group mb-3">
                        <label for="accExpire" class="form-label">Account Expiration</label>
                        <?= form_dropdown(['class' => 'form-select', 'name' => 'accExpire', 'id' => 'accExpire'], $accExpire, esc($accExpire_value)) ?>
                        <?php if (!empty($errors['accExpire'])) : ?>
                            <small class="text-danger"><?= esc($errors['accExpire']) ?></small>
                        <?php endif; ?>
                    </div>

                    <div class="form-group mb-3">
                        <label for="accLevel" class="form-label">Account Level</label>
                        <?= form_dropdown(['class' => 'form-select', 'name' => 'accLevel', 'id' => 'accLevel'], $accLevel, esc($accLevel_value)) ?>
                        <?php if (!empty($errors['accLevel'])) : ?>
                            <small class="text-danger"><?= esc($errors['accLevel']) ?></small>
                        <?php endif; ?>
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn-create">
                            <i class="bi bi-plus-circle me-2"></i> Create Code
                        </button>
                    </div>

                    <?= form_close() ?>
                </div>
            </div>
        </div>

        <div class="col-lg-8 col-md-6 col-12 animate-in" style="animation-delay: 0.2s">
            <?php if ($code) : ?>
                <div class="card">
                    <div class="card-header">
                        <i class="bi bi-clock-history me-2"></i> History Generate - Total <?= $total_code ?>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover text-center" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Referral</th>
                                        <th>Hashed</th>
                                        <th>Saldo</th>
                                        <th>Level</th>
                                        <th>Expiration</th>
                                        <th>Used by</th>
                                        <th>Create by</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($code as $c) : ?>
                                        <tr>
                                            <td><?= esc($c->id_reff) ?></td>
                                            <td><span class="badge bg-primary"><?= esc($c->Referral) ?></span></td>
                                            <td><span class="text-warning"><?= esc(substr($c->code, 1, 15)) ?></span></td>
                                            <td><span class="text-success">$<?= esc($c->set_saldo) ?></span></td>
                                            <td><?= esc($c->level) ?></td>
                                            <td><?= esc($c->acc_expiration) ?></td>
                                            <td><?= esc($c->used_by) ?: '<span class="text-muted">Not used</span>' ?></td>
                                            <td><?= esc($c->created_by) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const animatedElements = document.querySelectorAll('.animate-in');
        animatedElements.forEach(element => {
            element.style.animationPlayState = 'running';
        });
    });
</script>
<?= $this->endSection() ?>