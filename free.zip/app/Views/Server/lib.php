<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>

<style>
    body {
        background-image: url('<?= base_url('assets/images/backround1.avif') ?>');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        background-color: #24193d;
        font-family: 'Poppins', sans-serif;
    }
    
    .files-container {
        padding: 15px;
    }
    
    .card {
        background-color: rgba(93, 63, 159, 0.75) !important;
        backdrop-filter: blur(12px);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 18px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.35);
        transition: all 0.3s ease;
        overflow: hidden;
        margin-bottom: 30px;
    }
    
    .card:hover {
        transform: translateY(-8px);
        box-shadow: 0 18px 50px rgba(0, 0, 0, 0.45);
    }
    
    .card-header {
        background: linear-gradient(135deg, rgba(93, 63, 159, 0.6), rgba(80, 50, 140, 0.8)) !important;
        border-bottom: 1px solid rgba(255, 255, 255, 0.15);
        color: white !important;
        font-weight: 600;
        padding: 18px 25px;
        font-size: 1.3rem;
        letter-spacing: 0.5px;
        text-align: center;
    }
    
    .card-body {
        padding: 25px 20px;
    }
    
    .form-control-custom, .search-input {
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: white;
        border-radius: 12px;
        padding: 12px 16px;
    }
    
    .form-control-custom:focus, .search-input:focus {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: rgba(167, 139, 250, 0.6);
        box-shadow: 0 0 0 0.25rem rgba(167, 139, 250, 0.3);
        color: white;
        outline: none;
    }
    
    .btn-gradient {
        background: linear-gradient(135deg, #7e5bef, #a78bfa);
        border: none;
        color: white;
        font-weight: 600;
        border-radius: 12px;
        padding: 12px 24px;
        transition: all 0.3s ease;
    }
    
    .btn-gradient:hover {
        background: linear-gradient(135deg, #6a4cc7, #9470db);
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(126, 91, 239, 0.4);
    }
    
    .btn-action {
        padding: 10px 14px;
        border-radius: 10px;
        font-size: 0.9rem;
        border-color: rgba(255, 255, 255, 0.4) !important;
        background-color: rgba(93, 63, 159, 0.4) !important;
        color: white !important;
        text-align: center;
    }
    
    .btn-action:hover {
        background-color: rgba(167, 139, 250, 0.6) !important;
    }
    
    .file-card {
        background-color: rgba(93, 63, 159, 0.4);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 15px;
        padding: 20px;
        transition: all 0.3s ease;
        height: 100%;
        display: flex;
        flex-direction: column;
    }
    
    .file-card:hover {
        background-color: rgba(93, 63, 159, 0.6);
        transform: translateY(-5px);
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
    }
    
    .file-name {
        color: #d0bcff;
        font-weight: 600;
        font-size: 1.1rem;
    }
    
    .file-info {
        color: rgba(255, 255, 255, 0.8);
        font-size: 0.95rem;
        margin-bottom: 8px;
    }
    
    .upload-section {
        background-color: rgba(93, 63, 159, 0.4);
        border-radius: 15px;
        padding: 25px;
        margin-bottom: 30px;
        border: 1px solid rgba(255, 255, 255, 0.1);
    }
    
    .section-title {
        color: white;
        font-weight: 600;
        margin-bottom: 20px;
        font-size: 1.2rem;
    }
    
    .toast-container {
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        display: flex;
        flex-direction: column;
        gap: 10px;
    }
    
    .toast-alert {
        min-width: 280px;
        max-width: 380px;
        background-color: rgba(93, 63, 159, 0.95);
        backdrop-filter: blur(10px);
        border-left: 5px solid #a78bfa;
        border-radius: 12px;
        padding: 14px 18px;
        color: white;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4);
        animation: slideInRight 0.4s ease-out forwards;
        opacity: 0;
        font-size: 0.95rem;
    }
    
    .toast-alert.danger {
        border-left-color: #ff6b6b;
    }
    
    .toast-alert.success {
        border-left-color: #51cf66;
    }
    
    @keyframes slideInRight {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    .empty-state {
        text-align: center;
        padding: 60px 20px;
        color: rgba(255, 255, 255, 0.7);
    }
    
    .empty-state i {
        font-size: 60px;
        color: rgba(255, 255, 255, 0.3);
        margin-bottom: 20px;
    }
    
    .animate-in {
        animation: fadeInUp 0.6s ease-out forwards;
        opacity: 0;
    }
    
    @keyframes fadeInUp {
        from { opacity: 0; transform: translateY(30px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .rename-input {
        background: rgba(255, 255, 255, 0.1);
        border: 1px solid #a78bfa;
        color: white;
    }

    @media (max-width: 992px) {
        .files-container {
            padding: 15px;
        }
        
        #filesGrid {
            row-gap: 20px;
        }
    }

    @media (max-width: 768px) {
        .card-header {
            font-size: 1.2rem;
            padding: 16px;
        }
        
        .card-body {
            padding: 20px 15px;
        }
        
        .upload-section {
            padding: 20px;
        }
        
        .d-flex.justify-content-between.align-items-center.mb-4 {
            flex-direction: column;
            align-items: stretch !important;
            gap: 15px;
        }
        
        .search-input {
            width: 100% !important;
        }
        
        .d-flex.flex-wrap.gap-2 {
            flex-direction: column;
            gap: 10px !important;
        }
        
        .btn-action {
            width: 100%;
            padding: 12px;
            font-size: 1rem;
        }
        
        #rename-form-* .d-flex.gap-2 {
            flex-direction: column;
        }
        
        #rename-form-* .btn-sm {
            width: 100%;
        }
    }

    @media (max-width: 576px) {
        .files-container {
            padding: 10px;
        }
        
        .card-header {
            font-size: 1.1rem;
            padding: 14px;
        }
        
        .upload-section {
            padding: 15px;
        }
        
        .section-title {
            font-size: 1.1rem;
        }
        
        .file-name {
            font-size: 1rem;
        }
        
        .file-card {
            padding: 15px;
        }
    }
</style>

<!-- Toast Container -->
<div class="toast-container" id="toastContainer"></div>

<div class="files-container">
    <div class="row justify-content-center mt-3">
        <div class="col-12">
            <?= $this->include('Layout/msgStatus') ?>
        </div>
    </div>

    <div class="row justify-content-center">
        <div class="col-12">
            <div class="card animate-in" style="animation-delay: 0.1s">
                <div class="card-header">
                    <i class="bi bi-folder-fill me-2"></i> Online Files
                </div>
                <div class="card-body">
                    
                <!-- Upload Section -->
                <div class="upload-section mb-5">
                    <h5 class="section-title"><i class="bi bi-cloud-upload me-2"></i>Upload New File</h5>
                    <form id="uploadForm" enctype="multipart/form-data" class="row g-3 align-items-end">
                        <?= csrf_field() ?>
                        <div class="col-12 col-md-8">
                            <input type="file" name="file" required class="form-control form-control-custom" id="fileInput">
                        </div>
                        <div class="col-12 col-md-4">
                            <button type="submit" class="btn btn-gradient w-100">
                                <i class="bi bi-upload me-2"></i>Upload File
                            </button>
                        </div>
                    </form>

                    <!-- Progress Bar  -->
                    <div class="progress-custom mt-3 d-none" id="progressContainer">
                        <div class="d-flex justify-content-between mb-1">
                            <small id="progressText" class="text-light">Uploading...</small>
                            <small id="progressPercent" class="text-light">0%</small>
                        </div>
                        <div class="progress" style="height: 8px; background: rgba(255,255,255,0.1);">
                            <div id="progressBar" class="progress-bar progress-bar-striped progress-bar-animated" 
                                style="width: 0%; background: linear-gradient(90deg, #7e5bef, #a78bfa);"></div>
                        </div>
                    </div>

                    <small class="text-muted d-block mt-3">
                        <i class="bi bi-info-circle me-1"></i>Allowed extensions: rar, zip, so, lua, txt, log, json, cfg, ini, yaml, yml, sql, csv, xml, dat
                    </small>
                </div>

                    <!-- Search + Files Count -->
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="section-title mb-0"><i class="bi bi-files me-2"></i>Uploaded Files (<?= count($files) ?>)</h5>
                        <input type="text" id="searchFiles" class="search-input" placeholder="Search files...">
                    </div>

                    <?php if(empty($files)): ?>
    <div class="empty-state">
        <i class="bi bi-folder-x"></i>
        <h4>No files uploaded yet</h4>
        <p>Start by uploading your first file!</p>
    </div>
<?php else: ?>
    <div class="row g-4" id="filesGrid">
        <?php foreach($files as $f): ?>
        <div class="col-12 col-md-6 col-lg-4 file-item">
            <div class="file-card">
                <div class="d-flex align-items-center mb-3 justify-content-between">
                    <div class="d-flex align-items-center flex-grow-1 me-2">
                        <i class="bi <?= $f['icon_class'] ?> text-info me-3 fs-3 flex-shrink-0"></i>
                        <h6 class="file-name mb-0 text-truncate flex-grow-1" id="name-display-<?= $f['name_escaped'] ?>" title="<?= $f['name_escaped'] ?>">
                            <?= $f['name_escaped'] ?>
                        </h6>
                    </div>
                    <button class="btn btn-sm btn-outline-primary flex-shrink-0" onclick="startRename('<?= $f['name_escaped'] ?>')">
                        <i class="bi bi-pencil"></i>
                    </button>
                </div>

                <div id="rename-form-<?= $f['name_escaped'] ?>" class="d-none mt-3">
                    <form class="d-flex flex-column gap-2" onsubmit="event.preventDefault(); saveRename('<?= $f['name_escaped'] ?>');">
                        <div class="d-flex align-items-center gap-2">
                            <input type="text" class="form-control form-control-custom rename-input flex-grow-1" value="<?= esc($f['basename_no_ext']) ?>" id="rename-input-<?= $f['name_escaped'] ?>">
                            <small class="text-muted align-self-center">.<?= $f['ext'] ?></small>
                        </div>
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-gradient btn-sm flex-grow-1">
                                <i class="bi bi-check"></i> Save
                            </button>
                            <button type="button" class="btn btn-outline-light btn-sm flex-grow-1" onclick="cancelRename('<?= $f['name_escaped'] ?>')">
                                <i class="bi bi-x"></i> Cancel
                            </button>
                        </div>
                    </form>
                </div>

                <div class="file-info">
                    <i class="bi bi-hdd me-1"></i>Size: <?= $f['size_formatted'] ?>
                </div>
                <div class="file-info mb-4">
                    <i class="bi bi-clock me-1"></i>Last Modified: <?= $f['modified'] ?>
                </div>
                <div class="d-flex flex-wrap gap-2 mt-auto">
                    <a href="<?= $f['view_url'] ?>" target="_blank" class="btn btn-outline-light btn-action flex-fill">
                        <i class="bi bi-eye me-1"></i>View
                    </a>
                    <a href="<?= $f['dl_url'] ?>" class="btn btn-outline-success btn-action flex-fill">
                        <i class="bi bi-download me-1"></i>Download
                    </a>
                    <button class="btn btn-outline-info btn-action flex-fill" onclick="copyLink('<?= $f['dl_url_escaped'] ?>')">
                        <i class="bi bi-clipboard"></i>Copy Link
                    </button>
                    <form method="post" action="<?= $f['delete_url'] ?>" class="d-inline w-100" onsubmit="return confirmDelete(event)">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-outline-danger btn-action w-100 mt-2">
                            <i class="bi bi-trash"></i>Delete
                        </button>
                    </form>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function showNotification(message, type = 'success') {
        const container = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.className = `toast-alert ${type}`;
        toast.innerHTML = `
            <strong>${type === 'danger' ? 'Error!' : 'Success!'}</strong><br>
            <span>${message}</span>
        `;
        container.appendChild(toast);
        
        setTimeout(() => {
            toast.style.animation = 'slideInRight 0.4s ease-out reverse';
            setTimeout(() => toast.remove(), 400);
        }, 4000);
    }

    function copyLink(url) {
        navigator.clipboard.writeText(url).then(() => {
            showNotification('Link copied successfully ');
        }).catch(() => {
            showNotification('Failed to copy link ', 'danger');
        });
    }

    function confirmDelete(event) {
        if (!confirm('⚠️ Are you sure you want to delete this file?')) {
            event.preventDefault();
            return false;
        }
        showNotification('Deleting file...');
        return true;
    }

    // ====================== AJAX UPLOAD ======================
    document.getElementById('uploadForm').addEventListener('submit', function(e) {
        e.preventDefault();

        const fileInput = document.getElementById('fileInput');
        if (!fileInput.files || fileInput.files.length === 0) {
            showNotification('No file selected', 'danger');
            return;
        }

        const file = fileInput.files[0];
        const ext = file.name.split('.').pop().toLowerCase();
        
        const allowed = ['rar','zip','so','lua','txt','log','json','cfg','ini','yaml','yml','sql','csv','xml','dat'];

        if (!allowed.includes(ext)) {
            showNotification('File type not allowed! Allowed: ' + allowed.join(', '), 'danger');
            return;
        }

        if (!confirm(`Upload "${file.name}"?\nSize: ${(file.size / 1024 / 1024).toFixed(2)} MB`)) {
            return;
        }

        const formData = new FormData(this);
        
        const progressContainer = document.getElementById('progressContainer');
        const progressBar       = document.getElementById('progressBar');
        const progressText      = document.getElementById('progressText');
        const progressPercent   = document.getElementById('progressPercent');

        progressContainer.classList.remove('d-none');
        progressBar.style.width = '0%';
        progressPercent.textContent = '0%';
        progressText.textContent = 'Uploading...';

        const xhr = new XMLHttpRequest();
        xhr.open('POST', '<?= site_url("lib/upload") ?>', true);

        xhr.upload.onprogress = function(e) {
            if (e.lengthComputable) {
                const percent = Math.round((e.loaded / e.total) * 100);
                progressBar.style.width = percent + '%';
                progressPercent.textContent = percent + '%';
                if (percent >= 100) progressText.textContent = 'Processing file...';
            }
        };

        xhr.onload = function() {
            progressContainer.classList.add('d-none');

            try {
                const res = JSON.parse(this.responseText);
                if (res.success) {
                    showNotification(res.message + ' ✅', 'success');
                    setTimeout(() => location.reload(), 1200);
                } else {
                    showNotification(res.message, 'danger');
                }
            } catch (err) {
                showNotification('Server error occurred', 'danger');
            }
        };

        xhr.onerror = function() {
            progressContainer.classList.add('d-none');
            showNotification('Upload failed. Check your connection.', 'danger');
        };

        xhr.send(formData);
    });

    function startRename(filename) {
        document.getElementById('name-display-' + filename).classList.add('d-none');
        document.getElementById('rename-form-' + filename).classList.remove('d-none');
        const input = document.getElementById('rename-input-' + filename);
        input.focus();
        input.select();
    }

    function cancelRename(filename) {
        document.getElementById('name-display-' + filename).classList.remove('d-none');
        document.getElementById('rename-form-' + filename).classList.add('d-none');
    }

    async function saveRename(originalFilename) {
        const newBase = document.getElementById('rename-input-' + originalFilename).value.trim();

        if (newBase === originalFilename.replace(/\.[^/.]+$/, "")) {
            cancelRename(originalFilename);
            return;
        }

        if (newBase === '') {
            showNotification('Filename cannot be empty', 'danger');
            return;
        }

        const formData = new FormData();
        formData.append('original_name', originalFilename);
        formData.append('new_name', newBase);
        const token = document.querySelector('input[name="<?= csrf_token() ?>"]');
        if (token) formData.append('<?= csrf_token() ?>', token.value);

        try {
            showNotification('Renaming file...');
            const res = await fetch('<?= site_url("lib/rename") ?>', {
                method: 'POST',
                body: formData
            });
            const json = await res.json();

            if (json.success) {
                showNotification(json.message + ' ✅');
                setTimeout(() => location.reload(), 1500);
            } else {
                showNotification(json.message, 'danger');
                cancelRename(originalFilename);
            }
        } catch (e) {
            showNotification('Rename failed ❌', 'danger');
            cancelRename(originalFilename);
        }
    }

    document.getElementById('searchFiles')?.addEventListener('input', function() {
        const query = this.value.toLowerCase();
        document.querySelectorAll('.file-item').forEach(item => {
            const name = item.querySelector('.file-name').textContent.toLowerCase();
            item.style.display = name.includes(query) ? '' : 'none';
        });
    });

    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.animate-in').forEach((el, i) => {
            el.style.animationDelay = `${i * 0.1}s`;
        });
    });
</script>

<?= $this->endSection() ?>