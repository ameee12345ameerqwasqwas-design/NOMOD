<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>

<style>
    body {
        background-image: url('<?= base_url('assets/images/backround1.avif') ?>');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        background-color: #24193d;
        font-family: 'Poppins', sans-serif;
    }
    
    .admin-container {
        padding: 20px;
    }
    
    .card {
        background-color: rgba(93, 63, 159, 0.75) !important;
        backdrop-filter: blur(12px);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 18px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.35);
        transition: all 0.3s ease;
        overflow: hidden;
        margin-bottom: 30px;
    }
    
    .card:hover {
        transform: translateY(-8px);
        box-shadow: 0 18px 50px rgba(0, 0, 0, 0.45);
    }
    
    .card-header {
        background: linear-gradient(135deg, rgba(93, 63, 159, 0.6), rgba(80, 50, 140, 0.8)) !important;
        border-bottom: 1px solid rgba(255, 255, 255, 0.15);
        color: white !important;
        font-weight: 600;
        padding: 18px 25px;
        font-size: 1.2rem;
        letter-spacing: 0.5px;
        text-align: center;
    }
    
    .card-body {
        padding: 28px;
        color: white;
    }
    
    .form-control, .form-select, textarea {
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: white;
        border-radius: 12px;
        padding: 12px 16px;
    }
    
    .form-control:focus, .form-select:focus, textarea:focus {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: rgba(167, 139, 250, 0.6);
        box-shadow: 0 0 0 0.25rem rgba(167, 139, 250, 0.3);
    }
    
    .btn {
        border-radius: 12px;
        padding: 12px 24px;
        font-weight: 600;
        transition: all 0.3s ease;
    }
    
    .btn-outline-primary, .btn-outline-danger, .btn-outline-warning, .btn-outline-success {
        color: white !important;
        border-color: rgba(255, 255, 255, 0.4) !important;
        background-color: rgba(93, 63, 159, 0.4) !important;
    }
    
    .btn-outline-primary:hover { background-color: rgba(13, 110, 253, 0.3) !important; }
    .btn-outline-danger:hover { background-color: rgba(220, 53, 69, 0.3) !important; }
    .btn-outline-warning:hover { background-color: rgba(255, 193, 7, 0.3) !important; }
    .btn-outline-success:hover { background-color: rgba(25, 135, 84, 0.3) !important; }
    
    .hacks {
    display: flex !important;
    align-items: center !important;
    justify-content: space-between !important;
    padding: 12px 22px !important;
    margin-bottom: 12px !important;
    margin-left: auto !important;
    margin-right: auto !important;
    background-color: rgba(255, 255, 255, 0.08);
    border-radius: 14px;
    border: 1px solid rgba(255, 255, 255, 0.1);
    width: 96% !important;
    max-width: 96% !important;
    min-height: 52px !important;
    font-size: 1.03rem;
}

.hacks:hover {
    background-color: rgba(255, 255, 255, 0.13);
    border-color: rgba(167, 139, 250, 0.5);
}
    
    .switch {
        position: relative;
        display: inline-block;
        width: 60px;
        height: 32px;
        flex-shrink: 0;
    }
    
    .switch input { 
        opacity: 0; 
        width: 0; 
        height: 0; 
    }
    
    .slider {
        position: absolute;
        cursor: pointer;
        top: 0; left: 0; right: 0; bottom: 0;
        background-color: rgba(255, 255, 255, 0.2);
        transition: .4s;
        border-radius: 32px;
    }
    
    .slider:before {
        position: absolute;
        content: "";
        height: 24px;
        width: 24px;
        left: 4px;
        bottom: 4px;
        background-color: white;
        transition: .4s;
        border-radius: 50%;
    }
    
    input:checked + .slider { 
        background-color: #a78bfa; 
    }
    input:checked + .slider:before { 
        transform: translateX(28px); 
    }
    
    .text-info { 
        color: #d0bcff !important; 
        font-weight: 600; 
    }
    
    .animate-in {
        animation: fadeInUp 0.6s ease-out forwards;
        opacity: 0;
    }
    
    @keyframes fadeInUp {
        from { opacity: 0; transform: translateY(30px); }
        to { opacity: 1; transform: translateY(0); }
    }

    @media (max-width: 992px) {
        .admin-container {
            padding: 15px;
        }
    }

    @media (max-width: 768px) {
        .card-header {
            font-size: 1.1rem;
            padding: 16px;
        }
        
        .card-body {
            padding: 22px;
        }
        
        .hacks {
            font-size: 1rem;
            padding: 14px 18px;
        }
        
        .btn {
            width: 100%;
            padding: 14px;
            font-size: 1.05rem;
        }
        
        textarea.form-control {
            min-height: 110px;
        }
    }

    @media (max-width: 576px) {
        .admin-container {
            padding: 10px;
        }
        
        .card-header {
            font-size: 1.05rem;
            padding: 14px;
        }
        
        .card-body {
            padding: 18px;
        }
        
        .hacks {
            padding: 12px 16px;
            font-size: 0.95rem;
        }
        
        .switch {
            width: 54px;
            height: 28px;
        }
        
        .slider:before {
            height: 20px;
            width: 20px;
            left: 4px;
            bottom: 4px;
        }
        
        input:checked + .slider:before {
            transform: translateX(26px);
        }
    }
</style>

<div class="admin-container">
    <div class="row justify-content-center mt-3">
        <div class="col-12">
            <?= $this->include('Layout/msgStatus') ?>
        </div>
    </div>

    <div class="row g-4 justify-content-center">
        <div class="col-lg-6 col-12">
            <?php if($user->level != 2) : ?>
            <div class="card animate-in" style="animation-delay: 0.1s">
                <div class="card-header">
                    <i class="bi bi-server me-2"></i> Server Maintenance Mode
                </div>
                <div class="card-body">
                    <?= form_open() ?>
                    <input type="hidden" name="status_form" value="1">
                    <div class="mb-4">
                        <label class="mb-3">Current Maintenance Mode: <span class="text-info"><?= esc($onoff_data['status'] ?? 'Unknown') ?></span></label>
                        <label class="hacks">
                            Maintenance Mode
                            <div class="switch">
                                <input type="checkbox" name="radios" value="on" <?= ($onoff_data['status'] ?? '') == "on" ? 'checked' : '' ?>>
                                <span class="slider round"></span>
                            </div>
                        </label>
                    </div>
                    <div class="mb-4">
                        <label class="mb-3">Offline Message: <span class="text-info"><?= esc($onoff_data['myinput'] ?? 'No message') ?></span></label>
                        <textarea class="form-control" name="myInput" rows="3" placeholder="Server is under maintenance..."><?= esc($myInput_value) ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-outline-primary">
                        <i class="bi bi-save me-2"></i> Update
                    </button>
                    <?= form_close() ?>
                </div>
            </div>

            <div class="card animate-in" style="animation-delay: 0.2s">
                <div class="card-header">
                    <i class="bi bi-pencil-square me-2"></i> Change Mod Name
                </div>
                <div class="card-body">
                    <?= form_open() ?>
                    <input type="hidden" name="modname_form" value="1">
                    <div class="mb-4">
                        <label class="mb-3">Current Mod Name: <span class="text-info"><?= esc($modname_data['modname'] ?? 'Unknown') ?></span></label>
                        <input type="text" name="modname" class="form-control" placeholder="Enter new mod name" value="<?= esc($modname_value) ?>" required>
                    </div>
                    <button type="submit" class="btn btn-outline-warning">
                        <i class="bi bi-save me-2"></i> Update Name
                    </button>
                    <?= form_close() ?>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <div class="col-lg-6 col-12">
            <div class="card animate-in" style="animation-delay: 0.3s">
                <div class="card-header">
                    <i class="bi bi-toggles me-2"></i> Mod Features
                </div>
                <div class="card-body">
                    <?= form_open() ?>
                    <input type="hidden" name="feature_form" value="1">
                    <div class="mb-4">
                        <label class="mb-3">Current Status:</label>
                        <div class="text-info small mb-4">
                            ESP: <?= esc($feature_data['ESP'] ?? 'off') ?> | 
                            Items: <?= esc($feature_data['Item'] ?? 'off') ?> | 
                            AIM: <?= esc($feature_data['AIM'] ?? 'off') ?> | 
                            SilentAim: <?= esc($feature_data['SilentAim'] ?? 'off') ?> | 
                            BulletTrack: <?= esc($feature_data['BulletTrack'] ?? 'off') ?> | 
                            Memory: <?= esc($feature_data['Memory'] ?? 'off') ?> | 
                            Floating Texts: <?= esc($feature_data['Floating'] ?? 'off') ?> | 
                            Setting: <?= esc($feature_data['Setting'] ?? 'off') ?>
                        </div>
                        
                        <label class="hacks">ESP <div class="switch"><input type="checkbox" name="ESP" value="on" <?= $esp_checked ?>><span class="slider round"></span></div></label>
                        <label class="hacks">Items <div class="switch"><input type="checkbox" name="Item" value="on" <?= $item_checked ?>><span class="slider round"></span></div></label>
                        <label class="hacks">Aim-Bot <div class="switch"><input type="checkbox" name="AIM" value="on" <?= $aim_checked ?>><span class="slider round"></span></div></label>
                        <label class="hacks">Silent Aim <div class="switch"><input type="checkbox" name="SilentAim" value="on" <?= $silentAim_checked ?>><span class="slider round"></span></div></label>
                        <label class="hacks">Bullet Track <div class="switch"><input type="checkbox" name="BulletTrack" value="on" <?= $bulletTrack_checked ?>><span class="slider round"></span></div></label>
                        <label class="hacks">Memory <div class="switch"><input type="checkbox" name="Memory" value="on" <?= $memory_checked ?>><span class="slider round"></span></div></label>
                        <label class="hacks">Floating Texts <div class="switch"><input type="checkbox" name="Floating" value="on" <?= $floating_checked ?>><span class="slider round"></span></div></label>
                        <label class="hacks">Settings <div class="switch"><input type="checkbox" name="Setting" value="on" <?= $setting_checked ?>><span class="slider round"></span></div></label>
                    </div>
                    <button type="submit" class="btn btn-outline-danger">
                        <i class="bi bi-save me-2"></i> Update Features
                    </button>
                    <?= form_close() ?>
                </div>
            </div>

            <div class="card animate-in" style="animation-delay: 0.4s">
                <div class="card-header">
                    <i class="bi bi-chat-text me-2"></i> Change Floating Text
                </div>
                <div class="card-body">
                    <?= form_open() ?>
                    <input type="hidden" name="_ftext" value="1">
                    <div class="mb-4">
                        <label class="mb-3">Current Mod Status: <span class="text-info"><?= esc($ftext_data['_status'] ?? 'Unknown') ?></span></label>
                        <label class="hacks">
                            Safe Mode
                            <div class="switch">
                                <input type="checkbox" name="_ftextr" value="Safe" <?= $safe_checked ?>>
                                <span class="slider round"></span>
                            </div>
                        </label>
                    </div>
                    <div class="mb-4">
                        <label class="mb-3">Current Floating Text: <span class="text-info"><?= esc($ftext_data['_ftext'] ?? 'No text') ?></span></label>
                        <input type="text" name="_ftext" class="form-control" placeholder="Give feedback else key removed!" value="<?= esc($_ftext_value) ?>" required>
                    </div>
                    <button type="submit" class="btn btn-outline-success">
                        <i class="bi bi-save me-2"></i> Update Text
                    </button>
                    <?= form_close() ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.animate-in').forEach((el, index) => {
            el.style.animationDelay = `${index * 0.1}s`;
            el.style.animationPlayState = 'running';
        });
    });
</script>

<?= $this->endSection() ?>