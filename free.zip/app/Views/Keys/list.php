<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>
<style>
    body {
        background-image: url('<?= base_url('assets/images/backround1.avif') ?>');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        background-color: #24193d;
    }
    
    .card {
        background-color: rgba(93, 63, 159, 0.7) !important;
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 15px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        overflow: hidden;
        margin-bottom: 25px;
    }
    
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4);
    }
    
    .card-header {
        background-color: rgba(93, 63, 159, 0.4) !important;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        color: white !important;
        font-weight: 600;
        padding: 15px 20px;
    }
    
    .card-body {
        padding: 20px;
        color: white;
    }
    
    .form-control, .form-select {
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: white;
    }
    
    .form-control:focus, .form-select:focus {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: rgba(167, 139, 250, 0.5);
        color: white;
        box-shadow: 0 0 0 0.25rem rgba(167, 139, 250, 0.25);
    }
    
    .form-control::placeholder {
        color: rgba(255, 255, 255, 0.6);
    }
    
    .form-select option {
        background-color: rgba(93, 63, 159, 0.9);
        color: white;
    }
    
    .form-label {
        color: white;
        font-weight: 500;
        margin-bottom: 0.5rem;
    }
    
    .btn-outline-info {
        color: white;
        border-color: rgba(13, 202, 240, 0.5);
    }
    
    .btn-outline-info:hover {
        background-color: rgba(13, 202, 240, 0.2);
        color: white;
    }
    
    .btn-outline-light {
        color: white;
        border-color: rgba(255, 255, 255, 0.5);
    }
    
    .btn-outline-light:hover {
        background-color: rgba(255, 255, 255, 0.1);
        color: white;
    }
    
    .text-muted {
        color: rgba(255, 255, 255, 0.6) !important;
    }
    
    .maxDev {
        background-color: rgba(13, 202, 240, 0.2) !important;
        border: 1px solid rgba(13, 202, 240, 0.3);
        padding: 4px 8px !important;
        border-radius: 50px !important;
    }
    
    textarea {
        min-height: 100px;
    }
    
    .animate-in {
        animation: fadeIn 0.5s ease-out forwards;
        opacity: 0;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }

    .dropdown-menu {
        background-color: rgba(93, 63, 159, 0.95);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 12px;
    }
    
    .dropdown-item {
        color: white;
        padding: 10px 20px;
    }
    
    .dropdown-item:hover {
        background-color: rgba(167, 139, 250, 0.3);
    }
    
    .dropdown-item i {
        margin-right: 12px;
        width: 20px;
        text-align: center;
    }
</style>
<div class="row justify-content-center">
    <div class="col-lg-12">
        <?= $this->include('Layout/msgStatus') ?>
    </div>
    <div class="col-lg-12">
        <div class="card shadow-sm animate-in">
            <div class="card-header text-white" style="background: linear-gradient(135deg, rgba(93, 63, 159, 0.6), rgba(80, 50, 140, 0.8));">
                <div class="row align-items-center">
                    <div class="col pt-1">
                        <i class="bi bi-list-ul me-2"></i> Keys Registered
                        <button class="btn btn-sm btn-outline-light ms-3" id="blur-out" data-bs-toggle="tooltip" data-bs-placement="top" title="Eye Protect">
                            <i class="bi bi-eye-slash"></i>
                        </button>
                    </div>
                    <div class="col text-end">
                        <div class="dropdown d-inline-block">
                            <a class="btn btn-outline-light btn-sm dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="bi bi-three-dots-vertical me-2"></i> Menu
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="<?= site_url('keys/generate') ?>">
                                    <i class="bi bi-plus-circle-fill"></i> Generate Key
                                </a></li>
                                <li><a class="dropdown-item" href="<?= site_url('keys/deleteExp') ?>">
                                    <i class="bi bi-calendar-x-fill"></i> Delete Expired Keys
                                </a></li>
                                <li><a class="dropdown-item" href="<?= site_url('keys/deleteUnused') ?>">
                                    <i class="bi bi-trash-fill"></i> Delete Unused Keys  
                                </a></li>
                                <hr class="dropdown-divider">
                                <li><a class="dropdown-item" href="<?= site_url('keys/download_all_keys') ?>">
                                    <i class="bi bi-download"></i> Download All Keys
                                </a></li> 
                                <li><a class="dropdown-item" href="<?= site_url('keys/download_new_keys') ?>">
                                    <i class="bi bi-download"></i> Download New Keys
                                </a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?php if ($keylist) : ?>
                    <div class="table-responsive">
                        <table id="datatable" class="table table-bordered table-hover text-center" style="width:100%">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Game</th>
                                    <th>User Keys</th>
                                    <th>Devices</th>
                                    <th>Duration</th>
                                    <th>Expired</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                <?php else : ?>
                    <p class="text-center">Nothing keys to show</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
<?= $this->section('css') ?>
<?= link_tag("https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap5.min.css") ?>
<?= $this->endSection() ?>
<?= $this->section('js') ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js") ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js") ?>
<script>
    $(document).ready(function() {
        var table = $('#datatable').DataTable({
            processing: true,
            serverSide: true,
            order: [[0, "desc"]],
            ajax: "<?= site_url('keys/api') ?>",
            columns: [
                { data: 'id', name: 'id_keys' },
                { data: 'game' },
                {
                    data: 'user_key',
                    render: function(data, type, row) {
                        var is_valid = (row.status == 'Active') ? "text-warning" : "text-danger";
                        return `<span class="${is_valid} keyBlur key-sensi">${row.user_key ? row.user_key : '&mdash;'}</span>`;
                    }
                },
                {
                    data: 'devices',
                    render: function(data, type, row) {
    let totalDevice = 0;
    if (Array.isArray(row.devices)) {
        totalDevice = row.devices.length;
    } else if (typeof row.devices === 'string') {
        totalDevice = row.devices.split(',').filter(d => d.trim()).length;
    } else if (typeof row.devices === 'number') {
        totalDevice = row.devices;
    }

    return `<span id="devMax-${row.user_key}">${totalDevice}/${row.max_devices}</span>`;
}
                },
                { data: 'duration' },
                {
                    data: 'expired',
                    name: 'expired_date',
                    render: function(data, type, row) {
                        return row.expired ? `<span class="badge bg-warning text-dark">${row.expired}</span>` : '(not started yet)';
                    }
                },
                {
                    data: null,
                    render: function(data, type, row) {
                        return `
                            <div class="d-grid gap-2 d-md-block text-center">
                                <button class="btn btn-outline-danger btn-sm" onclick="resetUserKey('${row.user_key}')" title="Reset key?"><i class="bi bi-arrow-repeat"></i></button>
                                <button class="btn btn-outline-warning btn-sm" onclick="resetUserKey1('${row.user_key}')" title="DELETE KEY?"><i class="bi bi-trash-fill"></i></button>
                                <a href="<?= site_url('keys/') ?>${row.id}" class="btn btn-outline-info btn-sm" title="Edit key information?"><i class="bi bi-pencil-square"></i></a>
                            </div>`;
                    }
                }
            ]
        });
        $("#blur-out").click(function() {
            $(".keyBlur").toggleClass("key-sensi");
            $(this).html($(".keyBlur").hasClass("key-sensi") ? `<i class="bi bi-eye-slash"></i>` : `<i class="bi bi-eye"></i>`);
        });

        // Tooltips
        $('[data-bs-toggle="tooltip"]').tooltip();
    });
function resetUserKey(keys) {
    Swal.fire({
        title: 'Are you sure?',
        text: "This will reset all registered devices for this key.",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Reset Devices'
    }).then((result) => {
        if (result.isConfirmed) {
            $.getJSON("<?= site_url('keys/reset') ?>", { userkey: keys, reset: 1 }, function(data) {
                if (data.reset) {
                    Swal.fire({
                        title: 'Reset Successful!',
                        text: 'All devices have been cleared for this key.',
                        icon: 'success',
                        timer: 1500,
                        showConfirmButton: false
                    }).then(() => {
                        location.reload(); 
                    });
                } else {
                    Swal.fire('Failed!', 'Could not reset devices. Please try again.', 'error');
                }
            }).fail(function() {
                Swal.fire('Error!', 'Cannot connect to server. Please check your connection.', 'error');
            });
        }
    });
}
function resetUserKey1(keys) {
    Swal.fire({
        title: 'Are you sure?',
        text: "This action will permanently delete the key!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Yes, Delete!'
    }).then((result) => {
        if (result.isConfirmed) {
            $.getJSON("<?= site_url('keys/resetAll') ?>", { userkey: keys }, function(response) {
                if (response.success) {
                    Swal.fire({
                        title: 'Deleted!',
                        text: response.message,
                        icon: 'success',
                        timer: 1500,
                        showConfirmButton: false
                    }).then(() => {
                        location.reload(); 
                    });
                } else {
                    Swal.fire('Failed!', response.message, 'error');
                }
            }).fail(function() {
                Swal.fire('Error!', 'Connection failed. Please try again.', 'error');
            });
        }
    });
}
</script>
<?= $this->endSection() ?>