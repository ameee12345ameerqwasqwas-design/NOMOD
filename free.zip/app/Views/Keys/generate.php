<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<style>
    body {
        background-image: url('<?= base_url('assets/images/backround1.avif') ?>');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        background-color: #2d1b4e;
    }
    
    .card {
        background-color: rgba(93, 63, 159, 0.85) !important;
        backdrop-filter: blur(12px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 15px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        overflow: hidden;
        margin-bottom: 25px;
    }
    
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 40px rgba(0, 0, 0, 0.5);
    }
    
    .card-header {
        background-color: rgba(167, 139, 250, 0.2) !important;
        border-bottom: 1px solid rgba(255, 255, 255, 0.15);
        color: white !important;
        font-weight: 600;
        padding: 16px 25px;
        font-size: 1.1rem;
    }
    
    .card-body {
        padding: 25px;
        color: white;
    }
    
    .form-control, .form-select {
        background-color: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.25);
        color: white !important;
        border-radius: 10px;
        padding: 12px 16px;
        transition: all 0.2s ease;
    }
    
    .form-control:focus, .form-select:focus {
        background-color: rgba(255, 255, 255, 0.15);
        border-color: #a78bfa;
        color: white !important;
        box-shadow: 0 0 0 0.25rem rgba(167, 139, 250, 0.25);
    }
    
    .form-control::placeholder {
        color: rgba(255, 255, 255, 0.6);
        font-size: 14px;
    }
    
    .form-select option {
        background-color: #5d3f9f;
        color: white;
        padding: 10px;
    }
    
    .form-label {
        color: white;
        font-weight: 600;
        font-size: 14px;
        margin-bottom: 8px;
        margin-left: 5px;
    }
    
    .form-label i {
        margin-right: 8px;
        color: #a78bfa;
        font-size: 1.1rem;
    }
    
    .btn-outline-dark {
        color: white;
        border-color: rgba(167, 139, 250, 0.5);
        background: rgba(167, 139, 250, 0.1);
        border-radius: 10px;
        padding: 12px;
        font-weight: 600;
        transition: all 0.3s ease;
    }
    
    .btn-outline-dark:hover {
        background: rgba(167, 139, 250, 0.3);
        color: white;
        border-color: rgba(167, 139, 250, 0.8);
    }
    
    .btn-sm.btn-outline-dark {
        padding: 6px 12px;
        font-size: 14px;
    }
    
    .alert-success {
        background-color: rgba(46, 204, 113, 0.15);
        border: 1px solid rgba(46, 204, 113, 0.3);
        color: #2ecc71;
        border-radius: 10px;
        padding: 20px;
    }
    
    .alert-success strong {
        color: #2ecc71;
    }
    
    .key-sensi {
        filter: blur(5px);
        transition: filter 0.3s ease;
        font-family: monospace;
        font-size: 1rem;
        padding: 3px 8px;
        border-radius: 6px;
        background: rgba(0, 0, 0, 0.2);
        color: #fff;
    }
    
    .key-sensi:hover {
        filter: blur(0);
        background: rgba(0, 0, 0, 0.3);
    }
    
    .form-check-input {
        background-color: rgba(255, 255, 255, 0.1);
        border-color: rgba(255, 255, 255, 0.3);
    }
    
    .form-check-input:checked {
        background-color: #a78bfa;
        border-color: #a78bfa;
    }
    
    .form-check-input:focus {
        box-shadow: 0 0 0 0.25rem rgba(167, 139, 250, 0.25);
    }
    
    .form-check-label {
        color: white;
        font-weight: 500;
        font-size: 14px;
        cursor: pointer;
    }
    
    .form-check-label i {
        color: #a78bfa;
        margin-right: 8px;
    }
    
    .copy-btn {
        cursor: pointer;
        transition: all 0.2s ease;
        font-size: 1.3rem;
        color: rgba(255, 255, 255, 0.7);
        padding: 5px;
        border-radius: 6px;
    }
    
    .copy-btn:hover {
        color: #a78bfa;
        background: rgba(167, 139, 250, 0.1);
    }
    
    .key-display {
        background: rgba(255, 255, 255, 0.1);
        padding: 15px 20px;
        border-radius: 10px;
        margin: 20px 0;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border: 1px solid rgba(255, 255, 255, 0.15);
        font-family: monospace;
        font-size: 1rem;
    }
    
    .key-display strong {
        color: #a78bfa;
        word-break: break-all;
    }
    
    textarea {
        width: 0%;
        height: 0px;
        padding: 0px;
        border: 0;
        background: transparent;
        font-size: 16px;
        resize: none;
        opacity: 0;
    }
    
    .animate-in {
        animation: fadeIn 0.5s ease-out forwards;
        opacity: 0;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .duration-slider-container {
        margin: 20px 0;
        padding: 15px;
        background: rgba(255, 255, 255, 0.08);
        border-radius: 10px;
        border: 1px solid rgba(255, 255, 255, 0.15);
    }
    
    .slider-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
    }
    
    .slider-header h6 {
        color: white;
        margin: 0;
        font-weight: 600;
        font-size: 15px;
    }
    
    .duration-display {
        background: rgba(167, 139, 250, 0.2);
        color: white;
        padding: 6px 12px;
        border-radius: 8px;
        font-weight: 600;
        font-size: 14px;
        min-width: 120px;
        text-align: center;
        border: 1px solid rgba(167, 139, 250, 0.3);
    }
    
    .duration-slider {
        width: 100%;
        height: 8px;
        -webkit-appearance: none;
        appearance: none;
        background: rgba(255, 255, 255, 0.15);
        border-radius: 4px;
        outline: none;
        margin: 10px 0;
    }
    
    .duration-slider::-webkit-slider-thumb {
        -webkit-appearance: none;
        appearance: none;
        width: 20px;
        height: 20px;
        border-radius: 50%;
        background: #a78bfa;
        cursor: pointer;
        border: 2px solid rgba(255, 255, 255, 0.8);
        box-shadow: 0 0 8px rgba(167, 139, 250, 0.5);
        transition: all 0.2s ease;
    }
    
    .duration-slider::-webkit-slider-thumb:hover {
        background: #8b5cf6;
        transform: scale(1.1);
    }
    
    .duration-slider::-moz-range-thumb {
        width: 20px;
        height: 20px;
        border-radius: 50%;
        background: #a78bfa;
        cursor: pointer;
        border: 2px solid rgba(255, 255, 255, 0.8);
        box-shadow: 0 0 8px rgba(167, 139, 250, 0.5);
    }
    
    .duration-presets {
        display: flex;
        justify-content: space-between;
        margin-top: 10px;
        gap: 5px;
    }
    
    .duration-preset {
        color: rgba(255, 255, 255, 0.7);
        font-size: 12px;
        cursor: pointer;
        padding: 6px 8px;
        border-radius: 6px;
        transition: all 0.2s ease;
        text-align: center;
        flex: 1;
        background: rgba(255, 255, 255, 0.05);
    }
    
    .duration-preset:hover {
        color: white;
        background: rgba(255, 255, 255, 0.1);
    }
    
    .duration-preset.active {
        color: #a78bfa;
        font-weight: 600;
        background: rgba(167, 139, 250, 0.2);
        border: 1px solid rgba(167, 139, 250, 0.4);
    }
    
    .text-danger {
        color: #ff6b6b !important;
        font-size: 13px;
        margin-top: 5px;
        display: block;
    }
    
    .text-white-80 {
        color: rgba(255, 255, 255, 0.8);
    }
    
    .bi {
        color: #a78bfa;
    }
    
    #estimation {
        background: rgba(255, 255, 255, 0.1);
        color: #a78bfa;
        font-weight: 600;
        border: 1px solid rgba(255, 255, 255, 0.15);
    }
    
    .form-group {
        margin-bottom: 1.2rem;
    }
    
    .mt-4 {
        margin-top: 1.5rem !important;
    }

    .toggle-switch {
        display: flex;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 10px;
        padding: 5px;
        margin-bottom: 20px;
    }
    .toggle-btn {
        flex: 1;
        text-align: center;
        padding: 8px;
        cursor: pointer;
        border-radius: 8px;
        font-weight: 600;
        transition: 0.3s;
    }
    .toggle-btn.active {
        background: rgba(167, 139, 250, 0.4);
        color: white;
    }
</style>

<div class="row justify-content-center mt-4">
    <div class="col-lg-6">
        <?= $this->include('Layout/msgStatus') ?>
        
        <?php if (session()->getFlashdata('user_key')) : ?>
            <div class="card mb-4 animate-in" style="animation-delay: 0.1s">
                <div class="card-header">
                    <i class="bi bi-check-circle-fill me-2"></i> License Generated Successfully
                </div>
                <div class="card-body">
                    <div class="alert alert-success" role="alert">
                        <div class="mb-3">
                            <strong><i class="bi bi-controller me-2"></i>Game:</strong> 
                            <?= session()->getFlashdata('game') ?> / <?= session()->getFlashdata('duration') ?> Hours
                        </div>
                        <div class="mb-3">
                            <strong><i class="bi bi-key me-2"></i>License:</strong> 
                            <span class="key-sensi"><?= session()->getFlashdata('user_key') ?></span>
                        </div>
                        <div class="mb-3">
                            <strong><i class="bi bi-phone-vibrate-fill me-2"></i>Available for:</strong> 
                            <?= session()->getFlashdata('max_devices') ?> Devices
                        </div>
                        <small class="text-white-80">
                            <i class="bi bi-info-circle me-1"></i>
                            Duration will start when license is activated.
                        </small>
                    </div>
                    
                    <div class="key-display">
                        <strong><?= session()->getFlashdata('user_key') ?></strong>
                        <i class="bi bi-clipboard copy-btn" id="copybtn" onclick="copyText()" title="Copy to clipboard"></i>
                    </div>
                    
                    <textarea name="mytext" id="mytext"><?= session()->getFlashdata('user_key') ?></textarea>
                </div>
            </div>
        <?php endif; ?>
        
        <div class="card animate-in" style="animation-delay: 0.2s">
            <div class="card-header">
                <div class="row align-items-center">
                    <div class="col">
                        <i class="bi bi-key-fill me-2"></i> Create License
                    </div>
                    <div class="col text-end">
                        <a class="btn btn-sm btn-outline-dark d-inline-flex align-items-center" href="<?= site_url('keys') ?>">
                            <i class="bi bi-list-ul me-1"></i> View Keys
                        </a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <?= form_open() ?>

                <div class="row">
                    <div class="form-group col-lg-6 mb-3">
                        <label for="game" class="form-label"><i class="bi bi-controller"></i> Game</label>
                        <?= form_dropdown(['class' => 'form-select', 'name' => 'game', 'id' => 'game'], $game, esc($game_value)) ?>
                    </div>
                    <div class="form-group col-lg-6 mb-3">
                        <label for="max_devices" class="form-label"><i class="bi bi-phone-vibrate-fill"></i> Max Devices</label>
                        <input type="number" name="max_devices" id="max_devices" class="form-control" placeholder="Enter number of devices" value="<?= esc($max_devices_value) ?>" min="1">
                    </div>
                </div>

                <div class="toggle-switch">
                    <div class="toggle-btn active" onclick="showSlider()">Slider</div>
                    <div class="toggle-btn" onclick="showDropdown()">Dropdown</div>
                </div>

                <div id="sliderMode">
                    <div class="form-group mb-3">
                        <label class="form-label"><i class="bi bi-clock-history"></i> Duration (Slider)</label>
                        <div class="duration-slider-container">
                            <div class="slider-header">
                                <h6>Select Duration</h6>
                                <div class="duration-display" id="durationDisplay">1 Day (24 Hours)</div>
                            </div>
                            <input type="range" class="duration-slider" id="durationSlider" min="1" max="365" value="1" oninput="updateFromSlider(this.value)">
                            <div class="duration-presets">
                                <div class="duration-preset active" onclick="setPreset(1)">1 Day</div>
                                <div class="duration-preset" onclick="setPreset(7)">1 Week</div>
                                <div class="duration-preset" onclick="setPreset(30)">1 Month</div>
                                <div class="duration-preset" onclick="setPreset(90)">3 Months</div>
                                <div class="duration-preset" onclick="setPreset(180)">6 Months</div>
                                <div class="duration-preset" onclick="setPreset(365)">1 Year</div>
                            </div>
                        </div>
                    </div>
                </div>

                <div id="dropdownMode" style="display: none;">
                    <div class="form-group mb-3">
                        <label for="duration" class="form-label"><i class="bi bi-calendar-week"></i> Duration (Dropdown)</label>
                        <?= form_dropdown(['class' => 'form-select', 'name' => 'duration', 'id' => 'duration'], $duration, esc($duration_value)) ?>
                    </div>
                </div>

                <input type="hidden" name="slider_duration" id="sliderDuration" value="24">

                <div class="form-check mb-3">
                    <input class="form-check-input" type="checkbox" value="" name="check" onchange="fupi(this)" id="check">
                    <label class="form-check-label d-flex align-items-center" for="check">
                        <i class="bi bi-pencil-square"></i> Custom License Key
                    </label>
                </div>

                <div class="form-group mb-3" id="custom-container" style="display: none;">
                    <label for="custom" class="form-label"><i class="bi bi-keyboard"></i> Input Your Key</label>
                    <input type="text" minlength="4" maxlength="25" name="cuslicense" class="form-control" id="custom" placeholder="Enter custom license key">
                </div>
                
                <div class="form-group mb-3" id="bulk-container">
                    <label for="hulala" class="form-label"><i class="bi bi-collection-play"></i> Bulk Keys</label>         
                    <select class="form-select" id="hulala" name="loopcount">
                        <option value="5">1 Key</option>
                        <option value="1">5 Keys</option>
                        <option value="2">10 Keys</option>
                        <option value="3">25 Keys</option>
                        <option value="4">50 Keys</option>
                        <option value="5">100 Keys</option>
                    </select>
                </div>
                
                <input type="hidden" id="textinput" name="custominput" value="auto">
                
                <div class="form-group mb-4">
                    <label for="estimation" class="form-label"><i class="bi bi-currency-dollar"></i> Estimated Cost</label>
                    <input type="text" id="estimation" class="form-control" placeholder="Calculating..." readonly>
                </div>
                
                <div class="form-group mt-4">
                    <button type="submit" class="btn btn-outline-dark w-100 d-flex justify-content-center align-items-center py-2">
                        <i class="bi bi-sparkle me-2"></i>
                        <span>Generate License</span>
                    </button>
                </div>
                <?= form_close() ?>
            </div>
        </div>
    </div>
</div>

<script>
    function showSlider() {
        document.getElementById('sliderMode').style.display = 'block';
        document.getElementById('dropdownMode').style.display = 'none';
        document.querySelectorAll('.toggle-btn')[0].classList.add('active');
        document.querySelectorAll('.toggle-btn')[1].classList.remove('active');
    }

    function showDropdown() {
        document.getElementById('sliderMode').style.display = 'none';
        document.getElementById('dropdownMode').style.display = 'block';
        document.querySelectorAll('.toggle-btn')[0].classList.remove('active');
        document.querySelectorAll('.toggle-btn')[1].classList.add('active');
        updateSliderFromDropdown();
    }

    function updateFromSlider(days) {
        const hours = days * 24;
        document.getElementById('sliderDuration').value = hours;
        document.getElementById('durationDisplay').textContent = days + (days > 1 ? " Days" : " Day") + " (" + hours + " Hours)";
        updateDropdownFromSlider(hours);
        updateEstimation();
    }

    function updateDropdownFromSlider(hours) {
        const dropdown = document.getElementById('duration');
        let closest = dropdown.options[0];
        let minDiff = Math.abs(hours - parseInt(dropdown.options[0].value));
        for (let opt of dropdown.options) {
            let diff = Math.abs(hours - parseInt(opt.value));
            if (diff < minDiff) {
                minDiff = diff;
                closest = opt;
            }
        }
        dropdown.value = closest.value;
    }

    function updateSliderFromDropdown() {
        const hours = parseInt(document.getElementById('duration').value) || 24;
        const days = Math.round(hours / 24);
        document.getElementById('durationSlider').value = days;
        document.getElementById('sliderDuration').value = hours;
        document.getElementById('durationDisplay').textContent = days + (days > 1 ? " Days" : " Day") + " (" + hours + " Hours)";
        updateEstimation();
    }

    function setPreset(days) {
        document.getElementById('durationSlider').value = days;
        updateFromSlider(days);
        document.querySelectorAll('.duration-preset').forEach(p => p.classList.remove('active'));
        event.target.classList.add('active');
    }

    function updateEstimation() {
        const devices = parseInt(document.getElementById('max_devices').value) || 1;
        const hours = parseInt(document.getElementById('sliderDuration').value) || 24;
        const days = Math.ceil(hours / 24);
        const total = (devices * 80 * days).toFixed(2);
        document.getElementById('estimation').value = '$' + total;
    }

    function copyText() {
        const txt = document.getElementById("mytext");
        txt.select();
        document.execCommand("copy");
        const btn = document.getElementById("copybtn");
        const old = btn.className;
        btn.className = "bi bi-clipboard-check copy-btn";
        btn.style.color = "#2ecc71";
        setTimeout(() => {
            btn.className = old;
            btn.style.color = "";
        }, 2000);
    }

    function fupi(obj) {
        if ($(obj).is(":checked")) {
            document.getElementById("custom-container").style.display = "block";
            document.getElementById("bulk-container").style.display = "none";
            document.getElementById("textinput").value = "custom";
        } else {
            document.getElementById("custom-container").style.display = "none";
            document.getElementById("bulk-container").style.display = "block";
            document.getElementById("textinput").value = "auto";
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        document.getElementById("custom-container").style.display = "none";
        updateEstimation();
    });

    document.getElementById('duration').addEventListener('change', updateSliderFromDropdown);
    document.getElementById('max_devices').addEventListener('input', updateEstimation);
</script>

<?= $this->endSection() ?>