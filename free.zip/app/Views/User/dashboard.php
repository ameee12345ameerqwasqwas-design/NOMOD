<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>

<style>
    body {
        background-image: url('<?= base_url('assets/images/backround1.avif') ?>');
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        background-color: #2d1b4e;
        font-family: 'Poppins', sans-serif;
    }
    
    .dashboard-container {
        padding: 20px;
    }
    
    .card {
        background-color: rgba(93, 63, 159, 0.7) !important;
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 15px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        transition: all 0.3s ease;
        overflow: hidden;
        margin-bottom: 25px;
    }
    
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 40px rgba(0, 0, 0, 0.4);
    }
    
    .card-header {
        background-color: rgba(93, 63, 159, 0.4) !important;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        color: white !important;
        font-weight: 600;
        font-size: 1.2rem;
        padding: 15px 20px;
        text-align: center;
    }
    
    .card-body {
        padding: 20px;
        color: white;
    }
    
    #exp {
        font-family: 'Nova Mono', monospace;
        text-align: center;
        color: #fff;
        font-size: 3rem;
        text-shadow: 0px 0px 20px #a78bfa;
        margin: 0;
        animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
        0% { opacity: 1; }
        50% { opacity: 0.7; }
        100% { opacity: 1; }
    }
    
    .list-group-item {
        background-color: rgba(93, 63, 159, 0.3);
        border: 1px solid rgba(255, 255, 255, 0.1);
        color: white;
        transition: all 0.3s ease;
        padding: 12px 20px;
        margin-bottom: 5px;
        border-radius: 8px;
    }
    
    .list-group-item:hover {
        background-color: rgba(93, 63, 159, 0.5);
        transform: translateX(5px);
    }
    
    .badge {
        padding: 8px 15px;
        border-radius: 50px;
        font-weight: 500;
        font-size: 0.85rem;
    }
    
    .badge.text-success {
        background-color: rgba(40, 167, 69, 0.2);
        color: #4ade80 !important;
    }
    
    .badge.text-danger {
        background-color: rgba(220, 53, 69, 0.2);
        color: #f87171 !important;
    }
    
    .badge.text-primary {
        background-color: rgba(13, 110, 253, 0.2);
        color: #60a5fa !important;
    }
    
    .badge.text-dark {
        background-color: rgba(255, 255, 255, 0.2);
        color: white !important;
    }
    
    .badge.text-muted {
        background-color: rgba(108, 117, 125, 0.2);
        color: #d1d5db !important;
    }
    
    .table {
        color: white;
    }
    
    .table-bordered {
        border-color: rgba(255, 255, 255, 0.1);
    }
    
    .table-hover tbody tr:hover {
        background-color: rgba(255, 255, 255, 0.1);
    }
    
    .stat-card {
        text-align: center;
        padding: 15px;
    }
    
    .stat-icon {
        font-size: 2.5rem;
        margin-bottom: 15px;
        color: #a78bfa;
        animation: float 3s ease-in-out infinite;
    }
    
    @keyframes float {
        0% { transform: translateY(0px); }
        50% { transform: translateY(-10px); }
        100% { transform: translateY(0px); }
    }
    
    .stat-value {
        font-size: 2.5rem;
        font-weight: bold;
        margin-bottom: 5px;
        background: linear-gradient(45deg, #a78bfa, #60a5fa);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }
    
    .stat-label {
        font-size: 1rem;
        opacity: 0.8;
        text-transform: uppercase;
        letter-spacing: 1px;
    }
    
    .animate-in {
        animation: fadeIn 0.5s ease-out forwards;
        opacity: 0;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .cyber-card {
        background-color: rgba(93, 63, 159, 0.7) !important;
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 15px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        transition: all 0.3s ease;
        overflow: hidden;
        margin-bottom: 25px;
        height: auto;
    }
    
    .cyber-header {
        background-color: rgba(93, 63, 159, 0.4) !important;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        color: white !important;
        font-weight: 600;
        font-size: 1.2rem;
        padding: 15px 20px;
        text-align: center;
    }
    
    .cyber-list-item {
        background-color: rgba(93, 63, 159, 0.3);
        border: 1px solid rgba(255, 255, 255, 0.1);
        color: white;
        transition: all 0.3s ease;
        padding: 12px 20px;
        margin-bottom: 5px;
        border-radius: 8px;
    }
    
    .cyber-list-item:hover {
        background-color: rgba(93, 63, 159, 0.5);
        transform: translateX(5px);
    }
    
    .cyber-badge {
        padding: 8px 15px;
        border-radius: 50px;
        font-weight: 500;
        font-size: 0.85rem;
        min-width: 80px;
        text-align: center;
    }
    
    .cyber-badge-danger {
        background-color: rgba(220, 53, 69, 0.2);
        color: #f87171 !important;
    }
    
    .cyber-badge-warning {
        background-color: rgba(255, 193, 7, 0.2);
        color: #ffd54f !important;
    }
    
    .cyber-badge-success {
        background-color: rgba(40, 167, 69, 0.2);
        color: #4ade80 !important;
    }
    
    .cyber-badge-info {
        background-color: rgba(23, 162, 184, 0.2);
        color: #4dc0e4 !important;
    }

    @media (max-width: 992px) {
        .top-dashboard-card {
            margin-bottom: 20px;
        }
    }

    @media (max-width: 768px) {
        .dashboard-container {
            padding: 15px;
        }
        #exp { 
            font-size: 2.2rem !important; 
        }
        .stat-value { 
            font-size: 2rem !important; 
        }
        .cyber-header {
            font-size: 1.1rem;
        }
        .cyber-list-item {
            padding: 10px 15px;
            font-size: 0.95rem;
        }
        .cyber-badge h5 {
            font-size: 1.3rem !important;
        }
        .chart-container {
            height: 220px !important;
        }
    }

    @media (max-width: 576px) {
        .dashboard-container {
            padding: 10px;
        }
        #exp { 
            font-size: 1.8rem !important; 
        }
        .cyber-badge {
            padding: 6px 12px;
            font-size: 0.8rem;
        }
        .cyber-badge h5 {
            font-size: 1.2rem !important;
        }
        .table {
            font-size: 0.85rem;
        }
    }
</style>

<div class="dashboard-container">
    <div class="row g-4">

        <!-- SYSTEM STATS -->
        <div class="col-lg-4 col-md-6 col-12 top-dashboard-card">
            <div class="cyber-card">
                <div class="cyber-header">
                    <i class="fas fa-database"></i> SYSTEM STATS
                </div>
                <div class="card-body">
                    <ul class="list-group mb-3">
                        <li class="cyber-list-item d-flex justify-content-between align-items-center">
                            <i class="fas fa-key"></i> TOTAL KEYS
                            <span class="cyber-badge cyber-badge-danger">
                                <h5><?= esc($total_keys) ?></h5>
                            </span>
                        </li>
                        <li class="cyber-list-item d-flex justify-content-between align-items-center">
                            <i class="fas fa-rocket"></i> ACTIVATED
                            <span class="cyber-badge cyber-badge-warning">
                                <h5><?= esc($activated_keys) ?></h5>
                            </span>
                        </li>
                        <li class="cyber-list-item d-flex justify-content-between align-items-center">
                            <i class="fas fa-battery-half"></i> INACTIVE
                            <span class="cyber-badge cyber-badge-warning">
                                <h5><?= esc($inactive_keys) ?></h5>
                            </span>
                        </li>
                        <li class="cyber-list-item d-flex justify-content-between align-items-center">
                            <i class="fas fa-users"></i> USERS ONLINE
                            <span class="cyber-badge cyber-badge-success">
                                <h5><?= esc($total_users) ?></h5>
                            </span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- USER PROFILE -->
        <div class="col-lg-4 col-md-6 col-12 top-dashboard-card">
            <div class="cyber-card">
                <div class="cyber-header">
                    <i class="fas fa-user-astronaut"></i> USER PROFILE
                </div>
                <div class="card-body">
                    <ul class="list-group mb-3">
                        <li class="cyber-list-item d-flex justify-content-between align-items-center">
                            <i class="fas fa-user-shield"></i> CLEARANCE
                            <span class="cyber-badge cyber-badge-danger">
                                <?= getLevel($user->level) ?>
                            </span>
                        </li>
                        <li class="cyber-list-item d-flex justify-content-between align-items-center">
                            <i class="fas fa-coins"></i> CREDITS
                            <span class="cyber-badge cyber-badge-warning">
                                $<?= esc($user->saldo) ?>
                            </span>
                        </li>
                        <li class="cyber-list-item d-flex justify-content-between align-items-center">
                            <i class="fas fa-clock"></i> SESSION START
                            <span class="cyber-badge cyber-badge-success">
                                <?= $time::parse(session()->time_since)->humanize() ?>
                            </span>
                        </li>
                        <li class="cyber-list-item d-flex justify-content-between align-items-center">
                            <i class="fas fa-hourglass-end"></i> SESSION END
                            <span class="cyber-badge cyber-badge-info">
                                <?= $time::now()->difference($time::parse(session()->time_login))->humanize() ?>
                            </span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- NETWORK TERMINAL + VISITOR LOGS -->
        <div class="col-lg-4 col-md-12 col-12 top-dashboard-card">
            <div class="d-flex flex-column gap-4">
                <div class="cyber-card">
                    <div class="cyber-header">
                        <i class="fas fa-network-wired"></i> NETWORK TERMINAL
                    </div>
                    <div class="card-body">
                        <ul class="list-group">
                            <li class="cyber-list-item d-flex justify-content-between align-items-center">
                                <i class="fas fa-globe"></i> NODE ADDRESS
                                <span class="cyber-badge cyber-badge-danger">
                                    <h5 id="cyber-ip"><?= esc($user_ip) ?></h5>
                                </span>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="cyber-card">
                    <div class="cyber-header">
                        <i class="fas fa-chart-network"></i> VISITOR LOGS
                    </div>
                    <div class="card-body">
                        <ul class="list-group">
                            <li class="cyber-list-item d-flex justify-content-between align-items-center">
                                <i class="fas fa-eye"></i> VISITORS
                                <span class="cyber-badge cyber-badge-danger">
                                    <h5 id="cyber-counter"><?= esc($visit_count) ?></h5>
                                </span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4 mt-3">
        <!-- History Card -->
        <div class="col-lg-8 col-12 animate-in" style="animation-delay: 0.7s">
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-clock-history me-2"></i> History
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm table-bordered table-hover text-center">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Info</th>
                                    <th>Code</th>
                                    <th>Duration</th>
                                    <th>Devices</th>
                                    <th>Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($history as $h) : ?>
                                <tr>
                                    <td><span class="align-middle badge text-dark">#3812<?= esc($h['id_history']) ?></span></td>
                                    <td><?= esc($h['game']) ?></td>
                                    <td><span class="align-middle badge text-dark"><?= esc($h['code']) ?>**</span></td>
                                    <td><span class="align-middle badge text-dark"><?= esc($h['duration_formatted']) ?></span></td>
                                    <td><span class="align-middle badge text-primary"><?= esc($h['devices']) ?> Devices</span></td>
                                    <td><i class="align-middle badge text-muted"><?= esc($h['time_human']) ?></i></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Activity Chart -->
        <div class="col-lg-4 col-12 animate-in" style="animation-delay: 0.8s">
            <div class="card">
                <div class="card-header">
                    <i class="bi bi-activity me-2"></i> Activity
                </div>
                <div class="card-body">
                    <div class="chart-container" style="position: relative; height: 250px;">
                        <canvas id="activityChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>

    document.addEventListener('DOMContentLoaded', function() {
        const animatedElements = document.querySelectorAll('.animate-in');
        animatedElements.forEach(element => {
            element.style.animationPlayState = 'running';
        });
        
        const activityCtx = document.getElementById('activityChart').getContext('2d');
        const activityChart = new Chart(activityCtx, {
            type: 'doughnut',
            data: {
                labels: ['Used Keys', 'Unused Keys'],
                datasets: [{
                    data: [<?= esc($activated_keys) ?>, <?= esc($inactive_keys) ?>],
                    backgroundColor: [
                        'rgba(74, 222, 128, 0.8)',
                        'rgba(248, 113, 113, 0.8)'
                    ],
                    borderColor: [
                        'rgba(74, 222, 128, 1)',
                        'rgba(248, 113, 113, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: 'white',
                            padding: 20
                        }
                    }
                },
                cutout: '70%'
            }
        });
    });
</script>

<?= $this->endSection() ?>