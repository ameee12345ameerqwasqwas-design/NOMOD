<?php

namespace App\Models;

use CodeIgniter\Model;

class LibCounterModel extends Model
{
    protected $table         = 'lib_counters';
    protected $primaryKey    = 'id';
    protected $allowedFields = [
        'lib_name',
        'package_name',
        'unique_code',
        'status',
        'max_uses',
        'current_uses',
        'note',
    ];
    protected $useTimestamps = true;

    public function getByPackage(string $packageName): ?object
    {
        return $this->where('package_name', $packageName)
                    ->where('status', 1)
                    ->get()
                    ->getRowObject();
    }

    public function getByCode(string $code): ?object
    {
        return $this->where('unique_code', $code)->get()->getRowObject();
    }

    public function verifyLib(string $packageName, string $code): array
    {
        $row = $this->where('package_name', $packageName)
                    ->where('unique_code', $code)
                    ->where('status', 1)
                    ->get()
                    ->getRowObject();

        if (!$row) {
            return ['valid' => false, 'reason' => 'Package or code not registered'];
        }

        if ($row->max_uses > 0 && $row->current_uses >= $row->max_uses) {
            return ['valid' => false, 'reason' => 'Max uses reached'];
        }

        $this->update($row->id, ['current_uses' => $row->current_uses + 1]);

        return [
            'valid'        => true,
            'lib_name'     => $row->lib_name,
            'package_name' => $row->package_name,
            'uses'         => $row->current_uses + 1,
            'max_uses'     => $row->max_uses,
        ];
    }

    public function generateUniqueCode(): string
    {
        do {
            $code = strtoupper(bin2hex(random_bytes(8))) . '-' . strtoupper(bin2hex(random_bytes(4)));
        } while ($this->where('unique_code', $code)->countAllResults() > 0);

        return $code;
    }

    public function getStats(): array
    {
        $db    = \Config\Database::connect();
        $total = $this->countAll();
        $active = $this->where('status', 1)->countAllResults(false);
        $totalUses = $db->table($this->table)->selectSum('current_uses')->get()->getRowArray()['current_uses'] ?? 0;

        return [
            'total'       => $total,
            'active'      => $active,
            'inactive'    => $total - $active,
            'total_uses'  => (int) $totalUses,
        ];
    }
}
