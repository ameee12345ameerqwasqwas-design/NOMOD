<?php

namespace App\Models;

use CodeIgniter\Model;

class GamesModel extends Model
{
    protected $table = 'games';
    protected $primaryKey = 'id';
    protected $allowedFields = ['game_code', 'game_name', 'status'];
    protected $useTimestamps = false;
    
    public function getActiveGames()
    {
        return $this->where('status', 1)->findAll();
    }
}