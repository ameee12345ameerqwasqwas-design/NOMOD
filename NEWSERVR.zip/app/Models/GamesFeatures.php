<?php

namespace App\Models;

use CodeIgniter\Model;

class GamesFeatures extends Model
{
    protected $table = 'games_features';
    protected $primaryKey = 'id';
    protected $allowedFields = ['game', 'ESP', 'Item', 'AIM', 'SilentAim', 'BulletTrack', 'Memory', 'Floating', 'Setting', 'status', 'maintenance_mode', 'maintenance_message'];
    protected $returnType = 'array';
    protected $useTimestamps = false;
}