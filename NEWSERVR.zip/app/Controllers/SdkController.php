<?php

namespace App\Controllers;

class SdkController extends BaseController
{
    public function index()
    {
        if (!session()->has('userid')) {
            return redirect()->to(base_url('login'));
        }
        $userModel = new \App\Models\UserModel();
        $user = $userModel->getUser(session()->userid);
        $data = ['title' => 'SDK / Server Library', 'user' => $user];
        return view('sdk/index', $data);
    }
}
