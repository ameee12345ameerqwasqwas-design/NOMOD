<?php

namespace App\Controllers;

use App\Models\UserModel;

class FileManager extends BaseController
{
    protected $user;
    protected $uploadDir;
    protected $allowedExtensions = ['so', 'zip', 'json', 'apk'];
    protected $maxFileSize = 1073741824;

    public function __construct()
    {
        if (!session()->has('userid')) {
            return redirect()->to(base_url('login'))->with('error', 'Please login first.');
        }

        $userModel = new UserModel();
        $this->user = $userModel->getUser(session()->userid);
        
        $username = $this->user->username;
        
        $this->uploadDir = FCPATH . 'bypass/' . $username . '/';
        
        if (!file_exists($this->uploadDir)) {
            mkdir($this->uploadDir, 0777, true);
        }
        
        $this->cleanupExpiredFiles();
    }

    public function index()
    {
        $data = [
            'title' => 'File Manager',
            'user' => $this->user,
            'files' => $this->getUploadedFiles()
        ];
        
        return view('file_manager/index', $data);
    }

    public function upload()
    {
        if (!$this->request->isAJAX()) {
            return $this->response->setStatusCode(400)->setJSON([
                'success' => false,
                'message' => 'Invalid request method'
            ]);
        }

        if (!session()->has('userid')) {
            return $this->response->setStatusCode(403)->setJSON([
                'success' => false,
                'message' => 'Unauthorized access'
            ]);
        }

        $files = $this->request->getFiles();
        $expiration = $this->request->getPost('expiration');
        
        if (empty($files['fileToUpload']) || !$files['fileToUpload'][0]->isValid()) {
            return $this->response->setStatusCode(400)->setJSON([
                'success' => false,
                'message' => 'No valid files were uploaded'
            ]);
        }

        $uploadedFiles = [];
        $errors = [];

        foreach ($files['fileToUpload'] as $file) {
            if (!$file->isValid()) {
                $errors[] = $file->getErrorString();
                continue;
            }

            $allowedExtensions = ['so', 'json', 'zip', 'apk'];
            $extension = $file->getClientExtension();
            
            if (!in_array($extension, $allowedExtensions)) {
                $errors[] = 'Invalid file type for ' . $file->getClientName() . '. Only .so, .json, .zip, and .apk files are allowed.';
                continue;
            }

            $maxSize = 1024 * 1024 * 1024;
            if ($file->getSize() > $maxSize) {
                $errors[] = 'File size exceeds the maximum limit of 1GB for ' . $file->getClientName();
                continue;
            }

            $filename = preg_replace('/[^a-zA-Z0-9\.\-]/', '', $file->getClientName());

            if (!is_dir($this->uploadDir)) {
                if (!mkdir($this->uploadDir, 0755, true)) {
                    $errors[] = 'Failed to create upload directory. Check permissions.';
                    continue;
                }
            }

            $targetPath = $this->uploadDir . $filename;
            if (file_exists($targetPath)) {
                if (!unlink($targetPath)) {
                    $errors[] = 'Failed to replace existing file: ' . $filename;
                    continue;
                }
            }

            try {
                $file->move($this->uploadDir, $filename);
                
                if (!file_exists($this->uploadDir . $filename)) {
                    throw new \Exception('File move operation failed');
                }
                
                $this->saveExpirationTime($filename, $expiration);
                $uploadedFiles[] = $filename;
                
            } catch (\Exception $e) {
                $errors[] = 'Failed to save file ' . $filename . ': ' . $e->getMessage();
            }
        }

        if (!empty($errors)) {
            return $this->response->setStatusCode(400)->setJSON([
                'success' => false,
                'message' => 'Some files failed to upload: ' . implode(', ', $errors)
            ]);
        }

        return $this->response->setJSON([
            'success' => true,
            'message' => count($uploadedFiles) . ' file(s) uploaded successfully.',
            'uploaded_files' => $uploadedFiles
        ]);
    }

    public function delete()
    {
        if (!$this->request->isAJAX()) {
            return $this->response->setStatusCode(403)->setJSON([
                'success' => false,
                'message' => 'Invalid request method'
            ]);
        }

        $filename = $this->request->getPost('filename');
        
        if (empty($filename)) {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'Filename is required'
            ]);
        }

        $filePath = $this->uploadDir . $filename;
        
        $expirationFile = $this->uploadDir . $filename . '.expiration';
        if (file_exists($expirationFile)) {
            unlink($expirationFile);
        }
        
        if (file_exists($filePath)) {
            if (unlink($filePath)) {
                return $this->response->setJSON([
                    'success' => true,
                    'message' => 'File deleted successfully.'
                ]);
            } else {
                return $this->response->setJSON([
                    'success' => false,
                    'message' => 'Unable to delete the file.'
                ]);
            }
        } else {
            return $this->response->setJSON([
                'success' => false,
                'message' => 'File not found.'
            ]);
        }
    }

    public function editJson($filename)
    {
        if (strpos($filename, '..') !== false) {
            return redirect()->to(base_url('file-manager'))->with('msgDanger', 'Invalid file path.');
        }

        $filePath = $this->uploadDir . $filename;
        
        if (!file_exists($filePath) || pathinfo($filePath, PATHINFO_EXTENSION) !== 'json') {
            return redirect()->to(base_url('file-manager'))->with('msgDanger', 'JSON file not found.');
        }

        $data = json_decode(file_get_contents($filePath), true);
        if (!is_array($data)) {
            $data = [];
        }

        if ($this->request->getMethod() === 'post') {
            foreach ($data as $key => $_) {
                if ($this->request->getPost($key) !== null) {
                    $data[$key] = $this->request->getPost($key);
                }
            }
            
            file_put_contents($filePath, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            return redirect()->to(base_url('file-manager'))->with('msgSuccess', 'JSON file updated successfully.');
        }

        $viewData = [
            'title' => 'Edit JSON - ' . $filename,
            'user' => $this->user,
            'filename' => $filename,
            'filePath' => $filePath,
            'jsonData' => $data
        ];

        return view('file_manager/edit_json', $viewData);
    }

    public function download($filename)
    {
        $filePath = $this->uploadDir . $filename;
        
        if (file_exists($filePath)) {
            return $this->response->download($filePath, null)->setFileName($filename);
        } else {
            return redirect()->to(base_url('file-manager'))->with('msgDanger', 'File not found.');
        }
    }

    private function getUploadedFiles()
    {
        $files = [];
        
        if (is_dir($this->uploadDir)) {
            $fileList = scandir($this->uploadDir);
            foreach ($fileList as $file) {
                if ($file != '.' && $file != '..' && !str_ends_with($file, '.expiration')) {
                    $filePath = $this->uploadDir . $file;
                    $fileExt = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                    
                    if (in_array($fileExt, $this->allowedExtensions)) {
                        $username = $this->user->username;
                        $directLink = base_url('bypass/' . $username . '/' . urlencode($file));
                        
                        $expirationInfo = $this->getExpirationInfo($file);
                        
                        $files[] = [
                            'name' => $file,
                            'size' => $this->formatFileSize(filesize($filePath)),
                            'uploaded_at' => date("Y-m-d H:i:s", filectime($filePath)),
                            'download_link' => base_url('file-manager/download/' . urlencode($file)),
                            'direct_link' => $directLink,
                            'edit_link' => $fileExt === 'json' ? base_url('file-manager/edit-json/' . urlencode($file)) : null,
                            'expiration' => $expirationInfo['expiration'],
                            'time_left' => $expirationInfo['time_left'],
                            'delete_date' => $expirationInfo['delete_date']
                        ];
                    }
                }
            }
        }
        
        usort($files, function($a, $b) {
            return strtotime($b['uploaded_at']) - strtotime($a['uploaded_at']);
        });
        
        return $files;
    }

    private function formatFileSize($bytes)
    {
        $units = ['bytes', 'KB', 'MB', 'GB'];
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        
        $bytes /= (1 << (10 * $pow));
        
        return round($bytes, 2) . ' ' . $units[$pow];
    }

    private function saveExpirationTime($filename, $expiration)
    {
        $expirationFile = $this->uploadDir . $filename . '.expiration';
        
        if ($expiration === 'unlimited') {
            if (file_exists($expirationFile)) {
                unlink($expirationFile);
            }
            return;
        }
        
        $expirationTime = 0;
        switch ($expiration) {
            case '1hour':
                $expirationTime = time() + 3600;
                break;
            case '2hours':
                $expirationTime = time() + 7200;
                break;
            case '1day':
                $expirationTime = time() + 86400;
                break;
            case '3days':
                $expirationTime = time() + 259200;
                break;
            case '7days':
                $expirationTime = time() + 604800;
                break;
            case '15days':
                $expirationTime = time() + 1296000;
                break;
            case '30days':
                $expirationTime = time() + 2592000;
                break;
            case '60days':
                $expirationTime = time() + 5184000;
                break;
            default:
                $expirationTime = 0;
        }
        
        if ($expirationTime > 0) {
            file_put_contents($expirationFile, $expirationTime);
        }
    }

    private function getExpirationInfo($filename)
    {
        $expirationFile = $this->uploadDir . $filename . '.expiration';
        
        if (!file_exists($expirationFile)) {
            return [
                'expiration' => 'Unlimited',
                'time_left' => 'Never',
                'delete_date' => 'Never'
            ];
        }
        
        $expirationTime = (int)file_get_contents($expirationFile);
        $currentTime = time();
        
        if ($currentTime >= $expirationTime) {
            $filePath = $this->uploadDir . $filename;
            if (file_exists($filePath)) {
                unlink($filePath);
                unlink($expirationFile);
            }
            return [
                'expiration' => 'Expired',
                'time_left' => 'File deleted',
                'delete_date' => 'Already deleted'
            ];
        }
        
        $timeLeft = $expirationTime - $currentTime;
        
        $days = floor($timeLeft / 86400);
        $hours = floor(($timeLeft % 86400) / 3600);
        $minutes = floor(($timeLeft % 3600) / 60);
        $seconds = $timeLeft % 60;
        
        $timeLeftString = '';
        if ($days > 0) {
            $timeLeftString .= $days . ' days ';
        }
        if ($hours > 0) {
            $timeLeftString .= $hours . ' hours ';
        }
        if ($minutes > 0) {
            $timeLeftString .= $minutes . ' minutes ';
        }
        if ($seconds > 0 && $days === 0) {
            $timeLeftString .= $seconds . ' seconds';
        }
        
        if (empty($timeLeftString)) {
            $timeLeftString = 'Less than 1 second';
        }
        
        return [
            'expiration' => date('Y-m-d H:i:s', $expirationTime),
            'time_left' => trim($timeLeftString),
            'delete_date' => date('Y-m-d H:i:s', $expirationTime)
        ];
    }

    public function cleanupExpiredFiles()
    {
        if (is_dir($this->uploadDir)) {
            $fileList = scandir($this->uploadDir);
            foreach ($fileList as $file) {
                if ($file != '.' && $file != '..' && str_ends_with($file, '.expiration')) {
                    $filename = str_replace('.expiration', '', $file);
                    $this->getExpirationInfo($filename);
                }
            }
        }
    }
}