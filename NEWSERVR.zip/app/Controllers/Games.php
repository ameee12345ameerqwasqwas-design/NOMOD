<?php

namespace App\Controllers;

use App\Models\GamesModel;
use Config\Services;

class Games extends BaseController
{
    protected $gamesModel;
    protected $user;

    public function __construct()
    {
        $this->gamesModel = new GamesModel();
        $userModel = new \App\Models\UserModel();
        $this->user = $userModel->getUser();
    }

    public function index()
    {
        $db = \Config\Database::connect();
        
        // إذا كان المستخدم مسؤول (Level 1) يظهر كل الألعاب
        if ($this->user->level == 1) {
            $games = $this->gamesModel->findAll();
        } else {
            // إذا كان مستخدم عادي، يظهر فقط الألعاب المرتبطة به
            $builder = $db->table('games g');
            $builder->select('g.*');
            $builder->join('user_games ug', 'ug.game_id = g.id', 'inner');
            $builder->where('ug.user_id', $this->user->id_users);
            $games = $builder->get()->getResultArray();
        }
        
        $data = [
            'title' => 'Games Management',
            'user' => $this->user,
            'games' => $games,
            'validation' => Services::validation()
        ];
        
        return view('games/index', $data);
    }

    public function create()
    {
        if ($this->request->getMethod() === 'post') {
            return $this->createAction();
        }
        
        $data = [
            'title' => 'Add New Game',
            'user' => $this->user,
            'validation' => Services::validation()
        ];
        
        return view('games/create', $data);
    }

    private function createAction()
    {
        $rules = [
            'game_code' => [
                'label' => 'Game Code',
                'rules' => 'required|alpha_numeric|max_length[32]|is_unique[games.game_code]',
                'errors' => [
                    'is_unique' => 'Game code already exists'
                ]
            ],
            'game_name' => [
                'label' => 'Game Name',
                'rules' => 'required|max_length[100]'
            ],
            'status' => [
                'label' => 'Status',
                'rules' => 'required|in_list[0,1]'
            ]
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('msgDanger', 'Please check the errors');
        }

        $data = [
            'game_code' => $this->request->getPost('game_code'),
            'game_name' => $this->request->getPost('game_name'),
            'status' => $this->request->getPost('status'),
            'created_by' => $this->user->id_users,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $this->gamesModel->insert($data);
        $gameId = $this->gamesModel->getInsertID();
        
        // ✅ Add relationship between user and game
        $db = \Config\Database::connect();
        $db->table('user_games')->insert([
            'user_id' => $this->user->id_users,
            'game_id' => $gameId
        ]);
        
        return redirect()->to('/games')->with('msgSuccess', 'Game added successfully');
    }

    public function edit($id)
    {
        $db = \Config\Database::connect();
        
        // Check if user has access to this game
        if ($this->user->level != 1) {
            $checkAccess = $db->table('user_games')
                ->where('user_id', $this->user->id_users)
                ->where('game_id', $id)
                ->countAllResults();
                
            if ($checkAccess == 0) {
                return redirect()->to('/games')->with('msgDanger', 'You do not have permission to edit this game');
            }
        }
        
        $game = $this->gamesModel->find($id);
        
        if (!$game) {
            return redirect()->to('/games')->with('msgDanger', 'Game not found');
        }
        
        if ($this->request->getMethod() === 'post') {
            return $this->editAction($id);
        }
        
        $data = [
            'title' => 'Edit Game',
            'user' => $this->user,
            'game' => $game,
            'validation' => Services::validation()
        ];
        
        return view('games/edit', $data);
    }

    private function editAction($id)
    {
        $game = $this->gamesModel->find($id);
        
        if (!$game) {
            return redirect()->to('/games')->with('msgDanger', 'Game not found');
        }
        
        $rules = [
            'game_code' => [
                'label' => 'Game Code',
                'rules' => "required|alpha_numeric|max_length[32]|is_unique[games.game_code,id,{$id}]",
                'errors' => [
                    'is_unique' => 'Game code already exists'
                ]
            ],
            'game_name' => [
                'label' => 'Game Name',
                'rules' => 'required|max_length[100]'
            ],
            'status' => [
                'label' => 'Status',
                'rules' => 'required|in_list[0,1]'
            ]
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('msgDanger', 'Please check the errors');
        }

        $data = [
            'game_code' => $this->request->getPost('game_code'),
            'game_name' => $this->request->getPost('game_name'),
            'status' => $this->request->getPost('status'),
            'updated_at' => date('Y-m-d H:i:s')
        ];

        $this->gamesModel->update($id, $data);
        
        return redirect()->to('/games')->with('msgSuccess', 'Game updated successfully');
    }

    public function delete($id)
    {
        $db = \Config\Database::connect();
        
        // Check if user has access to this game
        if ($this->user->level != 1) {
            $checkAccess = $db->table('user_games')
                ->where('user_id', $this->user->id_users)
                ->where('game_id', $id)
                ->countAllResults();
                
            if ($checkAccess == 0) {
                return redirect()->to('/games')->with('msgDanger', 'You do not have permission to delete this game');
            }
        }
        
        $game = $this->gamesModel->find($id);
        
        if (!$game) {
            return redirect()->to('/games')->with('msgDanger', 'Game not found');
        }
        
        // Delete from user_games first
        $db->table('user_games')->where('game_id', $id)->delete();
        
        // Then delete the game
        $this->gamesModel->delete($id);
        
        return redirect()->to('/games')->with('msgSuccess', 'Game deleted successfully');
    }

    public function toggleStatus($id)
    {
        $db = \Config\Database::connect();
        
        // Check if user has access to this game
        if ($this->user->level != 1) {
            $checkAccess = $db->table('user_games')
                ->where('user_id', $this->user->id_users)
                ->where('game_id', $id)
                ->countAllResults();
                
            if ($checkAccess == 0) {
                return redirect()->to('/games')->with('msgDanger', 'You do not have permission to modify this game');
            }
        }
        
        $game = $this->gamesModel->find($id);
        
        if (!$game) {
            return redirect()->to('/games')->with('msgDanger', 'Game not found');
        }
        
        $newStatus = $game['status'] == 1 ? 0 : 1;
        
        $this->gamesModel->update($id, ['status' => $newStatus]);
        
        $statusText = $newStatus == 1 ? 'enabled' : 'disabled';
        
        return redirect()->to('/games')->with('msgSuccess', "Game {$statusText} successfully");
    }
}