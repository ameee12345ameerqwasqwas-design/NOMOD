<?php

$dotenvPath = __DIR__ . '/../../.env';
if (file_exists($dotenvPath)) {
    $lines = file($dotenvPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '=') !== false) {
            list($name, $value) = explode('=', $line, 2);
            $name = trim($name);
            $value = trim($value, " '\"");
            if (!getenv($name)) {
                putenv("$name=$value");
            }
        }
    }
}

$servername = getenv('database.default.hostname');
$username   = getenv('database.default.username');
$password   = getenv('database.default.password');
$dbname     = getenv('database.default.database');

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("PROBLEM WITH CONNECTION: " . mysqli_connect_error());
}

?>