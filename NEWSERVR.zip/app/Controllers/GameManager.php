<?php

namespace App\Controllers;

use App\Models\GamesModel;
use Config\Services;

class GameManager extends BaseController
{
    protected $gamesModel;

    public function __construct()
    {
        $this->gamesModel = new GamesModel();
    }

    public function index()
    {
        $userModel = new \App\Models\UserModel();
        $user = $userModel->getUser();
        
        // صلاحية الوصول لجميع المستويات
        $db = \Config\Database::connect();
        
        // إذا كان المستخدم مسؤول (Level 1) يظهر كل الألعاب
        if ($user->level == 1) {
            $games = $this->gamesModel->findAll();
        } else {
            // إذا كان مستخدم عادي، يظهر فقط الألعاب المرتبطة به
            $builder = $db->table('games g');
            $builder->select('g.*');
            $builder->join('user_games ug', 'ug.game_id = g.id', 'inner');
            $builder->where('ug.user_id', $user->id_users);
            $games = $builder->get()->getResultArray();
        }
        
        $data = [
            'title' => 'إدارة الألعاب',
            'user' => $user,
            'games' => $games,
            'validation' => Services::validation(),
        ];
        return view('game_manager/index', $data);
    }

    public function addGame()
    {
        $userModel = new \App\Models\UserModel();
        $user = $userModel->getUser();
        
        // صلاحية إضافة لعبة لجميع المستويات
        $validation = Services::validation();
        $validation->setRules([
            'game_code' => [
                'label' => 'كود اللعبة',
                'rules' => 'required|alpha_numeric|max_length[20]|is_unique[games.game_code]',
                'errors' => [
                    'is_unique' => 'كود اللعبة موجود بالفعل',
                    'alpha_numeric' => 'الكود يجب أن يحتوي على أحرف وأرقام فقط'
                ]
            ],
            'game_name' => [
                'label' => 'اسم اللعبة',
                'rules' => 'required|max_length[100]'
            ],
            'status' => [
                'label' => 'الحالة',
                'rules' => 'required|in_list[on,off]'
            ]
        ]);
        
        if (!$validation->withRequest($this->request)->run()) {
            return redirect()->back()->withInput()->with('msgDanger', 'هناك أخطاء في البيانات');
        }
        
        $gameCode = strtoupper($this->request->getPost('game_code'));
        $gameName = $this->request->getPost('game_name');
        $status = $this->request->getPost('status');
        
        $gameData = [
            'game_code' => $gameCode,
            'game_name' => $gameName,
            'status' => $status,
            'created_by' => $user->id_users, // إضافة معرف المستخدم اللي أنشأ اللعبة
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s')
        ];
        
        // إضافة اللعبة في جدول games
        $this->gamesModel->insert($gameData);
        $gameId = $this->gamesModel->getInsertID(); // جلب ID اللعبة اللي تم إنشاؤها
        
        // ✅ إضافة العلاقة بين المستخدم واللعبة
        $db = \Config\Database::connect();
        $db->table('user_games')->insert([
            'user_id' => $user->id_users,
            'game_id' => $gameId
        ]);
        
        // إضافة ميزات اللعبة الافتراضية
        $gamesFeaturesModel = new \App\Models\GamesFeaturesModel();
        $gamesFeaturesModel->insert([
            'game' => $gameCode,
            'ESP' => 'on',
            'Item' => 'on',
            'AIM' => 'on',
            'SilentAim' => 'on',
            'BulletTrack' => 'on',
            'Memory' => 'on',
            'Floating' => 'on',
            'Setting' => 'on',
            'status' => $status,
            'maintenance_mode' => 'off',
            'maintenance_message' => ''
        ]);
        
        return redirect()->to('gamemanager')->with('msgSuccess', 'تم إضافة اللعبة بنجاح');
    }

    public function editGame($id = null)
    {
        $userModel = new \App\Models\UserModel();
        $user = $userModel->getUser();
        
        // صلاحية التعديل: المستخدم يمكنه تعديل الألعاب المرتبطة به فقط
        $db = \Config\Database::connect();
        
        // التحقق إذا كان المستخدم مرتبط باللعبة
        if ($user->level != 1) {
            $checkAccess = $db->table('user_games')
                ->where('user_id', $user->id_users)
                ->where('game_id', $id)
                ->countAllResults();
                
            if ($checkAccess == 0) {
                return redirect()->to('gamemanager')->with('msgDanger', 'ليس لديك صلاحية لتعديل هذه اللعبة');
            }
        }
        
        $game = $this->gamesModel->find($id);
        if (!$game) {
            return redirect()->to('gamemanager')->with('msgDanger', 'اللعبة غير موجودة');
        }
        
        if ($this->request->getMethod() === 'post') {
            $validation = Services::validation();
            $validation->setRules([
                'game_name' => [
                    'label' => 'اسم اللعبة',
                    'rules' => 'required|max_length[100]'
                ],
                'status' => [
                    'label' => 'الحالة',
                    'rules' => 'required|in_list[on,off]'
                ]
            ]);
            
            if (!$validation->withRequest($this->request)->run()) {
                return redirect()->back()->withInput()->with('msgDanger', 'هناك أخطاء في البيانات');
            }
            
            $updateData = [
                'game_name' => $this->request->getPost('game_name'),
                'status' => $this->request->getPost('status'),
                'updated_at' => date('Y-m-d H:i:s')
            ];
            
            $this->gamesModel->update($id, $updateData);
            
            $gamesFeaturesModel = new \App\Models\GamesFeaturesModel();
            $gamesFeaturesModel->where('game', $game['game_code'])->set([
                'status' => $this->request->getPost('status')
            ])->update();
            
            return redirect()->to('gamemanager')->with('msgSuccess', 'تم تحديث اللعبة بنجاح');
        }
        
        $data = [
            'title' => 'تعديل اللعبة',
            'user' => $user,
            'game' => $game,
            'validation' => Services::validation(),
        ];
        return view('game_manager/edit', $data);
    }

    public function deleteGame($id)
    {
        $userModel = new \App\Models\UserModel();
        $user = $userModel->getUser();
        
        // صلاحية الحذف: المستخدم يمكنه حذف الألعاب المرتبطة به فقط
        $db = \Config\Database::connect();
        
        if ($user->level != 1) {
            $checkAccess = $db->table('user_games')
                ->where('user_id', $user->id_users)
                ->where('game_id', $id)
                ->countAllResults();
                
            if ($checkAccess == 0) {
                return redirect()->to('gamemanager')->with('msgDanger', 'ليس لديك صلاحية لحذف هذه اللعبة');
            }
        }
        
        $game = $this->gamesModel->find($id);
        if (!$game) {
            return redirect()->to('gamemanager')->with('msgDanger', 'اللعبة غير موجودة');
        }
        
        // حذف العلاقة من user_games أولاً
        $db->table('user_games')->where('game_id', $id)->delete();
        
        // حذف ميزات اللعبة
        $gamesFeaturesModel = new \App\Models\GamesFeaturesModel();
        $gamesFeaturesModel->where('game', $game['game_code'])->delete();
        
        // حذف اللعبة نفسها
        $this->gamesModel->delete($id);
        
        return redirect()->to('gamemanager')->with('msgSuccess', 'تم حذف اللعبة بنجاح');
    }
}