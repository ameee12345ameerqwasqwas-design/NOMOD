<?php

namespace App\Controllers;

use App\Models\HistoryModel;
use App\Models\KeysModel;
use App\Models\UserModel;
use App\Models\GamesModel;
use Config\Services;

class Keys extends BaseController
{
    protected $userModel, $model, $user, $userId, $gamesModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
        $this->user = $this->userModel->getUser();
        $this->model = new KeysModel();
        $this->gamesModel = new GamesModel();
        $this->time = new \CodeIgniter\I18n\Time;
        $this->userId = session()->get('userid');
        
        $this->duration = [
            1 => '1 Hours &mdash; $1/Device',
            5 => '5 Hours &mdash; $2/Device',
            24 => '1 Days &mdash; $5/Device',
            72 => '3 Days &mdash; $6/Device',
            168 => '7 Days &mdash; $10/Device',
            360 => '15 Days &mdash; $15/Device',
            720 => '30 Days &mdash; $20/Device',
            1440 => '60 Days &mdash; $30/Device',
        ];

        $this->price = [
            1 => 1,
            5 => 2,
            24 => 5,
            72 => 6,
            168 => 10,
            360 => 15,
            720 => 20,
            1440 => 30,
        ];
    }

    public function getGameList()
    {
        $userId = session()->userid;
        $allowedGames = $this->userModel->getAllowedGames($userId);
        
        $games = $this->gamesModel->where('status', 1)->findAll();
        $gameList = [];
        
        foreach ($games as $game) {
            if (empty($allowedGames) || in_array($game['game_code'], $allowedGames)) {
                $gameList[$game['game_code']] = $game['game_name'];
            }
        }
        
        return $gameList;
    }

    public function getFilteredGameList($userId = null)
    {
        if (!$userId) {
            $userId = session()->userid;
        }
        
        $allowedGames = $this->userModel->getAllowedGames($userId);
        
        $games = $this->gamesModel->where('status', 1)->findAll();
        $gameList = [];
        
        foreach ($games as $game) {
            if (empty($allowedGames) || in_array($game['game_code'], $allowedGames)) {
                $gameList[$game['game_code']] = $game['game_name'];
            }
        }
        
        return $gameList;
    }

    public function index()
    {
        $model = $this->model;
        $user = $this->user;

        if ($user->level != 1) {
            $keys = $model->where('registrator', $user->username)->findAll();
        } else {
            $keys = $model->findAll();
        }

        $data = [
            'title' => 'Keys',
            'user' => $user,
            'userLevel' => $user->level,
            'keylist' => $keys,
            'time' => $this->time,
        ];
        return view('Keys/list', $data);
    }
    
    public function download_all_Keys(){
        $model = $this->model;
        $user = $this->user;
        
        $selectedUser = $this->request->getGet('userFilter');
        
        if ($user->level == 1 && !empty($selectedUser)) {
            $keys = $model->where('registrator', $selectedUser)->findAll();
        } else {
            $keys = $model->where('registrator', $user->username)->findAll();
        }
        
        $data='';
        for($i=0;$i<count($keys);$i++){
            $data.=$keys[$i]['user_key']."\n";
        }
        write_file('Newkeys.txt', $data);
        $this->downloadFile('Newkeys.txt');
    }

    public function download_new_Keys(){
        $this->downloadFile('new.txt');
    }

    function downloadFile($yourFile){
        $file = @fopen($yourFile, "rb");
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename=Allkeys.txt');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($yourFile));
        while (!feof($file)) {
            print(@fread($file, 1024 * 8));
            ob_flush();
            flush();
        }
    }

    public function alterKeys(){
        $model=$this->model;
        $user = $this->user;
        
        $selectedUser = $this->request->getGet('userFilter');
        
        if ($user->level == 1 && !empty($selectedUser)) {
            $model->where('registrator', $selectedUser);
        } elseif ($user->level != 1) {
            $model->where('registrator', $user->username);
        }
        
        $data=$model->where('expired_date <', date('Y-m-d H:i:s'))->delete();
        return redirect()->back()->with('msgSuccess', 'success');
    }

    public function deleteKeys(){
        $model = $this->model;
        $user  = $this->user;
        $selectedUser = $this->request->getGet('userFilter');

        if ($user->level == 1) {
            if (!empty($selectedUser)) {
                $model->where('registrator', $selectedUser)->delete();
            } else {
                $model->where('1=1', null, false)->delete();
            }
        } else {
            $model->where('registrator', $user->username)->delete();
        }

        return redirect()->back()->with('msgSuccess', 'success');
    }

    public function resetAllKeys(){
        $model = $this->model;
        $user = $this->user;
        
        $selectedUser = $this->request->getGet('userFilter');
        
        if ($user->level == 1 && !empty($selectedUser)) {
            $model->where('registrator', $selectedUser);
        } elseif ($user->level != 1) {
            $model->where('registrator', $user->username);
        }
        
        $model->set('devices', NULL)->set('expired_date',NULL)->update();
        return redirect()->to('keys'); 
    }

    public function startDate(){
        $model=$this->model;
        $user = $this->user;
        
        $selectedUser = $this->request->getGet('userFilter');
        
        if ($user->level == 1 && !empty($selectedUser)) {
            $model->where('registrator', $selectedUser);
        } elseif ($user->level != 1) {
            $model->where('registrator', $user->username);
        }
        
        $data=$model->where('expired_date ='.null)->delete();
        return redirect()->back()->with('msgSuccess', 'success');
    }

    public function api_get_keys(){
        $model = $this->model;
        $user = $this->user;
        
        $request = service('request');
        $userFilter = $request->getGet('userFilter');
        
        $builder = $model->builder();
        
        if ($user->level != 1) {
            $builder->where('registrator', $user->username);
        } 
        elseif (!empty($userFilter)) {
            $builder->where('registrator', $userFilter);
        }
        
        return $model->API_getKeys($builder);
    }

    public function deleteExpired(){
        $model=$this->model;
        $user = $this->user;
        
        $selectedUser = $this->request->getGet('userFilter');
        
        if ($user->level == 1 && !empty($selectedUser)) {
            $model->where('registrator', $selectedUser);
        } elseif ($user->level != 1) {
            $model->where('registrator', $user->username);
        }
        
        $data=$model->where('expired_date <', date('Y-m-d H:i:s'))->delete();
        return redirect()->back()->with('msgSuccess', 'success');
    }

    public function deleteUnused(){
        $model=$this->model;
        $user = $this->user;
        
        $selectedUser = $this->request->getGet('userFilter');
        
        if ($user->level == 1 && !empty($selectedUser)) {
            $model->where('registrator', $selectedUser);
        } elseif ($user->level != 1) {
            $model->where('registrator', $user->username);
        }
        
        $data=$model->where('expired_date ='.null)->delete();
        return redirect()->back()->with('msgSuccess', 'success');
    }
    
    public function api_key_delete(){
        $model=$this->model;
        $keys = $this->request->getGet('userkey');
        $data=$model->where('user_key', $keys)->delete();
        print_r($data);

        return redirect()->back()->with('msgSuccess', 'success');
    }
    
    public function api_key_reset(){
        sleep(1);
        $model = $this->model;
        $keys = $this->request->getGet('userkey');
        $reset = $this->request->getGet('reset');
        $db_key = $model->getKeys($keys);

        $rules = [];
        if ($db_key) {
            $total = $db_key->devices ? explode(',', $db_key->devices) : [];
            $rules = ['devices_total' => count($total), 'devices_max' => (int) $db_key->max_devices];
            $user = $this->user;
            if ($db_key->devices and $reset) {
                if ($user->level == 1 or $db_key->registrator == $user->username) {
                    $model->resetKey($keys);
                    $rules = ['reset' => true, 'devices_total' => 0, 'devices_max' => $db_key->max_devices];
                }
            }
        }

        $data = ['registered' => $db_key ? true : false, 'keys' => $keys];
        $real_response = array_merge($data, $rules);
        return $this->response->setJSON($real_response);
    }

    public function edit_key($key = false){
        if ($this->request->getPost()) return $this->edit_key_action();
        $msgDanger = "The user key no longer exists.";
        if ($key) {
            $dKey = $this->model->getKeys($key, 'id_keys');
            $user = $this->user;
            if ($dKey) {
                if ($user->level == 1 or $dKey->registrator == $user->username) {
                    $validation = Services::validation();
                    $game_list = $this->getGameList();
                    $data = [
                        'title' => 'Key',
                        'user' => $user,
                        'key' => $dKey,
                        'game_list' => $game_list,
                        'time' => $this->time,
                        'key_info' => getDevice($dKey->devices),
                        'messages' => setMessage('Please carefuly edit information'),
                        'validation' => $validation,
                    ];
                    return view('Keys/key_edit', $data);
                } else {
                    $msgDanger = "Restricted to this user key.";
                }
            }
        }
        return redirect()->to('keys')->with('msgDanger', $msgDanger);
    }

    private function edit_key_action(){
        $keys = $this->request->getPost('id_keys');
        $user = $this->user;
        $dKey = $this->model->getKeys($keys, 'id_keys');
        $game_list = $this->getGameList();
        $game_codes = implode(",", array_keys($game_list));

        if (!$dKey) {
            $msgDanger = "The user key no longer exists~";
        } else {
            if ($user->level == 1 or $dKey->registrator == $user->username) {
                $form_reseller = [
                    'status' => [
                        'label' => 'status',
                        'rules' => 'required|integer|in_list[0,1]',
                        'erros' => [
                            'integer' => 'Invalid {field}.',
                            'in_list' => 'Choose between list.'
                        ]
                    ]
                ];
                $form_admin = [
                    'id_keys' => [
                        'label' => 'keys',
                        'rules' => 'required|is_not_unique[keys_code.id_keys]|numeric',
                        'errors' => [
                            'is_not_unique' => 'Invalid keys.'
                        ],
                    ],
                    'game' => [
                        'label' => 'Games',
                        'rules' => "required|alpha_numeric_space|in_list[$game_codes]",
                        'errors' => [
                            'alpha_numeric_space' => 'Invalid characters.'
                        ],
                    ],
                    'user_key' => [
                        'label' => 'User keys',
                        'rules' => "required|is_unique[keys_code.user_key,user_key,$dKey->user_key]|alpha_numeric",
                        'errors' => [
                            'is_unique' => '{field} has been taken.'
                        ],
                    ],
                    'duration' => [
                        'label' => 'duration',
                        'rules' => 'required|numeric|greater_than_equal_to[1]',
                        'errors' => [
                            'greater_than_equal_to' => 'Minimum {field} is invalid.',
                            'numeric' => 'Invalid hour {field}.'
                        ]
                    ],
                    'max_devices' => [
                        'label' => 'devices',
                        'rules' => 'required|numeric|greater_than_equal_to[1]',
                        'errors' => [
                            'greater_than_equal_to' => 'Minimum {field} is invalid.',
                            'numeric' => 'Invalid max of {field}.'
                        ]
                    ],
                    'registrator' => [
                        'label' => 'registrator',
                        'rules' => 'permit_empty|alpha_numeric_space|min_length[4]'
                    ],
                    'expired_date' => [
                        'label' => 'expired',
                        'rules' => 'permit_empty|valid_date[Y-m-d H:i:s]',
                        'errors' => [
                            'valid_date' => 'Invalid {field} date.',
                        ]
                    ],
                    'devices' => [
                        'label' => 'device list',
                        'rules' => 'permit_empty'
                    ]
                ];

                if ($user->level == 1) {
                    $form_rules = array_merge($form_reseller, $form_admin);
                    $devices = $this->request->getPost('devices');
                    $max_devices = $this->request->getPost('max_devices');
                    $data_saves = [
                        'game' => $this->request->getPost('game'),
                        'user_key' => $this->request->getPost('user_key'),
                        'duration' => $this->request->getPost('duration'),
                        'max_devices' => $max_devices,
                        'status' => $this->request->getPost('status'),
                        'registrator' => $this->request->getPost('registrator'),
                        'expired_date' => $this->request->getPost('expired_date') ?: NULL,
                        'devices' => setDevice($devices, $max_devices),
                    ];
                } else {
                    $form_rules = $form_reseller;
                    $data_saves = ['status' => $this->request->getPost('status')];
                }

                if (!$this->validate($form_rules)) {
                    return redirect()->back()->withInput()->with('msgDanger', 'Failed! Please check the error');
                } else {
                    $this->model->update($dKey->id_keys, $data_saves);
                    return redirect()->back()->with('msgSuccess', 'User key successfuly updated!');
                }
            } else {
                $msgDanger = "Restricted to this user key~";
            }
        }
        return redirect()->to('keys')->with('msgDanger', $msgDanger);
    }

    public function generate()
    {
        if ($this->request->getPost())
            return $this->generate_action();

        $user = $this->user;
        $validation = Services::validation();

        $message = setMessage("<i class='bi bi-wallet'></i> Total Saldo $$user->saldo");
        if ($user->saldo <= 0) {
            $message = setMessage("Please top up to your beloved admin.", 'warning');
        }

        $game_list = $this->getGameList();
        $data = [
            'title' => 'Generate',
            'user' => $user,
            'time' => $this->time,
            'game' => $game_list,
            'duration' => $this->duration,
            'price' => json_encode($this->price),
            'messages' => $message,
            'validation' => $validation,
        ];
        return view('Keys/generate', $data);
    }

    private function generate_action()
    {
        $user = $this->user;
        $game = $this->request->getPost('game');
        $maxd = $this->request->getPost('max_devices');
        $drtn = $this->request->getPost('duration');
        $twst = $this->request->getPost('custominput');
        $cuslicense = $this->request->getPost('cuslicense');
        $license_type = $this->request->getPost('license_type');
        
        $game_list = $this->getGameList();
        
        $allowedGames = $this->userModel->getAllowedGames($user->id_users);
        if (!empty($allowedGames) && !in_array($game, $allowedGames)) {
            return redirect()->back()->with('msgDanger', 'غير مسموح لك بإنشاء مفاتيح لهذه اللعبة.');
        }
        
        $getPrice = getPrice($this->price, $drtn, $maxd);
        
        $game_codes = implode(",", array_keys($game_list));
        $form_rules = [
            'game' => [
                'label' => 'Games',
                'rules' => "required|alpha_numeric_space|in_list[$game_codes]",
                'errors' => [
                    'alpha_numeric_space' => 'Invalid characters.'
                ],
            ],
            'duration' => [
                'label' => 'duration',
                'rules' => 'required|numeric|greater_than_equal_to[1]',
                'errors' => [
                    'greater_than_equal_to' => 'Minimum {field} is invalid.',
                    'numeric' => 'Invalid day {field}.'
                ]
            ],
            'max_devices' => [
                'label' => 'devices',
                'rules' => 'required|numeric|greater_than_equal_to[1]',
                'errors' => [
                    'greater_than_equal_to' => 'Minimum {field} is invalid.',
                    'numeric' => 'Invalid max of {field}.'
                ]
            ],
        ];

        $validation = Services::validation();
        $reduceCheck = ($user->saldo - $getPrice);
        
        if ($reduceCheck < 0) {
            $validation->setError('duration', 'Insufficient balance');
            return redirect()->back()->withInput()->with('msgWarning', 'Please top up to your beloved admin.');
        }
        
        if (!$this->validate($form_rules)) {
            return redirect()->back()->withInput()->with('msgDanger', 'Failed! Please check the error');
        }
        
        $prefix = strtoupper($user->username);
        
        $durationPart = preg_replace('/[^0-9]/', '', $drtn);
        $randomPart = strtoupper(random_string('alnum', 8));
        $license = $prefix . 'x' . $durationPart . 'x' . $randomPart;

        if ($twst == "custom") {
            if (strlen($cuslicense) > 3 && strlen($cuslicense) < 20) {
                $findKey = $this->model->getKeysGame(['user_key' => $cuslicense, 'game' => $game]);
                if ($findKey) {
                    return redirect()->back()->with('msgDanger', 'Key already exists!!');
                }
                $license = $cuslicense;
            } else {
                return redirect()->back()->with('msgDanger', 'Custom Key is too Short/Long');
            }
        } else {
            $attempts = 0;
            $maxAttempts = 10;
            
            do {
                $license = $prefix . 'x' . $durationPart . 'x' . strtoupper(random_string('alnum', 8));
                $findKey = $this->model->where('user_key', $license)->first();
                $attempts++;
                
                if ($attempts >= $maxAttempts) {
                    return redirect()->back()->with('msgDanger', 'تعذر توليد مفتاح فريد. يرجى المحاولة مرة أخرى.');
                }
            } while ($findKey);
        }

        $data_response = [
            'game' => $game,
            'user_key' => $license,
            'duration' => $durationPart,
            'max_devices' => $maxd,
            'registrator' => $user->username,
            'admin_id' => $this->userId
        ];

        try {
            $lastKeyId = $this->model->insert($data_response);
        } catch (\mysqli_sql_exception $e) {
            if ($e->getCode() == 1062) {
                return redirect()->back()->withInput()->with('msgDanger', 'المفتاح موجود بالفعل. يرجى المحاولة مرة أخرى.');
            }
            throw $e;
        }
        
        $this->userModel->update(session('userid'), ['saldo' => $reduceCheck]);

        $history = new HistoryModel();
        $history->insert([
            'keys_id' => $lastKeyId,
            'user_do' => $user->username,
            'info' => "$game|" . substr($license, 0, 5) . "|$drtn|$maxd"
        ]);

        $other_response = ['fees' => $getPrice];
        
        session()->setFlashdata('user_key', $license);
        session()->setFlashdata('game', $game_list[$game]);
        session()->setFlashdata('duration', $durationPart);
        session()->setFlashdata('max_devices', $maxd);
        session()->setFlashdata('fees', $getPrice);
        
        return redirect()->to(site_url('keys/generate'))->with('msgSuccess', 'Successfully Generated.');
    }

    public function extendAllKeys()
    {
        $model = $this->model;
        $user = $this->user;
        
        $selectedUser = $this->request->getGet('userFilter');
        $extensionHours = $this->request->getPost('extension_hours');
        
        if ($user->level == 1 && !empty($selectedUser)) {
            $model->where('registrator', $selectedUser);
        } elseif ($user->level != 1) {
            $model->where('registrator', $user->username);
        }
        
        $keys = $model->findAll();
        
        $updatedCount = 0;
        
        foreach ($keys as $key) {
            if ($key['expired_date']) {
                $currentExpiry = new \DateTime($key['expired_date']);
                $currentExpiry->modify("+{$extensionHours} hours");
                $newExpiry = $currentExpiry->format('Y-m-d H:i:s');
                
                $model->update($key['id_keys'], [
                    'expired_date' => $newExpiry
                ]);
                $updatedCount++;
            }
        }
        
        return redirect()->back()->with('msgSuccess', "تم تذويد وقت {$updatedCount} كود بنجاح بإضافة {$extensionHours} ساعة");
    }

    public function extendKeysView()
    {
        $user = $this->user;
        
        $data = [
            'title' => 'تذويد وقت الأكواد',
            'user' => $user,
            'duration_options' => [
                1 => '1 ساعة',
                5 => '5 ساعات', 
                24 => '1 يوم (24 ساعة)',
                72 => '3 أيام (72 ساعة)',
                168 => '7 أيام (168 ساعة)',
                360 => '15 يوم (360 ساعة)',
                720 => '30 يوم (720 ساعة)',
                1440 => '60 يوم (1440 ساعة)'
            ]
        ];
        
        return view('Keys/extend_keys', $data);
    }

    public function deleteAllDevices()
    {
        $model = $this->model;
        $user = $this->user;
        
        $selectedUser = $this->request->getGet('userFilter');
        
        if ($user->level == 1 && !empty($selectedUser)) {
            $model->where('registrator', $selectedUser);
        } elseif ($user->level != 1) {
            $model->where('registrator', $user->username);
        }
        
        $result = $model->set('devices', null)->update();
        
        return redirect()->back()->with('msgSuccess', 'تم حذف جميع الأجهزة من جميع المفاتيح بنجاح!');
    }
}