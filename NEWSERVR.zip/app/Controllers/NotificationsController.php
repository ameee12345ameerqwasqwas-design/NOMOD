<?php
namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;

class NotificationsController extends BaseController
{
    use ResponseTrait;

    private function isApiRequest()
    {
        $userAgent = $this->request->getUserAgent();
        $isBrowser = $userAgent->isBrowser();
        
        return !$isBrowser;
    }

    public function index()
    {
        return $this->manageView();
    }

    public function manageView()
    {
        $user = $this->getUser();
        
        if (!in_array($user->level, [1, 2])) {
            return redirect()->to('dashboard')->with('msgWarning', 'Access Denied');
        }

        if ($this->request->getPost('notification_form')) {
            return $this->createNotificationAction();
        }

        if ($this->request->getPost('delete_notification')) {
            return $this->deleteNotificationAction();
        }

        $notifications = $this->getNotifications();
        
        $data = [
            'title' => 'Notifications Management',
            'user' => $user,
            'notifications' => $notifications
        ];
        
        return view('Notifications/manage', $data);
    }

    public function apiNotifications()
    {
        if ($this->isApiRequest()) {
            $target = $this->request->getGet('target') ?? 'all';
            $notifications = $this->getNotifications($target);
            
            $activeNotifications = array_filter($notifications, function($notification) {
                return $notification->is_active == 1;
            });
            
            return $this->response->setJSON([
                'status' => true,
                'data' => array_values($activeNotifications)
            ]);
        } else {
            return $this->showLandingPage();
        }
    }

    private function showLandingPage()
    {
        $html = '<!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title>R3PMOD VIP</title>
            <link rel="preconnect" href="https://fonts.googleapis.com">
            <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
            <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;1,100;1,200;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"/>
        <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body{
            margin: 0;
            padding: 0;
            overflow-x: hidden;
            background: #0a0a0a;
            font-family: "Josefin Sans", sans-serif;
        }

        .hero-section {
            height: 100vh;
            background: linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 50%, #16213e 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }

        .hero-section::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(45deg, 
                rgba(255,0,150,0.1) 0%, 
                rgba(0,255,255,0.1) 25%, 
                rgba(255,255,0,0.1) 50%, 
                rgba(0,255,0,0.1) 75%, 
                rgba(255,0,0,0.1) 100%);
            animation: rgbFlow 8s ease-in-out infinite;
            z-index: 1;
        }

        @keyframes rgbFlow {
            0%, 100% { opacity: 0.3; }
            50% { opacity: 0.7; }
        }

        .hero-content {
            position: relative;
            z-index: 2;
            text-align: center;
        }

        .hero-title {
            font-size: 5rem;
            font-weight: 700;
            background: linear-gradient(45deg, #ff0080, #00ffcc, #ffcc00, #ff0080);
            background-size: 400% 400%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            animation: rgbText 6s ease-in-out infinite;
            margin-bottom: 1rem;
            text-shadow: 0 0 30px rgba(255,255,255,0.1);
        }

        @keyframes rgbText {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }

        .hero-subtitle {
            color: rgba(255,255,255,0.8);
            font-size: 1.5rem;
            margin-bottom: 2rem;
            letter-spacing: 3px;
            text-transform: uppercase;
        }

        .hero-badge {
            display: inline-block;
            background: linear-gradient(45deg, #ff0080, #00ffcc);
            padding: 10px 25px;
            border-radius: 50px;
            color: white;
            font-weight: 600;
            letter-spacing: 1px;
            box-shadow: 0 10px 30px rgba(255,0,128,0.3);
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }

        .about-section {
            width: 100%;
            min-height: 100vh;
            padding: 100px 0;
            background: linear-gradient(135deg, #0a0a0a 0%, #1a1a2e 100%);
            position: relative;
        }

        .about-container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 60px;
            align-items: center;
        }

        .about-content {
            padding: 40px;
            background: rgba(255,255,255,0.05);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            border: 1px solid rgba(255,255,255,0.1);
            box-shadow: 0 20px 40px rgba(0,0,0,0.3);
        }

        .about-title {
            font-size: 3.5rem;
            color: white;
            margin-bottom: 20px;
            background: linear-gradient(45deg, #ff0080, #00ffcc);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .about-subtitle {
            color: rgba(255,255,255,0.8);
            font-size: 1.5rem;
            margin-bottom: 30px;
        }

        .about-subtitle span {
            color: #ff0080;
            font-weight: 700;
        }

        .about-text {
            color: rgba(255,255,255,0.7);
            line-height: 1.8;
            font-size: 1.1rem;
            margin-bottom: 40px;
        }

        .cta-button {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            background: linear-gradient(45deg, #ff0080, #00ffcc);
            color: white;
            text-decoration: none;
            border: none;
            font-weight: 600;
            padding: 15px 35px;
            border-radius: 50px;
            font-size: 1.1rem;
            transition: all 0.3s ease;
            box-shadow: 0 10px 30px rgba(255,0,128,0.3);
            cursor: pointer;
        }

        .cta-button:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 40px rgba(255,0,128,0.4);
        }

        .about-visual {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .visual-element {
            width: 300px;
            height: 300px;
            background: linear-gradient(45deg, #ff0080, #00ffcc, #ffcc00);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            animation: rotate 10s linear infinite;
            box-shadow: 0 0 100px rgba(255,0,128,0.3);
        }

        .visual-element::before {
            content: "R3PMOD";
            font-size: 2rem;
            font-weight: 700;
            color: white;
            text-shadow: 0 0 20px rgba(0,0,0,0.5);
        }

        @keyframes rotate {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .toast {
            position: fixed;
            top: 30px;
            right: 30px;
            border-radius: 15px;
            background: rgba(255,255,255,0.95);
            backdrop-filter: blur(10px);
            padding: 20px 35px 20px 25px;
            box-shadow: 0 15px 40px rgba(0,0,0,0.2);
            border-left: 6px solid #ff0080;
            overflow: hidden;
            transform: translateX(calc(100% + 30px));
            transition: all 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.35);
            z-index: 1000;
        }

        .toast.active {
            transform: translateX(0%);
        }

        .toast .toast-content {
            display: flex;
            align-items: center;
        }

        .toast-content .check {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 35px;
            width: 35px;
            background: linear-gradient(45deg, #ff0080, #00ffcc);
            color: #fff;
            font-size: 20px;
            border-radius: 50%;
        }

        .toast-content .message {
            display: flex;
            flex-direction: column;
            margin: 0 20px;
        }

        .message .text {
            font-size: 16px;
            font-weight: 400;
            color: #666;
        }

        .message .text.text-1 {
            font-weight: 600;
            color: #333;
        }

        .toast .close {
            position: absolute;
            top: 10px;
            right: 15px;
            padding: 5px;
            cursor: pointer;
            opacity: 0.7;
            color: #333;
        }

        .toast .close:hover {
            opacity: 1;
        }

        .toast .progress {
            position: absolute;
            bottom: 0;
            left: 0;
            height: 3px;
            width: 100%;
            background: #ddd;
        }

        .toast .progress:before {
            content: "";
            position: absolute;
            bottom: 0;
            right: 0;
            height: 100%;
            width: 100%;
            background: linear-gradient(45deg, #ff0080, #00ffcc);
        }

        .progress.active:before {
            animation: progress 5s linear forwards;
        }

        @keyframes progress {
            100% {
                right: 100%;
            }
        }

        @media screen and (max-width: 968px) {
            .about-container {
                grid-template-columns: 1fr;
                gap: 40px;
            }
            
            .hero-title {
                font-size: 3rem;
            }
            
            .about-title {
                font-size: 2.5rem;
            }
        }

        @media screen and (max-width: 600px) {
            .hero-title {
                font-size: 2rem;
            }
            
            .hero-subtitle {
                font-size: 1rem;
            }
            
            .about-title {
                font-size: 2rem;
            }
            
            .about-subtitle {
                font-size: 1.2rem;
            }
            
            .visual-element {
                width: 200px;
                height: 200px;
            }
            
            .toast {
                right: 20px;
                left: 20px;
                transform: translateY(-150px);
            }
            
            .toast.active {
                transform: translateY(0);
            }
        }
        </style>
        </head>
        <body>
            <section class="hero-section">
                <div class="hero-content">
                    <h1 class="hero-title">R3PMOD</h1>
                    <p class="hero-subtitle">VIP 3MK EXPERIENCE</p>
                    <div class="hero-badge">PREMIUM ACCESS</div>
                </div>
            </section>
            
            <section class="about-section">
                <div class="about-container">
                    <div class="about-content">
                        <h2 class="about-title">مرحباً NOOP</h2>
                        <h3 class="about-subtitle">𝗛𝗶 <span>𝗥𝟯𝗣𝗠𝗢𝗗⚡ 𝗩𝗜𝗣 💣 𝟯𝗠𝗞</span></h3>
                        <p class="about-text">
                            وانتة لك طاب بل صدفة انجب ولا تحجي اخرك ما تعرف تكرك<br>
                            <br>انتة لك جاي بصدفة تريد تكرك لك ليوم احشي رجلي بيك دودكي تريد تكرك لو يطلع شيب بطي؟زك ما يتكرك هههههههههه حمار تكريك مطلع سيرفر من كناري مكيف لحمار
                        </p>
                        <h3 class="about-subtitle">هل تريد قناتي اضغط</h3>
                        <button class="cta-button" id="channelButton">
                            <i class="fab fa-telegram"></i>
                            اضغط هنا
                        </button>
                    </div>
                    <div class="about-visual">
                        <div class="visual-element"></div>
                    </div>
                </div>
            </section>

            <script>
                document.getElementById("channelButton").addEventListener("click", function() {
                    window.open("https://t.me/R3PMOD", "_blank");
                });
            </script>
        </body>
        </html>';

        return $this->response->setBody($html)->setContentType('text/html');
    }

    private function createNotificationAction()
    {
        $validation = \Config\Services::validation();
        
        $rules = [
            'title' => 'required|min_length[3]|max_length[255]',
            'message' => 'required|min_length[5]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('msgDanger', 'Please check the form data.');
        }

        $data = [
            'title' => esc($this->request->getPost('title')),
            'message' => esc($this->request->getPost('message')),
            'type' => 'info',
            'target_users' => 'all',
            'is_active' => $this->request->getPost('is_active') ? 1 : 0,
            'created_at' => date('Y-m-d H:i:s')
        ];

        $db = db_connect();
        $db->table('notifications')->insert($data);

        return redirect()->back()->with('msgSuccess', 'Notification created successfully!');
    }

    private function deleteNotificationAction()
    {
        $id = $this->request->getPost('id');
        
        $db = db_connect();
        $db->table('notifications')->where('id', $id)->delete();
        
        return redirect()->back()->with('msgSuccess', 'Notification deleted successfully!');
    }

    private function getNotifications($target = 'all')
    {
        try {
            $db = db_connect();
            $query = $db->table('notifications')
                       ->orderBy('created_at', 'DESC');
            
            if ($target !== 'all') {
                $query->where('target_users', $target);
            }
            
            return $query->get()->getResult();
        } catch (\Exception $e) {
            return [];
        }
    }

    private function getUser()
    {
        $model = new \App\Models\UserModel();
        return $model->getUser(session()->userid);
    }
}