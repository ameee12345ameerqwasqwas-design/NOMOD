<?php

namespace Config;

use CodeIgniter\Config\Services;

$routes = Services::routes();

if (file_exists(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Auth');
$routes->setDefaultMethod('login');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(false);

// Auth Routes
$routes->match(['get', 'post'], '/', 'Auth::login');
$routes->match(['get', 'post'], 'login', 'Auth::login');
$routes->get('logout', 'Auth::logout');
$routes->match(['get', 'post'], 'reset', 'Auth::reset');
$routes->match(['get', 'post'], 'register', 'Auth::register');

// Dashboard
$routes->get('dashboard', 'User::index', ['filter' => 'auth']);
$routes->get('dbg', 'Auth::index');

// Settings & Server
$routes->match(['get', 'post'], 'settings', 'User::settings', ['filter' => 'auth']);
$routes->match(['get', 'post'], 'server', 'User::Server', ['filter' => 'auth']);
$routes->match(['get', 'post'], 'Server', 'User::Server', ['filter' => 'auth']);

// SDK / Server Library
$routes->get('sdk', 'SdkController::index', ['filter' => 'auth']);

// File Manager Routes
$routes->group('file-manager', ['filter' => 'auth'], function ($routes) {
    $routes->get('/', 'FileManager::index');
    $routes->post('upload', 'FileManager::upload');
    $routes->post('delete', 'FileManager::delete');
    $routes->get('download/(:segment)', 'FileManager::download/$1');
    $routes->get('edit-json/(:any)', 'FileManager::editJson/$1');
    $routes->post('edit-json/(:any)', 'FileManager::editJson/$1');
});

// Notifications
$routes->get('notifications', 'NotificationsController::manageView', ['filter' => 'auth']);
$routes->post('notifications', 'NotificationsController::manageView', ['filter' => 'auth']);
$routes->get('api/notifications', 'NotificationsController::apiNotifications');

// Keys Routes
$routes->group('keys', ['filter' => 'auth'], function ($routes) {
    $routes->match(['get', 'post'], '/', 'Keys::index');
    $routes->match(['get', 'post'], 'generate', 'Keys::generate');
    $routes->get('(:num)', 'Keys::edit_key/$1');
    $routes->get('reset', 'Keys::api_key_reset');
    $routes->get('delete', 'Keys::api_key_delete');
    $routes->get('deleteAllDevices', 'Keys::deleteAllDevices');
    $routes->post('edit', 'Keys::edit_key');
    $routes->match(['get', 'post'], 'api', 'Keys::api_get_keys');
    $routes->get('alter', 'Keys::alterKeys');
    $routes->get('resetDevices', 'Keys::resetDevices');
    $routes->get('resetAll', 'Keys::resetAllKeys');
    $routes->get('disableAll', 'Keys::disableAll');
    $routes->get('download/all', 'Keys::download_all_Keys');
    $routes->get('download/new', 'Keys::download_new_Keys');
    $routes->get('deleteKeys', 'Keys::deleteKeys');
    $routes->get('start', 'Keys::startDate');
    $routes->get('extend-view', 'Keys::extendKeysView');
    $routes->post('extend-all', 'Keys::extendAllKeys');
});

// Games Routes
$routes->get('games', 'Games::index', ['filter' => 'auth']);
$routes->get('games/create', 'Games::create', ['filter' => 'auth']);
$routes->post('games/create', 'Games::create', ['filter' => 'auth']);
$routes->get('games/edit/(:num)', 'Games::edit/$1', ['filter' => 'auth']);
$routes->post('games/edit/(:num)', 'Games::edit/$1', ['filter' => 'auth']);
$routes->get('games/delete/(:num)', 'Games::delete/$1', ['filter' => 'auth']);
$routes->get('games/toggleStatus/(:num)', 'Games::toggleStatus/$1', ['filter' => 'auth']);

// Game Manager Routes
$routes->get('game-manager', 'GameManager::index', ['filter' => 'auth']);
$routes->match(['get', 'post'], 'game-manager/(:num)', 'GameManager::manage/$1', ['filter' => 'auth']);
$routes->post('game-manager/feature/delete', 'GameManager::deleteFeature', ['filter' => 'auth']);

// Bots Routes
$routes->group('bots', ['filter' => 'auth'], function ($routes) {
    $routes->get('/', 'BotController::index');
    $routes->get('create', 'BotController::create');
    $routes->post('create', 'BotController::store');
    $routes->get('edit/(:num)', 'BotController::edit/$1');
    $routes->post('edit/(:num)', 'BotController::update/$1');
    $routes->get('delete/(:num)', 'BotController::delete/$1');
    $routes->post('toggle/(:num)', 'BotController::toggle/$1');
});

// Webhooks & Connect
$routes->match(['get', 'post'], 'connect', 'Connect::index');
$routes->post('webhook/(:any)', 'WebhookController::handle/$1');

// Panel Settings (Admin Only)
$routes->match(['get', 'post'], 'panelsettings', 'User::panelsettings', ['filter' => 'admin']);

// Admin Routes
$routes->group('admin', ['filter' => 'admin'], function ($routes) {
    $routes->match(['get', 'post'], 'create-referral', 'User::ref_index');
    $routes->get('delete-referral/(:num)', 'User::delete_referral/$1');
    $routes->match(['get', 'post'], 'manage-users', 'User::manage_users');
    $routes->match(['get', 'post'], 'user/(:num)', 'User::user_edit/$1');
    $routes->get('user/alter', 'User::alterUser');
    $routes->match(['get', 'post'], 'user/singledelete/(:num)', 'User::singleDelete/$1');
    $routes->group('api', function ($routes) {
        $routes->match(['get', 'post'], 'users', 'User::api_get_users');
    });
});

if (file_exists(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
