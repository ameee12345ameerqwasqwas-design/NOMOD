<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?? 'إدارة الألعاب' ?></title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; }
        .card { border-radius: 10px; }
        .status-on { color: green; }
        .status-off { color: red; }
        .badge-creator { background: #6c757d; color: white; font-size: 0.8em; }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-8">
                <h2 class="mb-4">🕹️ إدارة الألعاب</h2>
                <?php if ($user->level != 1): ?>
                    <p class="text-muted">أنت تشاهد فقط الألعاب التي أضفتها أو المرتبطة بحسابك</p>
                <?php else: ?>
                    <p class="text-muted">أنت تشاهد جميع الألعاب في النظام (صلاحية مسؤول)</p>
                <?php endif; ?>
            </div>
            <div class="col-md-4 text-start">
                <a href="<?= site_url('dashboard') ?>" class="btn btn-secondary">🔙 رجوع</a>
            </div>
        </div>

        <!-- رسائل التنبيه -->
        <?php if (session()->has('msgSuccess')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?= session('msgSuccess') ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- نموذج إضافة لعبة جديدة -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">➕ إضافة لعبة جديدة</h5>
            </div>
            <div class="card-body">
                <form action="<?= site_url('gamemanager/addGame') ?>" method="post">
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <label class="form-label">كود اللعبة *</label>
                            <input type="text" name="game_code" class="form-control" required maxlength="20" placeholder="مثال: COD">
                        </div>
                        <div class="col-md-5 mb-3">
                            <label class="form-label">اسم اللعبة *</label>
                            <input type="text" name="game_name" class="form-control" required maxlength="100" placeholder="مثال: Call of Duty Mobile">
                        </div>
                        <div class="col-md-2 mb-3">
                            <label class="form-label">الحالة *</label>
                            <select name="status" class="form-select" required>
                                <option value="on">مفعل</option>
                                <option value="off">معطل</option>
                            </select>
                        </div>
                        <div class="col-md-2 mb-3 d-flex align-items-end">
                            <button type="submit" class="btn btn-success w-100">إضافة</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- جدول الألعاب -->
        <div class="card">
            <div class="card-header bg-dark text-white">
                <h5 class="mb-0">📋 قائمة الألعاب</h5>
            </div>
            <div class="card-body">
                <?php if (empty($games)): ?>
                    <p class="text-center text-muted">لا توجد ألعاب مضافة بعد</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>كود اللعبة</th>
                                    <th>اسم اللعبة</th>
                                    <th>الحالة</th>
                                    <th>تاريخ الإضافة</th>
                                    <?php if ($user->level == 1): ?>
                                        <th>المُنشئ</th>
                                    <?php endif; ?>
                                    <th>الإجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $userModel = new \App\Models\UserModel();
                                foreach ($games as $index => $game): 
                                ?>
                                    <tr>
                                        <td><?= $index + 1 ?></td>
                                        <td><strong><?= $game['game_code'] ?></strong></td>
                                        <td><?= $game['game_name'] ?></td>
                                        <td>
                                            <?php if ($game['status'] == 'on' || $game['status'] == 1): ?>
                                                <span class="badge bg-success status-on">✅ مفعل</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger status-off">❌ معطل</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?= date('Y-m-d H:i', strtotime($game['created_at'])) ?></td>
                                        <?php if ($user->level == 1): ?>
                                            <td>
                                                <?php 
                                                if (!empty($game['created_by'])) {
                                                    $creator = $userModel->find($game['created_by']);
                                                    if ($creator) {
                                                        echo '<span class="badge badge-creator">' . $creator->username . '</span>';
                                                    } else {
                                                        echo '<span class="badge badge-creator">غير معروف</span>';
                                                    }
                                                } else {
                                                    echo '<span class="badge badge-creator">النظام</span>';
                                                }
                                                ?>
                                            </td>
                                        <?php endif; ?>
                                        <td>
                                            <a href="<?= site_url('gamemanager/edit/' . $game['id']) ?>" class="btn btn-sm btn-warning">✏️ تعديل</a>
                                            <a href="<?= site_url('gamemanager/delete/' . $game['id']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('هل أنت متأكد من حذف هذه اللعبة؟')">🗑️ حذف</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>