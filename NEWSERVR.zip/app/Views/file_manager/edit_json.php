<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<style>
    * {margin:0;padding:0;box-sizing:border-box;font-family:'Segoe UI',Arial,sans-serif}
    body {background:linear-gradient(135deg,#0c0c0c,#1a1a2e,#16213e);color:#fff;padding:20px;min-height:100vh}
    .container {max-width:1200px;margin:0 auto}
    .header {display:flex;justify-content:space-between;align-items:center;margin-bottom:2rem;padding:25px;background:rgba(189,189,189,0.15);border-radius:15px;border:1px solid rgba(66,66,66,0.3);box-shadow:0 8px 32px rgba(66,66,66,0.1);backdrop-filter:blur(10px)}
    .logo {font-size:2.2rem;background:linear-gradient(45deg,#424242,#616161);-webkit-background-clip:text;-webkit-text-fill-color:transparent;font-weight:700;text-shadow:0 0 20px rgba(66,66,66,0.3)}
    .header-buttons {display:flex;gap:15px}
    .header-btn {background:rgba(66,66,66,0.5);color:#eee;padding:12px 25px;border-radius:8px;text-decoration:none;transition:.3s;border:1px solid rgba(66,66,66,0.7);font-weight:600;box-shadow:0 4px 15px rgba(66,66,66,0.2)}
    .header-btn:hover {transform:translateY(-2px);box-shadow:0 6px 20px rgba(66,66,66,0.3);background:rgba(66,66,66,0.7);color:#FFFFFF}
    .section-title {font-size:1.8rem;margin-bottom:1.5rem;color:#EEEEEE;text-align:center;font-weight:700;text-shadow:0 0 10px rgba(66,66,66,0.3)}
    .edit-section {background:rgba(189,189,189,0.15);padding:30px;border-radius:15px;border:1px solid rgba(66,66,66,0.3);box-shadow:0 8px 32px rgba(66,66,66,0.1);backdrop-filter:blur(10px);max-width:800px;margin:0 auto}
    .file-info {display:none}
    .form-grid {display:grid;gap:15px}
    .input-group {display:flex;flex-direction:column;gap:8px}
    .input-label {color:#EEEEEE;font-weight:600;font-size:.9rem}
    .json-input {background:rgba(66,66,66,0.3);border:1px solid rgba(66,66,66,0.5);border-radius:8px;padding:12px 15px;color:#EEEEEE;font-family:'Courier New',monospace;font-size:.9rem;transition:.3s}
    .json-input:focus {outline:none;border-color:rgba(66,66,66,0.7);box-shadow:0 0 10px rgba(66,66,66,0.3);background:rgba(66,66,66,0.4);color:#EEEEEE}
    .form-actions {display:grid;grid-template-columns:1fr 1fr;gap:15px;margin-top:25px}
    .save-btn,.back-btn {padding:15px;border-radius:8px;cursor:pointer;font-weight:600;font-size:1rem;border:1px solid rgba(97,97,97,0.7);transition:.3s;text-align:center}
    .save-btn {background:rgba(66,66,66,0.5);color:#EEEEEE}
    .save-btn:hover {transform:translateY(-2px);box-shadow:0 6px 20px rgba(97,97,97,0.3);background:rgba(66,66,66,0.7);color:#FFFFFF}
    .back-btn {background:rgba(97,97,97,0.5);color:#EEEEEE;text-decoration:none}
    .back-btn:hover {transform:translateY(-2px);box-shadow:0 6px 20px rgba(117,117,117,0.3);background:rgba(97,97,97,0.7);color:#FFFFFF}
    @media(max-width:768px){.header{flex-direction:column;gap:15px}.header-buttons{flex-direction:column;width:100%}.header-btn{width:100%}.form-actions{grid-template-columns:1fr}.edit-section{padding:20px}}
</style>

<div class="container">
    <div class="header">
        <div class="logo">JSON Editor</div>
        <div class="header-buttons">
            <a href="<?= site_url('file-manager') ?>" class="header-btn">📁 File Manager</a>
        </div>
    </div>

    <h2 class="section-title">✏️ Edit JSON File</h2>

    <div class="edit-section">

        <form method="post">
            <input type="hidden" name="<?= csrf_token() ?>" value="<?= csrf_hash() ?>" />

            <div class="form-grid">
                <?php foreach ($jsonData as $key => $val): ?>
                    <div class="input-group">
                        <label class="input-label"><?= esc($key) ?></label>
                        <input type="text" class="json-input" name="<?= esc($key) ?>" value="<?= esc($val) ?>">
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="form-actions">
                <a href="<?= site_url('file-manager') ?>" class="back-btn">⬅️ Back</a>
                <button type="submit" class="save-btn">💾 Save Changes</button>
            </div>
        </form>

    </div>
</div>

<?= $this->endSection() ?>