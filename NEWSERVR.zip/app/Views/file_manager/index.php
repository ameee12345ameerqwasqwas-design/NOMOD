<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>
<style>
    body {
        background: linear-gradient(135deg, #0c0c0c 0%, #1a1a2e 50%, #16213e 100%); 
        color: #fff; 
        min-height: 100vh;
    }
    
    .cosmic-card {
        background: rgba(189, 189, 189, 0.15);
        border-radius: 10px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
        border: 1px solid rgba(66, 66, 66, 0.3);
        backdrop-filter: blur(10px);
        margin-bottom: 20px;
        overflow: hidden;
    }

    .cosmic-header {
        background: linear-gradient(45deg, #424242, #424242);
        color: #EEEEEE;
        border-radius: 10px 10px 0 0 !important;
        padding: 15px 20px;
        font-weight: 600;
        border-bottom: 1px solid rgba(66, 66, 66, 0.3);
    }
    
    .upload-area {
        transition: all 0.3s ease;
        background: rgba(189, 189, 189, 0.15);
        border: 1px solid rgba(66, 66, 66, 0.3);
        border-radius: 10px;
        backdrop-filter: blur(10px);
        padding: 25px;
    }
    
    .upload-area:hover {
        transform: scale(1.02);
        box-shadow: 0 10px 25px rgba(66, 66, 66, 0.2);
    }
    
    .files-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 20px;
        margin-top: 30px;
    }
    
    .file-card {
        background: rgba(189, 189, 189, 0.15);
        border: 1px solid rgba(66, 66, 66, 0.3);
        border-radius: 10px;
        backdrop-filter: blur(10px);
        box-shadow: 0 8px 32px rgba(66, 66, 66, 0.1);
        padding: 20px;
        transition: all 0.3s ease;
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
    }
    
    .file-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 35px rgba(66, 66, 66, 0.2);
    }
    
    .file-icon {
        font-size: 3rem;
        text-align: center;
        margin-bottom: 15px;
        color: #616161;
    }
    
    .file-name {
        font-size: 1.1rem;
        font-weight: 600;
        text-align: center;
        margin-bottom: 10px;
        word-break: break-word;
        color: #EEEEEE;
        width: 100%;
    }
    
    .file-details {
        text-align: center;
        margin-bottom: 20px;
        color: #FFFFFF;
        font-size: 0.9rem;
        width: 100%;
    }
    
    .file-details div {
        margin-bottom: 5px;
    }
    
    .expiration-info {
        background: rgba(66, 66, 66, 0.3);
        border-radius: 6px;
        padding: 8px;
        margin: 10px 0;
        font-size: 0.85rem;
        width: 100%;
    }
    
    .expiration-unlimited {
        border-left: 3px solid #28a745;
    }
    
    .expiration-limited {
        border-left: 3px solid #ffc107;
    }
    
    .expiration-expired {
        border-left: 3px solid #dc3545;
    }
    
    .file-actions {
        display: grid;
        grid-template-columns: 1fr;
        gap: 10px;
        width: 100%;
    }
    
    .btn-action {
        padding: 12px;
        border: none;
        border-radius: 8px;
        font-weight: 600;
        transition: all 0.3s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        width: 100%;
    }
    
    .btn-copy {
        background: rgba(66, 66, 66, 0.5);
        border: 1px solid rgba(66, 66, 66, 0.7);
        color: #EEEEEE;
    }
    
    .btn-copy:hover {
        background: rgba(66, 66, 66, 0.7);
        color: #FFFFFF;
    }
    
    .btn-edit {
        background: rgba(66, 66, 66, 0.5);
        border: 1px solid rgba(66, 66, 66, 0.7);
        color: #EEEEEE;
    }
    
    .btn-edit:hover {
        background: rgba(66, 66, 66, 0.7);
        color: #FFFFFF;
    }
    
    .btn-delete {
        background: rgba(97, 97, 97, 0.5);
        border: 1px solid rgba(97, 97, 97, 0.7);
        color: #EEEEEE;
    }
    
    .btn-delete:hover {
        background: rgba(97, 97, 97, 0.7);
        color: #FFFFFF;
    }
    
    .btn-ios {
        background: rgba(66, 66, 66, 0.5);
        border: 1px solid rgba(66, 66, 66, 0.7);
        color: #EEEEEE;
        padding: 10px 20px;
        border-radius: 8px;
        font-weight: 600;
        transition: all 0.3s ease;
    }

    .btn-ios:hover {
        background: rgba(66, 66, 66, 0.7);
        transform: translateY(-2px);
    }
    
    .form-control {
        background: rgba(66, 66, 66, 0.3);
        border: 1px solid rgba(66, 66, 66, 0.5);
        color: #EEEEEE;
    }
    
    .form-control:focus {
        background: rgba(66, 66, 66, 0.4);
        border-color: rgba(66, 66, 66, 0.7);
        box-shadow: 0 0 10px rgba(66, 66, 66, 0.3);
        color: #EEEEEE;
    }
    
    .notification-card {
        border-radius: 12px;
        margin-bottom: 20px;
        border: none;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        background: rgba(189, 189, 189, 0.15);
        border: 1px solid rgba(66, 66, 66, 0.3);
    }
    
    .notification-info {
        border-left: 4px solid #17a2b8;
    }
    
    .notification-warning {
        border-left: 4px solid #ffc107;
    }
    
    .notification-success {
        border-left: 4px solid #28a745;
    }
    
    .notification-danger {
        border-left: 4px solid #dc3545;
    }
    
    .progress {
        background: rgba(0, 0, 0, 0.4);
        border: 1px solid rgba(66, 66, 66, 0.3);
        height: 20px;
        border-radius: 10px;
        overflow: hidden;
    }
    
    .progress-bar {
        background: linear-gradient(45deg, #28a745, #20c997);
        height: 100%;
        transition: width 0.3s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 12px;
        font-weight: bold;
        color: white;
        text-shadow: 1px 1px 2px rgba(0,0,0,0.5);
    }
    
    .empty-state {
        text-align: center;
        padding: 40px;
        color: #B0B0B0;
    }
    
    .empty-state i {
        font-size: 4rem;
        margin-bottom: 20px;
        color: #616161;
    }
    
    .file-info {
        background: rgba(66, 66, 66, 0.2);
        border-radius: 5px;
        padding: 5px 10px;
        margin: 5px 0;
        font-size: 0.8rem;
    }
</style>

<div class="container-fluid py-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <div class="cosmic-card">
                <div class="cosmic-header py-3">
                    <h3 class="card-title mb-0 text-center text-white">
                        <i class="bi bi-folder me-2"></i> File Manager
                    </h3>
                </div>
                <div class="card-body p-4">
                    <?php if (session()->has('msgSuccess')): ?>
                        <div class="notification-card notification-success p-3">
                            <?= session('msgSuccess') ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (session()->has('msgWarning')): ?>
                        <div class="notification-card notification-warning p-3">
                            <?= session('msgWarning') ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (session()->has('msgDanger')): ?>
                        <div class="notification-card notification-danger p-3">
                            <?= session('msgDanger') ?>
                        </div>
                    <?php endif; ?>

                    <div class="upload-area mb-4">
                        <form id="uploadForm" action="<?= base_url('file-manager/upload') ?>" method="post" enctype="multipart/form-data" class="space-y-4">
                            <input type="hidden" name="<?= csrf_token() ?>" value="<?= csrf_hash() ?>" />
                            <div class="mb-3">
                                <label for="fileToUpload" class="form-label">Select Files to Upload</label>
                                <input type="file" name="fileToUpload[]" id="fileToUpload" accept=".so,.zip,.json,.apk" 
                                       class="form-control" multiple>
                                <div class="form-text">You can select multiple files at once</div>
                            </div>
                            <div class="mb-3">
                                <label for="expiration" class="form-label">File Expiration</label>
                                <select name="expiration" id="expiration" class="form-control">
                                    <option value="unlimited">Unlimited</option>
                                    <option value="1hour">1 Hour</option>
                                    <option value="2hours">2 Hours</option>
                                    <option value="1day">1 Day</option>
                                    <option value="3days">3 Days</option>
                                    <option value="7days">7 Days</option>
                                    <option value="15days">15 Days</option>
                                    <option value="30days">30 Days</option>
                                    <option value="60days">60 Days</option>
                                </select>
                            </div>
                            <button type="submit" class="btn-ios w-100">
                                <i class="bi bi-upload me-2"></i> Upload File(s)
                            </button>
                            
                            <div id="uploadProgress" class="mt-3" style="display: none;">
                                <div class="d-flex justify-content-between mb-1">
                                    <span id="progressText">Preparing upload...</span>
                                    <span id="progressPercent">0%</span>
                                </div>
                                <div id="progressBar" class="progress">
                                    <div id="progressBarFill" class="progress-bar" role="progressbar" style="width: 0%">0%</div>
                                </div>
                                <div id="fileInfo" class="mt-2"></div>
                            </div>
                        </form>
                    </div>

                    <div class="files-grid">
                        <?php if (empty($files)): ?>
                            <div class="empty-state">
                                <i class="bi bi-folder-x"></i>
                                <h4>No files uploaded yet</h4>
                                <p>Upload your first file to get started</p>
                            </div>
                        <?php else: 
                            foreach ($files as $file): 
                                $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
                                $icon = 'bi-file-earmark';
                                if ($extension === 'so') $icon = 'bi-gear';
                                if ($extension === 'zip') $icon = 'bi-file-earmark-zip';
                                if ($extension === 'json') $icon = 'bi-file-earmark-code';
                                if ($extension === 'apk') $icon = 'bi-phone';
                                
                                $expirationClass = 'expiration-unlimited';
                                if ($file['expiration'] !== 'Unlimited' && $file['expiration'] !== 'Expired') {
                                    $expirationClass = 'expiration-limited';
                                } elseif ($file['expiration'] === 'Expired') {
                                    $expirationClass = 'expiration-expired';
                                }
                        ?>
                            <div class="file-card">
                                <div class="file-icon">
                                    <i class="bi <?= $icon ?>"></i>
                                </div>
                                <div class="file-name">
                                    <?= esc($file['name']) ?>
                                </div>
                                <div class="file-details">
                                    <div><?= esc($file['size']) ?></div>
                                    <div><?= esc($file['uploaded_at']) ?></div>
                                </div>
                                <div class="expiration-info <?= $expirationClass ?>">
                                    <div><strong>Expiration:</strong> <?= esc($file['expiration']) ?></div>
                                    <?php if ($file['time_left'] !== 'Never' && $file['time_left'] !== 'File deleted'): ?>
                                        <div><strong>Time Left:</strong> <?= esc($file['time_left']) ?></div>
                                        <div><strong>Delete Date:</strong> <?= esc($file['delete_date']) ?></div>
                                    <?php elseif ($file['time_left'] === 'File deleted'): ?>
                                        <div class="text-danger"><strong>Status:</strong> Expired and deleted</div>
                                    <?php else: ?>
                                        <div><strong>Status:</strong> Permanent</div>
                                    <?php endif; ?>
                                </div>
                                <div class="file-actions">
                                    <button onclick="copyFileLink('<?= esc($file['direct_link']) ?>')" class="btn-action btn-copy">
                                        <i class="bi bi-clipboard"></i> Copy Link
                                    </button>
                                    <?php if ($extension === 'json'): ?>
                                        <a href="<?= esc($file['edit_link']) ?>" class="btn-action btn-edit">
                                            <i class="bi bi-pencil"></i> Edit
                                        </a>
                                    <?php endif; ?>
                                    <button onclick="deleteFile('<?= esc($file['name']) ?>')" class="btn-action btn-delete">
                                        <i class="bi bi-trash"></i> Delete
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; 
                        endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function copyFileLink(url) {
    navigator.clipboard.writeText(url).then(function() {
        Swal.fire({
            icon: 'success',
            title: 'Link Copied!',
            text: 'Direct file link has been copied to clipboard',
            timer: 1500,
            showConfirmButton: false
        });
    }).catch(function() {
        const tempInput = document.createElement('input');
        tempInput.value = url;
        document.body.appendChild(tempInput);
        tempInput.select();
        document.execCommand('copy');
        document.body.removeChild(tempInput);
        
        Swal.fire({
            icon: 'success',
            title: 'Link Copied!',
            text: 'Direct file link has been copied to clipboard',
            timer: 1500,
            showConfirmButton: false
        });
    });
}

function deleteFile(filename) {
    Swal.fire({
        title: 'Are you sure?',
        text: `You are about to delete ${filename}`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            fetch('<?= base_url('file-manager/delete') ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: `<?= csrf_token() ?>=<?= csrf_hash() ?>&filename=${encodeURIComponent(filename)}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Deleted!',
                        text: data.message || 'File has been deleted.',
                        timer: 1500,
                        showConfirmButton: false
                    }).then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: data.message || 'Failed to delete file'
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Failed to delete file'
                });
            });
        }
    });
}

document.getElementById('uploadForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    var fileInput = document.getElementById('fileToUpload');
    var files = fileInput.files;
    
    if (files.length === 0) {
        Swal.fire({
            icon: 'error',
            title: 'No Files Selected',
            text: 'Please select at least one file to upload.'
        });
        return false;
    }
    
    for (var i = 0; i < files.length; i++) {
        var fileName = files[i].name;
        var allowedExtensions = /(\.so|\.json|\.zip|\.apk)$/i;
        
        if (!allowedExtensions.exec(fileName)) {
            Swal.fire({
                icon: 'error',
                title: 'Invalid File Type',
                text: 'Only .json, .so, .zip and .apk files are allowed. Invalid file: ' + fileName
            });
            return false;
        }
    }
    
    var form = e.target;
    var formData = new FormData(form);
    
    var xhr = new XMLHttpRequest();
    var uploadProgress = document.getElementById('uploadProgress');
    var progressBarFill = document.getElementById('progressBarFill');
    var progressText = document.getElementById('progressText');
    var progressPercent = document.getElementById('progressPercent');
    var fileInfo = document.getElementById('fileInfo');
    
    uploadProgress.style.display = 'block';
    progressBarFill.style.width = '0%';
    progressBarFill.textContent = '0%';
    progressPercent.textContent = '0%';
    progressText.textContent = 'Preparing upload...';
    fileInfo.innerHTML = '';
    
    var totalSize = 0;
    for (var i = 0; i < files.length; i++) {
        totalSize += files[i].size;
    }
    
    var uploadedSize = 0;
    
    xhr.upload.onprogress = function(e) {
        if (e.lengthComputable) {
            uploadedSize = e.loaded;
            var percent = (uploadedSize / totalSize) * 100;
            var currentPercent = Math.round(percent);
            
            progressBarFill.style.width = percent + '%';
            progressBarFill.textContent = currentPercent + '%';
            progressPercent.textContent = currentPercent + '%';
            
            var uploadedMB = (uploadedSize / 1024 / 1024).toFixed(2);
            var totalMB = (totalSize / 1024 / 1024).toFixed(2);
            
            progressText.textContent = 'Uploading: ' + currentPercent + '% (' + uploadedMB + 'MB / ' + totalMB + 'MB)';
            
            if (files.length > 1) {
                var currentFileIndex = Math.floor((uploadedSize / totalSize) * files.length);
                currentFileIndex = Math.min(currentFileIndex, files.length - 1);
                var currentFile = files[currentFileIndex];
                fileInfo.innerHTML = '<div class="file-info">Current: ' + currentFile.name + ' (' + (currentFile.size / 1024 / 1024).toFixed(2) + 'MB)</div>';
            }
        }
    };
    
    xhr.onload = function() {
        uploadProgress.style.display = 'none';
        
        try {
            if (!xhr.responseText) {
                throw new Error('Empty server response');
            }
            
            let response;
            try {
                response = JSON.parse(xhr.responseText);
            } catch (parseError) {
                console.error('Parse error:', parseError, 'Response:', xhr.responseText);
                throw new Error('Invalid server response format');
            }
            
            if (response.success) {
                Swal.fire({
                    icon: 'success',
                    title: 'Success!',
                    text: response.message || 'Files uploaded successfully',
                    timer: 2000,
                    showConfirmButton: false
                }).then(() => {
                    location.reload();
                });
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Upload Failed',
                    text: response.message || 'Failed to upload files'
                });
            }
        } catch (error) {
            console.error('Error:', error);
            Swal.fire({
                icon: 'error',
                title: 'Upload Error',
                text: error.message || 'Failed to process server response'
            });
        }
    };
    
    xhr.onerror = function() {
        uploadProgress.style.display = 'none';
        console.error('Network error occurred');
        Swal.fire({
            icon: 'error',
            title: 'Network Error',
            text: 'Failed to connect to server. Please check your internet connection.'
        });
    };
    
    xhr.onabort = function() {
        uploadProgress.style.display = 'none';
        console.error('Upload aborted');
        Swal.fire({
            icon: 'warning',
            title: 'Upload Cancelled',
            text: 'The upload was cancelled.'
        });
    };
    
    xhr.timeout = 300000;
    
    xhr.ontimeout = function() {
        uploadProgress.style.display = 'none';
        console.error('Request timed out');
        Swal.fire({
            icon: 'error',
            title: 'Timeout Error',
            text: 'The upload took too long and was cancelled.'
        });
    };
    
    xhr.open('POST', form.action, true);
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
    xhr.send(formData);
});

document.getElementById('fileToUpload').addEventListener('change', function(e) {
    var files = e.target.files;
    var fileInfo = document.getElementById('fileInfo');
    
    if (files.length > 0) {
        var totalSize = 0;
        var fileList = '';
        
        for (var i = 0; i < files.length; i++) {
            totalSize += files[i].size;
            fileList += '<div class="file-info">' + files[i].name + ' (' + (files[i].size / 1024 / 1024).toFixed(2) + 'MB)</div>';
        }
        
        fileInfo.innerHTML = '<strong>Selected Files (' + files.length + '):</strong>' + fileList + 
                           '<div class="file-info"><strong>Total Size:</strong> ' + (totalSize / 1024 / 1024).toFixed(2) + 'MB</div>';
    } else {
        fileInfo.innerHTML = '';
    }
});
</script>
<?= $this->endSection() ?>