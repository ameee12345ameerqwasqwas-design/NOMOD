<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>

<style>
    .glass-card {
        background: rgba(80, 50, 140, 0.65) !important;
        backdrop-filter: blur(16px);
        border: 1px solid rgba(255,255,255,0.15);
        border-radius: 18px;
        box-shadow: 0 10px 35px rgba(0,0,0,0.4);
    }
    .section-card {
        background: rgba(255,255,255,0.08);
        border-radius: 14px;
        padding: 20px;
        margin-bottom: 25px;
        border: 1px solid rgba(167, 139, 250, 0.2);
    }
    .form-control, .form-select {
        background: rgba(255,255,255,0.1);
        border: 1px solid rgba(255,255,255,0.25);
        color: white;
    }
    .form-control:focus {
        background: rgba(255,255,255,0.18);
        border-color: #a78bfa;
        box-shadow: 0 0 0 0.25rem rgba(167, 139, 250, 0.3);
    }
    .preview-img {
        border: 3px solid #a78bfa;
        border-radius: 12px;
        box-shadow: 0 0 15px rgba(167, 139, 250, 0.5);
    }
    .btn-apply {
        background: linear-gradient(135deg, #7e5bef, #a78bfa);
        border: none;
        color: white;
        font-weight: 600;
    }
    .btn-apply:hover {
        background: linear-gradient(135deg, #6a4cc7, #9470db);
        transform: translateY(-2px);
    }
</style>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-lg-9">
            <?= $this->include('Layout/msgStatus') ?>

            <div class="glass-card p-4">
                <h3 class="text-white mb-4 text-center">
                    <i class="bi bi-gear-fill me-2"></i> Panel Settings
                </h3>

                <!-- ==================== Panel Name Section ==================== -->
                <div class="section-card">
                    <h5 class="text-white mb-3"><i class="bi bi-pencil-square me-2"></i> Panel Name</h5>
                    <?= form_open('panelsettings', ['method' => 'post']) ?>
                        <div class="mb-3">
                            <input type="hidden" name="action" value="update_name">
                            <input type="text" name="base_name" class="form-control" 
                                   value="<?= esc($base_name ?? '') ?>" placeholder="Panel Name" required>
                        </div>
                        <button type="submit" class="btn btn-apply w-100">
                            <i class="bi bi-save me-2"></i> Apply Name Change
                        </button>
                    <?= form_close() ?>
                </div>

                <!-- ==================== Telegram Section ==================== -->
                <div class="section-card">
                    <h5 class="text-white mb-3"><i class="bi bi-telegram me-2"></i> Telegram Link</h5>
                    <?= form_open('panelsettings', ['method' => 'post']) ?>
                        <div class="mb-3">
                            <input type="hidden" name="action" value="update_telegram">
                            <input type="text" name="telegram_link" class="form-control" 
                                   value="<?= esc($telegram_link ?? '') ?>" 
                                   placeholder="@username or https://t.me/OLLIIEN" required>
                        </div>
                        <button type="submit" class="btn btn-apply w-100">
                            <i class="bi bi-save me-2"></i> Apply Telegram Change
                        </button>
                    <?= form_close() ?>
                </div>

                <!-- ==================== Favicon Section ==================== -->
                <div class="section-card">
                    <h5 class="text-white mb-3"><i class="bi bi-image me-2"></i> Logo</h5>
                    <?= form_open_multipart('panelsettings', ['method' => 'post']) ?>
                        <input type="hidden" name="action" value="update_favicon">
                        
                        <div class="d-flex align-items-center gap-4 mb-3">
                            <img src="<?= $favicon_url ?? base_url('assets/favicon.ico') ?>?v=<?= time() ?>" 
                                 alt="Current Favicon" class="preview-img" width="80" height="80">
                            
                            <div class="flex-grow-1">
                                <input type="file" name="favicon" accept=".ico" class="form-control">
                                <small class="text-white-50 mt-2 d-block">Only .ico files allowed (64x64 recommended)</small>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-apply w-100">
                            <i class="bi bi-upload me-2"></i> Upload & Apply Favicon
                        </button>
                    <?= form_close() ?>
                </div>

            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>