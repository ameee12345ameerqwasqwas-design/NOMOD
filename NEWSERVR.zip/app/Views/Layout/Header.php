<?php $uri = service('uri'); ?>

<style>
/* ═══ SIDEBAR – Blood Red × Gazelle × Gold ═══ */
:root {
    --sb-bg: rgba(12, 3, 3, 0.92);
    --sb-border: rgba(139, 0, 0, 0.35);
    --sb-gold: #FFD700;
    --sb-gold-dim: rgba(255, 215, 0, 0.18);
    --sb-red: #8B0000;
    --sb-red-light: #A31515;
    --sb-red-glow: rgba(139, 0, 0, 0.55);
    --sb-gazelle: #C8956C;
    --sb-text: #e8e0d8;
}

/* ── Menu Button (floating) ── */
.menu-button {
    position: fixed;
    right: 22px;
    bottom: 22px;
    width: 58px;
    height: 58px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--sb-red), #6a0000);
    border: 2px solid rgba(255, 215, 0, 0.35);
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 5px;
    cursor: pointer;
    z-index: 1002;
    box-shadow: 0 0 20px var(--sb-red-glow), 0 5px 15px rgba(0,0,0,0.5);
    transition: all 0.35s cubic-bezier(.4,0,.2,1);
    animation: menuPulse 3s ease-in-out infinite;
}

@keyframes menuPulse {
    0%, 100% { box-shadow: 0 0 20px var(--sb-red-glow), 0 5px 15px rgba(0,0,0,0.5); }
    50% { box-shadow: 0 0 35px var(--sb-red-glow), 0 0 15px rgba(255,215,0,0.25), 0 5px 15px rgba(0,0,0,0.5); }
}

.menu-button span {
    display: block;
    width: 22px;
    height: 2px;
    background: #fff;
    border-radius: 1px;
    transition: all 0.35s ease;
    transform-origin: center;
}

.menu-button:hover {
    transform: scale(1.12) rotate(5deg);
    border-color: var(--sb-gold);
    background: linear-gradient(135deg, var(--sb-red-light), var(--sb-gazelle));
}

.menu-button.active {
    border-color: var(--sb-gold);
    animation: none;
    box-shadow: 0 0 25px var(--sb-gold-dim), 0 5px 15px rgba(0,0,0,0.5);
}

.menu-button.active span:nth-child(1) { transform: rotate(45deg) translate(5px, 5px); background: var(--sb-gold); }
.menu-button.active span:nth-child(2) { opacity: 0; transform: scaleX(0); }
.menu-button.active span:nth-child(3) { transform: rotate(-45deg) translate(5px, -5px); background: var(--sb-gold); }

/* ── Overlay ── */
.sidebar-overlay {
    position: fixed; inset: 0;
    background: rgba(5, 0, 0, 0.45);
    backdrop-filter: blur(0px);
    opacity: 0;
    visibility: hidden;
    transition: all 0.4s ease;
    z-index: 1001;
    pointer-events: none;
}

.sidebar-overlay.active {
    opacity: 1;
    visibility: visible;
    pointer-events: auto;
    backdrop-filter: blur(8px);
}

/* ── Sidebar Panel ── */
.sidebar {
    position: fixed;
    top: 0; bottom: 0;
    right: -340px;
    width: 310px;
    background: var(--sb-bg);
    backdrop-filter: blur(24px);
    -webkit-backdrop-filter: blur(24px);
    border-left: 1px solid var(--sb-border);
    box-shadow: -8px 0 40px rgba(0,0,0,0.7), inset 1px 0 0 rgba(255,215,0,0.06);
    z-index: 1002;
    display: flex;
    flex-direction: column;
    transition: right 0.42s cubic-bezier(0.19, 1, 0.22, 1);
    overflow: hidden;
}

.sidebar.active { right: 0; }

/* Glowing top line */
.sidebar::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 2px;
    background: linear-gradient(90deg, transparent, var(--sb-red), var(--sb-gold), var(--sb-red), transparent);
    animation: topGlow 3s linear infinite;
    background-size: 200% 100%;
}

@keyframes topGlow {
    0% { background-position: -200% 0; }
    100% { background-position: 200% 0; }
}

.sidebar-inner {
    flex: 1;
    overflow-y: auto;
    padding: 22px 18px;
    height: 100%;
}

.sidebar-inner::-webkit-scrollbar { width: 3px; }
.sidebar-inner::-webkit-scrollbar-track { background: transparent; }
.sidebar-inner::-webkit-scrollbar-thumb { background: rgba(139,0,0,0.5); border-radius: 2px; }

/* ── Sidebar Header ── */
.sidebar-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 20px;
    padding-bottom: 14px;
    border-bottom: 1px solid rgba(255,215,0,0.1);
}

.brand-wrapper { display: flex; align-items: center; gap: 11px; }

.brand-logo {
    width: 42px; height: 42px;
    border-radius: 10px;
    border: 1px solid rgba(255,215,0,0.25);
    background: rgba(139,0,0,0.15);
    padding: 2px;
}

.brand-name {
    font-size: 1.25rem;
    font-weight: 700;
    color: var(--sb-gold);
    letter-spacing: 0.5px;
    text-shadow: 0 0 12px rgba(255,215,0,0.35);
}

.close-sidebar {
    width: 32px; height: 32px;
    border-radius: 50%;
    background: rgba(139,0,0,0.15);
    border: 1px solid rgba(139,0,0,0.35);
    color: var(--sb-gazelle);
    cursor: pointer;
    transition: all 0.25s ease;
    display: flex; align-items: center; justify-content: center;
}

.close-sidebar:hover {
    transform: rotate(90deg);
    background: var(--sb-red);
    color: white;
    border-color: var(--sb-gold);
}

/* ── User profile card ── */
.user-profile-card {
    display: flex;
    align-items: center;
    gap: 14px;
    background: linear-gradient(135deg, rgba(139,0,0,0.2), rgba(200,149,108,0.08));
    border: 1px solid rgba(139,0,0,0.3);
    border-radius: 14px;
    padding: 16px;
    margin-bottom: 22px;
    transition: all 0.3s ease;
}

.user-profile-card:hover {
    border-color: rgba(255,215,0,0.3);
    background: linear-gradient(135deg, rgba(139,0,0,0.28), rgba(200,149,108,0.12));
    box-shadow: 0 4px 20px rgba(139,0,0,0.25);
}

.avatar-icon {
    width: 48px; height: 48px;
    border-radius: 12px;
    background: linear-gradient(135deg, var(--sb-red), var(--sb-gazelle));
    display: flex; align-items: center; justify-content: center;
    color: white;
    font-size: 1.1rem;
    flex-shrink: 0;
    box-shadow: 0 4px 12px rgba(139,0,0,0.4);
    animation: avatarFloat 4s ease-in-out infinite;
}

@keyframes avatarFloat {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-3px); }
}

/* ── Section title ── */
.menu-section-title {
    font-size: 0.72rem;
    color: var(--sb-gazelle);
    text-transform: uppercase;
    letter-spacing: 2px;
    margin: 18px 0 8px;
    padding-left: 8px;
    font-weight: 700;
    opacity: 0.75;
    position: relative;
}

.menu-section-title::after {
    content: '';
    position: absolute;
    left: 0; bottom: -4px;
    width: 30px; height: 1px;
    background: linear-gradient(90deg, var(--sb-red), transparent);
}

/* ── Sidebar links ── */
.sidebar a {
    display: flex;
    align-items: center;
    padding: 12px 15px;
    color: var(--sb-text);
    text-decoration: none;
    border-radius: 11px;
    margin-bottom: 5px;
    background: transparent;
    border: 1px solid transparent;
    font-size: 0.9rem;
    font-weight: 500;
    transition: all 0.25s ease;
    position: relative;
    overflow: hidden;
}

.sidebar a::before {
    content: '';
    position: absolute;
    left: -100%; top: 0; bottom: 0;
    width: 3px;
    background: linear-gradient(180deg, var(--sb-gold), var(--sb-red));
    transition: left 0.25s ease;
}

.sidebar a:hover::before { left: 0; }

.sidebar a .nav-icon {
    font-size: 1rem;
    width: 24px;
    text-align: center;
    margin-right: 13px;
    flex-shrink: 0;
    transition: all 0.25s ease;
}

/* ── Per-button unique animations on hover ── */
/* Home – heartbeat */
.nav-home:hover .nav-icon { animation: heartbeat 0.6s ease infinite; color: var(--sb-gold); }
@keyframes heartbeat { 0%,100%{transform:scale(1)} 50%{transform:scale(1.35)} }

/* Keys – spin */
.nav-keys:hover .nav-icon { animation: keySpin 0.6s linear; color: var(--sb-gold); }
@keyframes keySpin { 0%{transform:rotate(0)} 100%{transform:rotate(360deg)} }

/* Generate – bounce */
.nav-generate:hover .nav-icon { animation: iconBounce 0.5s ease; color: var(--sb-gold); }
@keyframes iconBounce { 0%,100%{transform:translateY(0)} 40%{transform:translateY(-6px)} 70%{transform:translateY(-3px)} }

/* File Manager – swing */
.nav-files:hover .nav-icon { animation: iconSwing 0.6s ease; color: var(--sb-gold); transform-origin: top center; }
@keyframes iconSwing { 0%,100%{transform:rotate(0)} 25%{transform:rotate(-10deg)} 75%{transform:rotate(8deg)} }

/* Notifications – ring */
.nav-notif:hover .nav-icon { animation: ringShake 0.5s ease; color: var(--sb-gold); }
@keyframes ringShake { 0%,100%{transform:rotate(0)} 20%{transform:rotate(-15deg)} 40%{transform:rotate(15deg)} 60%{transform:rotate(-10deg)} 80%{transform:rotate(10deg)} }

/* Games – flip */
.nav-games:hover .nav-icon { animation: iconFlip 0.6s ease; color: var(--sb-gold); }
@keyframes iconFlip { 0%{transform:rotateY(0)} 50%{transform:rotateY(180deg)} 100%{transform:rotateY(360deg)} }

/* Game Manager – rotate */
.nav-gm:hover .nav-icon { animation: iconRot 0.7s linear; color: var(--sb-gold); }
@keyframes iconRot { 0%{transform:rotate(0)} 100%{transform:rotate(-360deg)} }

/* Bots – wave */
.nav-bots:hover .nav-icon { animation: iconWave 0.7s ease; color: var(--sb-gold); }
@keyframes iconWave { 0%,100%{transform:translateX(0)} 25%{transform:translateX(4px)} 75%{transform:translateX(-4px)} }

/* SDK – glow pulse */
.nav-sdk:hover .nav-icon { animation: sdkGlow 0.8s ease infinite; color: var(--sb-gold); }
@keyframes sdkGlow { 0%,100%{filter:drop-shadow(0 0 0 transparent)} 50%{filter:drop-shadow(0 0 6px gold)} }

/* Settings – gear */
.nav-settings:hover .nav-icon { animation: gearSpin 1s linear infinite; color: var(--sb-gold); }
@keyframes gearSpin { 0%{transform:rotate(0)} 100%{transform:rotate(360deg)} }

/* Server – radar */
.nav-server:hover .nav-icon { animation: radarPing 0.8s ease infinite; color: var(--sb-gold); }
@keyframes radarPing { 0%,100%{transform:scale(1);opacity:1} 50%{transform:scale(1.3);opacity:0.6} }

/* Panel Settings – zoom */
.nav-panel:hover .nav-icon { animation: panelZoom 0.4s ease; color: var(--sb-gold); }
@keyframes panelZoom { 0%{transform:scale(1)} 50%{transform:scale(1.4)} 100%{transform:scale(1)} }

/* Manage Users – slide */
.nav-users:hover .nav-icon { animation: usersSlide 0.5s ease; color: var(--sb-gold); }
@keyframes usersSlide { 0%{transform:translateX(0)} 30%{transform:translateX(5px)} 70%{transform:translateX(-3px)} 100%{transform:translateX(0)} }

/* Referral – flash */
.nav-ref:hover .nav-icon { animation: iconFlash 0.4s ease; color: var(--sb-gold); }
@keyframes iconFlash { 0%,100%{opacity:1} 50%{opacity:0.2} }

/* Extend Keys – stretch */
.nav-extend:hover .nav-icon { animation: iconStretch 0.5s ease; color: var(--sb-gold); }
@keyframes iconStretch { 0%,100%{transform:scaleX(1)} 50%{transform:scaleX(1.4)} }

/* Logout – exit slide */
.nav-logout:hover .nav-icon { animation: exitSlide 0.5s ease forwards; color: #ff6b6b; }
@keyframes exitSlide { 0%{transform:translateX(0)} 100%{transform:translateX(6px)} }

/* Default hover */
.sidebar a:hover {
    background: linear-gradient(135deg, rgba(139,0,0,0.25), rgba(200,149,108,0.08));
    border-color: rgba(139,0,0,0.35);
    color: white;
    transform: translateX(-4px);
    box-shadow: 0 4px 15px rgba(0,0,0,0.3);
}

.sidebar a.active {
    background: linear-gradient(135deg, rgba(139,0,0,0.4), rgba(200,149,108,0.12));
    border-color: rgba(255,215,0,0.3);
    color: var(--sb-gold);
    box-shadow: 0 4px 18px rgba(139,0,0,0.3), inset 0 0 12px rgba(255,215,0,0.05);
}

.sidebar a.active .nav-icon { color: var(--sb-gold); text-shadow: 0 0 8px var(--sb-gold); }
.sidebar a.active::before { left: 0; }

/* ── Divider ── */
.sidebar-divider {
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(139,0,0,0.5), rgba(255,215,0,0.2), rgba(139,0,0,0.5), transparent);
    margin: 16px 0;
    border: none;
}

/* ── Logout link style ── */
.logout-link {
    margin-top: 12px !important;
    background: rgba(139,0,0,0.1) !important;
    border-color: rgba(139,0,0,0.3) !important;
    color: #ff8080 !important;
}
.logout-link:hover { background: rgba(139,0,0,0.3) !important; border-color: var(--sb-red) !important; color: #ffaaaa !important; }

/* ── SDK link style ── */
.sdk-link {
    background: linear-gradient(135deg, rgba(200,149,108,0.15), rgba(255,215,0,0.06)) !important;
    border-color: rgba(200,149,108,0.3) !important;
    color: var(--sb-gazelle) !important;
}
.sdk-link:hover { background: linear-gradient(135deg, rgba(200,149,108,0.3), rgba(255,215,0,0.1)) !important; color: var(--sb-gold) !important; }

@media (max-width: 768px) {
    .sidebar { width: 87%; max-width: 310px; }
}
</style>

<div class="sidebar-overlay" id="sidebarOverlay"></div>

<?php if ($uri->getSegment(1) != 'login') : ?>
    <div class="menu-button" id="menuButton" aria-label="Toggle menu">
        <span></span><span></span><span></span>
    </div>
<?php endif; ?>

<nav class="sidebar" id="sidebar" role="navigation" aria-label="Main navigation">
    <div class="sidebar-inner">
        <!-- Header -->
        <div class="sidebar-header">
            <div class="brand-wrapper">
                <img src="/assets/favicon.ico" alt="<?= BASE_NAME ?> Logo" class="brand-logo" loading="lazy">
                <span class="brand-name"><?= BASE_NAME ?></span>
            </div>
            <button class="close-sidebar" id="closeSidebar" aria-label="Close menu">
                <i class="fas fa-times" style="font-size:0.8rem;"></i>
            </button>
        </div>

        <?php if (session()->has('userid')) : ?>
            <!-- User Profile Card -->
            <div class="user-profile-card">
                <div class="avatar-icon">
                    <i class="fas fa-user-secret"></i>
                </div>
                <div style="min-width:0;">
                    <div style="color:#fff;font-size:1rem;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                        <?= getName($user) ?>
                    </div>
                    <div style="margin-top:5px;display:flex;gap:5px;flex-wrap:wrap;">
                        <span style="font-size:0.7rem;padding:3px 10px;border-radius:50px;background:rgba(139,0,0,0.25);color:#ffb0a0;border:1px solid rgba(139,0,0,0.4);">
                            <?= getLevel($user->level) ?>
                        </span>
                        <span style="font-size:0.7rem;padding:3px 10px;border-radius:50px;background:rgba(255,215,0,0.12);color:#FFD700;border:1px solid rgba(255,215,0,0.25);">
                            <i class="bi bi-wallet2"></i> <?= $user->saldo ?>
                        </span>
                    </div>
                </div>
            </div>

            <!-- ── MAIN MENU ── -->
            <span class="menu-section-title">Main</span>

            <a href="<?= site_url('dashboard') ?>"
               class="nav-home <?= $uri->getSegment(1) == 'dashboard' ? 'active' : '' ?>">
                <i class="fas fa-home nav-icon"></i><span>Dashboard</span>
            </a>

            <a href="<?= site_url('keys') ?>"
               class="nav-keys <?= ($uri->getSegment(1) == 'keys' && $uri->getSegment(2) == '') ? 'active' : '' ?>">
                <i class="fas fa-key nav-icon"></i><span>Keys</span>
            </a>

            <a href="<?= site_url('keys/generate') ?>"
               class="nav-generate <?= $uri->getSegment(2) == 'generate' ? 'active' : '' ?>">
                <i class="fas fa-plus-circle nav-icon"></i><span>Generate</span>
            </a>

            <a href="<?= site_url('keys/extend-view') ?>"
               class="nav-extend <?= $uri->getSegment(2) == 'extend-view' ? 'active' : '' ?>">
                <i class="fas fa-hourglass-half nav-icon"></i><span>Extend Keys</span>
            </a>

            <div class="sidebar-divider"></div>

            <!-- ── CONTENT ── -->
            <span class="menu-section-title">Content</span>

            <a href="<?= site_url('file-manager') ?>"
               class="nav-files <?= $uri->getSegment(1) == 'file-manager' ? 'active' : '' ?>">
                <i class="fas fa-folder-open nav-icon"></i><span>File Manager</span>
            </a>

            <a href="<?= site_url('notifications') ?>"
               class="nav-notif <?= $uri->getSegment(1) == 'notifications' ? 'active' : '' ?>">
                <i class="fas fa-bell nav-icon"></i><span>Notifications</span>
            </a>

            <a href="<?= site_url('games') ?>"
               class="nav-games <?= $uri->getSegment(1) == 'games' ? 'active' : '' ?>">
                <i class="fas fa-gamepad nav-icon"></i><span>Games</span>
            </a>

            <div class="sidebar-divider"></div>

            <!-- ── SYSTEM ── -->
            <span class="menu-section-title">System</span>

            <a href="<?= site_url('settings') ?>"
               class="nav-settings <?= $uri->getSegment(1) == 'settings' ? 'active' : '' ?>">
                <i class="fas fa-cog nav-icon"></i><span>Settings</span>
            </a>

            <a href="<?= site_url('sdk') ?>"
               class="nav-sdk sdk-link <?= $uri->getSegment(1) == 'sdk' ? 'active' : '' ?>">
                <i class="fas fa-cube nav-icon"></i><span>SDK / Server Lib</span>
            </a>

            <?php if ($user->level == 1) : ?>
                <div class="sidebar-divider"></div>
                <span class="menu-section-title">Admin</span>

                <a href="<?= site_url('Server') ?>"
                   class="nav-server <?= $uri->getSegment(1) == 'Server' ? 'active' : '' ?>">
                    <i class="fas fa-server nav-icon"></i><span>Online System</span>
                </a>

                <a href="<?= site_url('bots') ?>"
                   class="nav-bots <?= $uri->getSegment(1) == 'bots' ? 'active' : '' ?>">
                    <i class="fas fa-robot nav-icon"></i><span>Bots</span>
                </a>

                <a href="<?= site_url('game-manager') ?>"
                   class="nav-gm <?= $uri->getSegment(1) == 'game-manager' ? 'active' : '' ?>">
                    <i class="fas fa-tools nav-icon"></i><span>Game Manager</span>
                </a>

                <a href="<?= site_url('panelsettings') ?>"
                   class="nav-panel <?= $uri->getSegment(1) == 'panelsettings' ? 'active' : '' ?>">
                    <i class="fas fa-cogs nav-icon"></i><span>Panel Settings</span>
                </a>

                <a href="<?= site_url('admin/manage-users') ?>"
                   class="nav-users <?= ($uri->getSegment(1) == 'admin' && $uri->getSegment(2) == 'manage-users') ? 'active' : '' ?>">
                    <i class="fas fa-users nav-icon"></i><span>Manage Users</span>
                </a>

                <a href="<?= site_url('admin/create-referral') ?>"
                   class="nav-ref <?= ($uri->getSegment(1) == 'admin' && $uri->getSegment(2) == 'create-referral') ? 'active' : '' ?>">
                    <i class="fas fa-user-plus nav-icon"></i><span>Create Referral</span>
                </a>
            <?php endif; ?>

            <div class="sidebar-divider"></div>

            <a href="<?= site_url('logout') ?>" class="nav-logout logout-link">
                <i class="fas fa-sign-out-alt nav-icon"></i><span>Logout</span>
            </a>

        <?php endif; ?>
    </div>
</nav>

<script>
/* ── Audio Engine ── */
const AudioEngine = {
    ctx: null, masterGain: null,
    init() {
        if (!this.ctx) {
            this.ctx = new (window.AudioContext || window.webkitAudioContext)();
            this.masterGain = this.ctx.createGain();
            this.masterGain.connect(this.ctx.destination);
            this.masterGain.gain.value = 0.08;
        }
        if (this.ctx.state === 'suspended') this.ctx.resume();
    },
    play(freq, type = 'sine', dur = 0.1, vol = 1) {
        try {
            this.init();
            const t = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const g = this.ctx.createGain();
            osc.type = type; osc.frequency.setValueAtTime(freq, t);
            g.gain.setValueAtTime(0, t);
            g.gain.linearRampToValueAtTime(vol, t + 0.01);
            g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
            osc.connect(g); g.connect(this.masterGain);
            osc.start(t); osc.stop(t + dur);
            osc.onended = () => { osc.disconnect(); g.disconnect(); };
        } catch(e) {}
    },
    open()  { this.play(600, 'sine', 0.12, 0.35); },
    close() { this.play(350, 'sine', 0.1, 0.25); },
    hover() { this.play(900, 'sine', 0.05, 0.15); },
};

/* ── Sidebar Logic ── */
let isOpen = false;
const sidebar  = document.getElementById('sidebar');
const overlay  = document.getElementById('sidebarOverlay');
const menuBtn  = document.getElementById('menuButton');
const closeBtn = document.getElementById('closeSidebar');

function openSidebar() {
    if (isOpen) return;
    isOpen = true;
    AudioEngine.open();
    sidebar.classList.add('active');
    overlay.classList.add('active');
    if (menuBtn) menuBtn.classList.add('active');
    document.body.style.overflow = 'hidden';
    /* stagger-in sidebar items */
    setTimeout(() => {
        const items = sidebar.querySelectorAll('a, .user-profile-card, .menu-section-title');
        items.forEach((el, i) => {
            el.style.opacity = '0';
            el.style.transform = 'translateX(22px)';
            setTimeout(() => {
                el.style.transition = 'opacity 0.28s ease, transform 0.28s ease';
                el.style.opacity = '1';
                el.style.transform = 'translateX(0)';
            }, i * 35);
        });
    }, 80);
}

function closeSidebar() {
    if (!isOpen) return;
    isOpen = false;
    AudioEngine.close();
    sidebar.classList.remove('active');
    overlay.classList.remove('active');
    if (menuBtn) menuBtn.classList.remove('active');
    document.body.style.overflow = '';
    const items = sidebar.querySelectorAll('a, .user-profile-card, .menu-section-title');
    items.forEach(el => { el.style.opacity = ''; el.style.transform = ''; el.style.transition = ''; });
}

function toggleSidebar() { isOpen ? closeSidebar() : openSidebar(); }

if (menuBtn) menuBtn.addEventListener('click', toggleSidebar);
if (closeBtn) closeBtn.addEventListener('click', closeSidebar);
if (overlay)  overlay.addEventListener('click', closeSidebar);

document.addEventListener('keydown', e => { if (e.key === 'Escape' && isOpen) closeSidebar(); });

/* Touch swipe */
let touchStartX = 0;
if (sidebar) {
    sidebar.addEventListener('touchstart', e => { touchStartX = e.touches[0].clientX; }, { passive: true });
    sidebar.addEventListener('touchend', e => {
        if (!isOpen) return;
        if (e.changedTouches[0].clientX - touchStartX > 60) closeSidebar();
    }, { passive: true });
}

/* Close on mobile link click */
document.querySelectorAll('.sidebar a').forEach(link => {
    link.addEventListener('mouseenter', () => AudioEngine.hover());
    link.addEventListener('click', () => { if (window.innerWidth <= 768) setTimeout(closeSidebar, 120); });
});

window.addEventListener('resize', () => { if (window.innerWidth > 900 && isOpen) closeSidebar(); });
</script>
