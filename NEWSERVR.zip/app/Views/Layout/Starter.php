<!doctype html>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&family=Rajdhani:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <?= link_tag('assets/css/natacode.css') ?>
    <link rel="icon" type="image/x-icon" href="<?= base_url('assets/favicon.ico') ?>">
    <title><?= BASE_NAME ?> - <?= isset($title) ? $title : 'Panel' ?></title>
    <?= $this->renderSection('css') ?>
    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
</head>
<body>
    <!-- Animated dot canvas background -->
    <canvas id="dot-canvas" style="position:fixed;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:0;"></canvas>

    <?php
        $uri = service('uri');
        $current_page = $uri->getSegment(1);
    ?>
    <?php if ($current_page != 'login' && $current_page != 'register' && $current_page != '') : ?>
        <?= $this->include('Layout/Header') ?>
    <?php endif; ?>

    <main style="position:relative;z-index:1;">
        <div class="container p-4 py-3 mb-2">
            <?= $this->renderSection('content') ?>
        </div>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.1.0/sweetalert2.all.min.js"></script>
    <?= $this->renderSection('js') ?>

    <script>
    /* ── Animated Colored Dots Background ── */
    (function() {
        const canvas = document.getElementById('dot-canvas');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');
        const PALETTES = [
            [139, 0, 0],      // blood red
            [200, 149, 108],  // gazelle
            [255, 215, 0],    // gold
            [180, 50, 50],    // lighter red
            [220, 130, 60],   // warm amber
        ];
        let dots = [], W, H;
        function resize() { W = canvas.width = window.innerWidth; H = canvas.height = window.innerHeight; }
        window.addEventListener('resize', resize);
        resize();
        function createDot() {
            const col = PALETTES[Math.floor(Math.random() * PALETTES.length)];
            return {
                x: Math.random() * W, y: Math.random() * H,
                r: Math.random() * 3.5 + 1.5,
                vx: (Math.random() - 0.5) * 0.5, vy: (Math.random() - 0.5) * 0.5,
                alpha: Math.random() * 0.3 + 0.08,
                pulse: Math.random() * Math.PI * 2,
                pulseSpeed: 0.01 + Math.random() * 0.015,
                col: col
            };
        }
        for (let i = 0; i < 110; i++) dots.push(createDot());
        function draw() {
            ctx.clearRect(0, 0, W, H);
            for (let i = 0; i < dots.length; i++) {
                const d = dots[i];
                d.pulse += d.pulseSpeed;
                const a = d.alpha * (0.5 + 0.5 * Math.sin(d.pulse));
                ctx.beginPath();
                ctx.arc(d.x, d.y, d.r, 0, Math.PI * 2);
                ctx.fillStyle = `rgba(${d.col[0]},${d.col[1]},${d.col[2]},${a.toFixed(2)})`;
                ctx.fill();
                d.x += d.vx; d.y += d.vy;
                if (d.x < -10) d.x = W + 10;
                if (d.x > W + 10) d.x = -10;
                if (d.y < -10) d.y = H + 10;
                if (d.y > H + 10) d.y = -10;
                for (let j = i + 1; j < dots.length; j++) {
                    const e = dots[j];
                    const dx = d.x - e.x, dy = d.y - e.y;
                    const dist = Math.sqrt(dx * dx + dy * dy);
                    if (dist < 90) {
                        const ca = (1 - dist / 90) * 0.06;
                        ctx.beginPath();
                        ctx.moveTo(d.x, d.y); ctx.lineTo(e.x, e.y);
                        ctx.strokeStyle = `rgba(139,0,0,${ca.toFixed(3)})`;
                        ctx.lineWidth = 0.5;
                        ctx.stroke();
                    }
                }
            }
            requestAnimationFrame(draw);
        }
        draw();
    })();
    </script>
</body>
</html>
