<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>

<style>
    .cosmic-card {
        background: rgba(189, 189, 189, 0.15);
        border-radius: 10px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
        border: 1px solid rgba(66, 66, 66, 0.3);
        backdrop-filter: blur(10px);
        margin-bottom: 20px;
        overflow: hidden;
    }

    .cosmic-header {
        background: linear-gradient(45deg, #424242, #424242);
        color: #EEEEEE;
        border-radius: 10px 10px 0 0 !important;
        padding: 15px 20px;
        font-weight: 600;
        border-bottom: 1px solid rgba(66, 66, 66, 0.3);
    }

    .notification-card {
        border-radius: 12px;
        margin-bottom: 20px;
        border: none;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        background: rgba(189, 189, 189, 0.15);
        border: 1px solid rgba(66, 66, 66, 0.3);
    }
    
    .notification-info {
        border-left: 4px solid #17a2b8;
    }
    
    .notification-warning {
        border-left: 4px solid #ffc107;
    }
    
    .notification-success {
        border-left: 4px solid #28a745;
    }
    
    .notification-danger {
        border-left: 4px solid #dc3545;
    }
    
    .badge-target {
        font-size: 0.75em;
    }

    .btn-ios {
        background: rgba(66, 66, 66, 0.5);
        border: 1px solid rgba(66, 66, 66, 0.7);
        color: #EEEEEE;
        padding: 10px 20px;
        border-radius: 8px;
        font-weight: 600;
        transition: all 0.3s ease;
    }

    .btn-ios:hover {
        background: rgba(66, 66, 66, 0.7);
        transform: translateY(-2px);
    }

    .form-control {
        background: rgba(66, 66, 66, 0.3);
        border: 1px solid rgba(66, 66, 66, 0.5);
        color: #EEEEEE;
    }

    .form-control:focus {
        background: rgba(66, 66, 66, 0.4);
        border-color: rgba(66, 66, 66, 0.7);
        color: #EEEEEE;
    }

    .form-check-input:checked {
        background-color: #424242;
        border-color: #424242;
    }

    .api-link-section {
        background: rgba(66, 66, 66, 0.3);
        border: 1px solid rgba(66, 66, 66, 0.5);
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 20px;
    }

    .api-link {
        font-family: 'Courier New', monospace;
        background: rgba(0, 0, 0, 0.3);
        padding: 10px 15px;
        border-radius: 6px;
        color: #EEEEEE;
        word-break: break-all;
        font-size: 14px;
    }
</style>

<div class="container-fluid">
    <div class="api-link-section">
        <div class="d-flex justify-content-between align-items-center mb-2">
            <h6 class="mb-0" style="color: #EEEEEE; font-weight: 600;">API Notifications Endpoint</h6>
        </div>
        <div class="api-link"><?= site_url('api/notifications') ?></div>
    </div>

    <div class="row">
        <div class="col-12 col-md-6">
            <div class="cosmic-card">
                <div class="cosmic-header">Create New Notification</div>
                <div class="card-body">
                    <?= form_open('notifications', ['id' => 'notificationForm']) ?>
                    <input type="hidden" name="notification_form" value="1">
                    
                    <div class="form-group mb-3">
                        <label style="color: #EEEEEE;">Title</label>
                        <input type="text" name="title" class="form-control" required 
                               placeholder="Enter notification title">
                    </div>
                    
                    <div class="form-group mb-3">
                        <label style="color: #EEEEEE;">Message</label>
                        <textarea name="message" class="form-control" rows="4" required 
                                  placeholder="Enter notification message"></textarea>
                    </div>
                    
                    <div class="form-group mb-3">
                        <div class="form-check">
                            <input type="checkbox" name="is_active" class="form-check-input" id="is_active" checked>
                            <label class="form-check-label" for="is_active" style="color: #EEEEEE;">Active Notification</label>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn-ios">Create Notification</button>
                    <?= form_close() ?>
                </div>
            </div>
        </div>
        
        <div class="col-12 col-md-6">
            <div class="cosmic-card">
                <div class="cosmic-header">Active Notifications</div>
                <div class="card-body">
                    <?php if(empty($notifications)): ?>
                        <p class="text-center text-muted">No notifications found.</p>
                    <?php else: ?>
                        <?php foreach($notifications as $notification): ?>
                            <div class="card notification-card notification-<?= $notification->type ?>">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <h6 class="card-title mb-0" style="color: #EEEEEE;"><?= esc($notification->title) ?></h6>
                                        <span class="badge badge-target badge-<?= $notification->type ?>">
                                            <?= ucfirst($notification->target_users) ?>
                                        </span>
                                    </div>
                                    <p class="card-text" style="color: #EEEEEE;"><?= esc($notification->message) ?></p>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <small class="text-muted">
                                            <?= date('M d, Y H:i', strtotime($notification->created_at)) ?>
                                        </small>
                                        <div>
                                            <?php if($notification->is_active): ?>
                                                <span class="badge badge-success">Active</span>
                                            <?php else: ?>
                                                <span class="badge badge-secondary">Inactive</span>
                                            <?php endif; ?>
                                            
                                            <?= form_open('notifications', ['class' => 'd-inline']) ?>
                                                <input type="hidden" name="delete_notification" value="1">
                                                <input type="hidden" name="id" value="<?= $notification->id ?>">
                                                <button type="submit" class="btn btn-sm btn-danger ml-2" 
                                                        onclick="return confirm('Are you sure?')">Delete</button>
                                            <?= form_close() ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        <?php if(session()->getFlashdata('msgSuccess')): ?>
            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: '<?= session()->getFlashdata('msgSuccess') ?>',
                timer: 3000
            });
        <?php endif; ?>
    });
</script>

<?= $this->endSection() ?>