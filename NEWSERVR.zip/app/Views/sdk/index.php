<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>

<style>
.sdk-hero {
    background: linear-gradient(135deg, rgba(139,0,0,0.35) 0%, rgba(200,149,108,0.12) 100%);
    border: 1px solid rgba(139,0,0,0.35);
    border-radius: 20px;
    padding: 36px 32px;
    margin-bottom: 30px;
    position: relative;
    overflow: hidden;
}
.sdk-hero::before {
    content: '';
    position: absolute;
    top: -40px; right: -40px;
    width: 200px; height: 200px;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(255,215,0,0.1) 0%, transparent 70%);
    pointer-events: none;
}
.sdk-file-card {
    background: rgba(20, 5, 5, 0.85);
    border: 1px solid rgba(139,0,0,0.3);
    border-radius: 14px;
    padding: 20px;
    transition: all 0.3s ease;
    margin-bottom: 14px;
    display: flex;
    align-items: center;
    gap: 16px;
}
.sdk-file-card:hover {
    border-color: rgba(255,215,0,0.35);
    background: rgba(30,8,8,0.9);
    transform: translateX(-4px);
    box-shadow: 0 6px 24px rgba(0,0,0,0.4);
}
.sdk-file-icon {
    width: 48px; height: 48px;
    border-radius: 12px;
    background: linear-gradient(135deg, rgba(139,0,0,0.5), rgba(200,149,108,0.25));
    display: flex; align-items: center; justify-content: center;
    font-size: 1.3rem; color: #FFD700;
    flex-shrink: 0;
}
.sdk-badge {
    font-size: 0.72rem;
    padding: 3px 10px;
    border-radius: 50px;
    background: rgba(139,0,0,0.25);
    border: 1px solid rgba(139,0,0,0.4);
    color: #ffb0a0;
    font-weight: 600;
}
.sdk-badge-gold {
    background: rgba(255,215,0,0.12);
    border-color: rgba(255,215,0,0.3);
    color: #FFD700;
}
.sdk-info-box {
    background: rgba(10,2,2,0.9);
    border: 1px solid rgba(139,0,0,0.3);
    border-left: 3px solid #FFD700;
    border-radius: 10px;
    padding: 14px 18px;
    margin-bottom: 18px;
    font-size: 0.85rem;
    color: #C8956C;
}
.sdk-section-title {
    font-size: 0.75rem;
    text-transform: uppercase;
    letter-spacing: 2px;
    color: #C8956C;
    font-weight: 700;
    margin-bottom: 14px;
    padding-bottom: 8px;
    border-bottom: 1px solid rgba(139,0,0,0.2);
}
</style>

<div class="row">
    <div class="col-12">
        <!-- Hero Banner -->
        <div class="sdk-hero">
            <div class="d-flex align-items-center gap-3 mb-3">
                <div style="width:56px;height:56px;border-radius:14px;background:linear-gradient(135deg,#8B0000,#C8956C);display:flex;align-items:center;justify-content:center;font-size:1.5rem;color:#FFD700;box-shadow:0 6px 20px rgba(139,0,0,0.4);">
                    <i class="fas fa-cube"></i>
                </div>
                <div>
                    <h2 style="color:#FFD700;margin:0;font-size:1.5rem;font-weight:700;">SDK / Server Library</h2>
                    <p style="color:#C8956C;margin:0;font-size:0.85rem;">سيرفر مكتبة — Server-side authentication & activation library</p>
                </div>
            </div>
            <div class="d-flex gap-2 flex-wrap">
                <span class="sdk-badge"><i class="fas fa-shield-alt me-1"></i> PHP 7.4+</span>
                <span class="sdk-badge"><i class="fas fa-database me-1"></i> MySQL</span>
                <span class="sdk-badge sdk-badge-gold"><i class="fas fa-check-circle me-1"></i> Production Ready</span>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Left column: Files -->
    <div class="col-lg-7 mb-4">
        <div class="card">
            <div class="card-header">
                <i class="fas fa-folder-open me-2" style="color:#FFD700;"></i>
                SDK Files
            </div>
            <div class="card-body">
                <div class="sdk-section-title">Core Files</div>

                <!-- config.php -->
                <div class="sdk-file-card">
                    <div class="sdk-file-icon"><i class="fas fa-cog"></i></div>
                    <div class="flex-grow-1">
                        <div style="color:#fff;font-weight:600;">config.php</div>
                        <div style="color:#C8956C;font-size:0.8rem;">Database connection & configuration settings</div>
                        <span class="sdk-badge mt-1 d-inline-block">Requires DB credentials</span>
                    </div>
                </div>

                <!-- index.php -->
                <div class="sdk-file-card">
                    <div class="sdk-file-icon"><i class="fas fa-home"></i></div>
                    <div class="flex-grow-1">
                        <div style="color:#fff;font-weight:600;">index.php</div>
                        <div style="color:#C8956C;font-size:0.8rem;">Main entry point & request router</div>
                        <span class="sdk-badge mt-1 d-inline-block">Entry Point</span>
                    </div>
                </div>

                <!-- panel.php -->
                <div class="sdk-file-card">
                    <div class="sdk-file-icon"><i class="fas fa-tachometer-alt"></i></div>
                    <div class="flex-grow-1">
                        <div style="color:#fff;font-weight:600;">panel.php</div>
                        <div style="color:#C8956C;font-size:0.8rem;">Admin panel & dashboard interface</div>
                        <span class="sdk-badge sdk-badge-gold mt-1 d-inline-block">Admin</span>
                    </div>
                </div>

                <!-- login.php -->
                <div class="sdk-file-card">
                    <div class="sdk-file-icon"><i class="fas fa-sign-in-alt"></i></div>
                    <div class="flex-grow-1">
                        <div style="color:#fff;font-weight:600;">login.php</div>
                        <div style="color:#C8956C;font-size:0.8rem;">Authentication & session handler</div>
                        <span class="sdk-badge mt-1 d-inline-block">Auth</span>
                    </div>
                </div>

                <!-- verify.php -->
                <div class="sdk-file-card">
                    <div class="sdk-file-icon"><i class="fas fa-key"></i></div>
                    <div class="flex-grow-1">
                        <div style="color:#fff;font-weight:600;">verify.php</div>
                        <div style="color:#C8956C;font-size:0.8rem;">Key verification & activation endpoint</div>
                        <span class="sdk-badge sdk-badge-gold mt-1 d-inline-block">API Endpoint</span>
                    </div>
                </div>

                <!-- activations.php -->
                <div class="sdk-file-card">
                    <div class="sdk-file-icon"><i class="fas fa-check-double"></i></div>
                    <div class="flex-grow-1">
                        <div style="color:#fff;font-weight:600;">activations.php</div>
                        <div style="color:#C8956C;font-size:0.8rem;">Device activation management</div>
                        <span class="sdk-badge mt-1 d-inline-block">Management</span>
                    </div>
                </div>

                <div class="sdk-section-title mt-4">Assets</div>
                <div class="sdk-file-card">
                    <div class="sdk-file-icon"><i class="fas fa-folder"></i></div>
                    <div class="flex-grow-1">
                        <div style="color:#fff;font-weight:600;">includes/</div>
                        <div style="color:#C8956C;font-size:0.8rem;">Shared utilities, helpers, and partials</div>
                        <span class="sdk-badge mt-1 d-inline-block">Directory</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Right column: Setup Guide -->
    <div class="col-lg-5 mb-4">
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-book me-2" style="color:#FFD700;"></i>
                Setup Guide
            </div>
            <div class="card-body">
                <div class="sdk-info-box">
                    <i class="fas fa-info-circle me-2" style="color:#FFD700;"></i>
                    The SDK files are located in the <code style="color:#FFD700;">/sdk/</code> directory at the project root. Upload them to your server separately.
                </div>

                <div class="sdk-section-title">Steps</div>

                <div style="display:flex;flex-direction:column;gap:12px;">
                    <div style="display:flex;gap:12px;align-items:flex-start;">
                        <div style="width:28px;height:28px;border-radius:50%;background:linear-gradient(135deg,#8B0000,#A31515);display:flex;align-items:center;justify-content:center;color:#FFD700;font-size:0.75rem;font-weight:700;flex-shrink:0;">1</div>
                        <div>
                            <div style="color:#fff;font-weight:600;font-size:0.9rem;">Upload SDK files</div>
                            <div style="color:#C8956C;font-size:0.8rem;">Upload the <code>/sdk/</code> folder to your web server (Apache/Nginx)</div>
                        </div>
                    </div>
                    <div style="display:flex;gap:12px;align-items:flex-start;">
                        <div style="width:28px;height:28px;border-radius:50%;background:linear-gradient(135deg,#8B0000,#A31515);display:flex;align-items:center;justify-content:center;color:#FFD700;font-size:0.75rem;font-weight:700;flex-shrink:0;">2</div>
                        <div>
                            <div style="color:#fff;font-weight:600;font-size:0.9rem;">Edit config.php</div>
                            <div style="color:#C8956C;font-size:0.8rem;">Set your MySQL host, database, username and password</div>
                        </div>
                    </div>
                    <div style="display:flex;gap:12px;align-items:flex-start;">
                        <div style="width:28px;height:28px;border-radius:50%;background:linear-gradient(135deg,#8B0000,#A31515);display:flex;align-items:center;justify-content:center;color:#FFD700;font-size:0.75rem;font-weight:700;flex-shrink:0;">3</div>
                        <div>
                            <div style="color:#fff;font-weight:600;font-size:0.9rem;">Import DB tables</div>
                            <div style="color:#C8956C;font-size:0.8rem;">Run the panel's SQL schema to create required tables</div>
                        </div>
                    </div>
                    <div style="display:flex;gap:12px;align-items:flex-start;">
                        <div style="width:28px;height:28px;border-radius:50%;background:linear-gradient(135deg,#8B0000,#A31515);display:flex;align-items:center;justify-content:center;color:#FFD700;font-size:0.75rem;font-weight:700;flex-shrink:0;">4</div>
                        <div>
                            <div style="color:#fff;font-weight:600;font-size:0.9rem;">Point verify.php</div>
                            <div style="color:#C8956C;font-size:0.8rem;">Use the <code style="color:#FFD700;">verify.php</code> endpoint in your application for key checks</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick API Reference -->
        <div class="card">
            <div class="card-header">
                <i class="fas fa-code me-2" style="color:#FFD700;"></i>
                Quick API Reference
            </div>
            <div class="card-body">
                <div style="color:#C8956C;font-size:0.82rem;margin-bottom:10px;">
                    Send a POST request to <code style="color:#FFD700;">verify.php</code>:
                </div>
                <div class="code-block mb-3">
POST https://yourserver.com/sdk/verify.php<br>
Content-Type: application/x-www-form-urlencoded<br><br>
key=YOUR_KEY&device=DEVICE_ID&game=GAME_ID
                </div>
                <div style="color:#C8956C;font-size:0.82rem;margin-bottom:8px;">Response (JSON):</div>
                <div class="code-block">
{<br>
&nbsp; "status": "valid",<br>
&nbsp; "expires": "2025-12-31",<br>
&nbsp; "features": [...]<br>
}
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
