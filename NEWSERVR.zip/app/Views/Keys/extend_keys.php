<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>

<style>
    .cosmic-card {
        background: rgba(189, 189, 189, 0.15);
        border-radius: 10px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
        border: 1px solid rgba(66, 66, 66, 0.3);
        backdrop-filter: blur(10px);
        margin-bottom: 20px;
        overflow: hidden;
    }

    .cosmic-header {
        background: linear-gradient(45deg, #424242, #424242);
        color: #EEEEEE;
        border-radius: 10px 10px 0 0 !important;
        padding: 15px 20px;
        font-weight: 600;
        border-bottom: 1px solid rgba(66, 66, 66, 0.3);
    }

    .action-btn {
        background: rgba(66, 66, 66, 0.3);
        border: 1px solid rgba(66, 66, 66, 0.5);
        color: #BDBDBD;
        padding: 8px 12px;
        border-radius: 6px;
        transition: all 0.3s ease;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        justify-content: center;
    }

    .action-btn:hover {
        background: rgba(66, 66, 66, 0.5);
        color: #EEEEEE;
        transform: translateY(-2px);
    }

    .cosmic-form-control {
        border-radius: 8px;
        border: 1px solid rgba(66, 66, 66, 0.3);
        padding: 12px 15px;
        transition: all 0.3s ease;
        background: rgba(238, 238, 238, 0.1);
        color: #000000;
        width: 100%;
    }

    .cosmic-form-control:focus {
        border-color: #424242;
        box-shadow: 0 0 0 0.2rem rgba(66, 66, 66, 0.25);
        background: rgba(238, 238, 238, 0.15);
        color: #000000;
    }

    .cosmic-btn-primary {
        background: linear-gradient(45deg, #424242, #424242);
        border: none;
        border-radius: 8px;
        color: #EEEEEE;
        font-weight: 600;
        transition: all 0.3s ease;
        padding: 12px 24px;
        width: 100%;
    }

    .cosmic-btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(66, 66, 66, 0.4);
        background: linear-gradient(45deg, #353434, #424242);
        color: #EEEEEE;
    }

    .page-title {
        font-size: 1.2rem;
        font-weight: 700;
        color: #EEEEEE;
        display: flex;
        align-items: center;
        gap: 0.75rem;
        margin: 0;
    }

    .icon-glow {
        filter: drop-shadow(0 0 3px rgba(66, 66, 66, 0.5));
    }

    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .fade-in-up {
        animation: fadeInUp 0.6s ease-out;
    }
</style>

<div class="container py-3 fade-in-up">
    <div class="row justify-content-center">
        <div class="col-12">
            <div class="cosmic-card mb-4">
                <div class="cosmic-header">
                    <div class="row align-items-center">
                        <div class="col">
                            <h5 class="page-title">
                                <i class="fas fa-clock icon-glow"></i>
                                إضافة وقت للمفاتيح
                            </h5>
                        </div>
                        <div class="col-auto">
                            <div class="d-flex gap-2">
                                <a class="action-btn" href="<?= site_url('keys/generate') ?>" title="إنشاء مفتاح جديد">
                                    <i class="fas fa-plus"></i>
                                </a>
                                <a class="action-btn" href="<?= site_url('keys') ?>" title="عرض جميع المفاتيح">
                                    <i class="fas fa-key"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="cosmic-card">
                <div class="cosmic-header text-center">
                    <h5 class="page-title mb-0">
                        <i class="fas fa-clock icon-glow"></i>
                        إضافة وقت
                    </h5>
                </div>
                <div class="card-body p-4">
                    <form action="<?= site_url('keys/extend-all') ?>" method="post">
                        <?= csrf_field() ?>
                        
                        <div class="mb-4">
                            <select name="extension_hours" class="cosmic-form-control" required>
                                <option value="">اختر المدة...</option>
                                <?php foreach ($duration_options as $hours => $label): ?>
                                    <option value="<?= $hours ?>"><?= $label ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <button type="submit" class="btn cosmic-btn-primary">
                            <i class="fas fa-plus-circle me-2"></i>
                            إضافة الوقت
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>