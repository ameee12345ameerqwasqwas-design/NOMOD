<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>

<style>
    @import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css');
    
    .games-dashboard {
        background: rgba(189, 189, 189, 0.15);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(66, 66, 66, 0.3);
        border-radius: 15px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
        padding: 25px;
        margin-bottom: 25px;
    }
    
    .games-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 25px;
        padding-bottom: 15px;
        border-bottom: 1px solid rgba(66, 66, 66, 0.3);
    }
    
    .games-title {
        color: #000000;
        font-size: 1.8rem;
        font-weight: 700;
        margin: 0;
        display: flex;
        align-items: center;
        gap: 12px;
    }
    
    .games-title i {
        color: #000000;
        font-size: 1.5rem;
        background: rgba(66, 66, 66, 0.1);
        padding: 10px;
        border-radius: 10px;
    }
    
    .add-game-btn {
        background: linear-gradient(45deg, #424242, #424242);
        border: none;
        border-radius: 10px;
        color: #FFFFFF;
        font-weight: 600;
        padding: 12px 24px;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        gap: 10px;
        transition: all 0.3s ease;
        box-shadow: 0 4px 15px rgba(66, 66, 66, 0.3);
    }
    
    .add-game-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(66, 66, 66, 0.4);
        background: linear-gradient(45deg, #000000, #424242);
        color: #FFFFFF;
    }
    
    .game-card {
        background: rgba(189, 189, 189, 0.2);
        border: 1px solid rgba(66, 66, 66, 0.4);
        border-radius: 12px;
        padding: 20px;
        margin-bottom: 15px;
        transition: all 0.3s ease;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.15);
    }
    
    .game-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.25);
        border-color: rgba(66, 66, 66, 0.6);
    }
    
    .game-card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 1px solid rgba(66, 66, 66, 0.3);
    }
    
    .game-id {
        color: #000000;
        font-weight: 700;
        font-size: 0.9rem;
        background: rgba(66, 66, 66, 0.15);
        padding: 5px 12px;
        border-radius: 20px;
    }
    
    .game-status {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1rem;
    }
    
    .status-active {
        background: rgba(76, 175, 80, 0.3);
        color: #00C853;
        border: 2px solid rgba(0, 200, 83, 0.5);
    }
    
    .status-inactive {
        background: rgba(244, 67, 54, 0.3);
        color: #FF0000;
        border: 2px solid rgba(255, 0, 0, 0.5);
    }
    
    .game-info {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 15px;
        margin-bottom: 20px;
    }
    
    .info-item {
        display: flex;
        flex-direction: column;
        gap: 5px;
    }
    
    .info-label {
        color: #000000;
        font-size: 0.85rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 1px;
        opacity: 0.8;
    }
    
    .info-value {
        color: #000000;
        font-size: 1.1rem;
        font-weight: 700;
    }
    
    .game-code-value {
        background: rgba(66, 66, 66, 0.15);
        padding: 8px 15px;
        border-radius: 8px;
        font-family: 'Courier New', monospace;
        color: #000000;
        font-weight: 700;
        border: 1px solid rgba(66, 66, 66, 0.3);
    }
    
    .game-actions {
        display: flex;
        gap: 8px;
        justify-content: flex-end;
    }
    
    .action-btn {
        width: 36px;
        height: 36px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        text-decoration: none;
        transition: all 0.3s ease;
        border: 1px solid rgba(66, 66, 66, 0.4);
        background: rgba(66, 66, 66, 0.2);
        color: #000000;
        font-size: 0.9rem;
    }
    
    .action-btn:hover {
        transform: translateY(-2px);
        background: rgba(66, 66, 66, 0.4);
        color: #000000;
        box-shadow: 0 4px 12px rgba(66, 66, 66, 0.3);
        border-color: #000000;
    }
    
    .action-toggle:hover {
        border-color: #FFC107;
        color: #FFC107;
        background: rgba(255, 193, 7, 0.2);
    }
    
    .action-edit:hover {
        border-color: #2196F3;
        color: #2196F3;
        background: rgba(33, 150, 243, 0.2);
    }
    
    .action-delete:hover {
        border-color: #F44336;
        color: #F44336;
        background: rgba(244, 67, 54, 0.2);
    }
    
    .action-key:hover {
        border-color: #9C27B0;
        color: #9C27B0;
        background: rgba(156, 39, 176, 0.2);
    }
    
    .empty-state {
        text-align: center;
        padding: 60px 20px;
        background: rgba(189, 189, 189, 0.1);
        border-radius: 12px;
        border: 2px dashed rgba(66, 66, 66, 0.4);
    }
    
    .empty-icon {
        font-size: 3.5rem;
        color: rgba(0, 0, 0, 0.3);
        margin-bottom: 20px;
    }
    
    .empty-text {
        color: #000000;
        font-size: 1.1rem;
        margin-bottom: 25px;
        font-weight: 600;
        opacity: 0.8;
    }
    
    .alert-message {
        background: rgba(66, 66, 66, 0.25);
        border: 1px solid rgba(66, 66, 66, 0.4);
        border-radius: 10px;
        padding: 15px 20px;
        margin-bottom: 20px;
        color: #000000;
        display: flex;
        align-items: center;
        gap: 12px;
        font-weight: 600;
    }
    
    .alert-message i {
        color: #000000;
        font-size: 1.2rem;
    }
    
    .alert-success {
        background: rgba(76, 175, 80, 0.25);
        border-color: rgba(0, 200, 83, 0.5);
        color: #000000;
    }
    
    .alert-success i {
        color: #00C853;
    }
    
    .alert-danger {
        background: rgba(244, 67, 54, 0.25);
        border-color: rgba(255, 0, 0, 0.5);
        color: #000000;
    }
    
    .alert-danger i {
        color: #FF0000;
    }
    
    @media (max-width: 768px) {
        .games-header {
            flex-direction: column;
            gap: 15px;
            text-align: center;
        }
        
        .games-title {
            font-size: 1.5rem;
            color: #000000;
        }
        
        .game-info {
            grid-template-columns: 1fr;
        }
        
        .game-actions {
            justify-content: center;
        }
        
        .game-card {
            padding: 15px;
        }
        
        .info-value {
            color: #000000;
        }
        
        .info-label {
            color: #000000;
        }
    }
</style>

<div class="games-dashboard">
    <?php if (session()->getFlashdata('msgSuccess')): ?>
        <div class="alert-message alert-success">
            <i class="fas fa-check-circle"></i>
            <?= session()->getFlashdata('msgSuccess') ?>
        </div>
    <?php endif; ?>
    
    <?php if (session()->getFlashdata('msgDanger')): ?>
        <div class="alert-message alert-danger">
            <i class="fas fa-exclamation-circle"></i>
            <?= session()->getFlashdata('msgDanger') ?>
        </div>
    <?php endif; ?>

    <div class="games-header">
        <h1 class="games-title">
            <i class="fas fa-gamepad"></i>
            إدارة الألعاب
        </h1>
        <a href="<?= site_url('games/create') ?>" class="add-game-btn">
            <i class="fas fa-plus-circle"></i>
            إضافة لعبة جديدة
        </a>
    </div>

    <?php if (empty($games)): ?>
        <div class="empty-state">
            <i class="fas fa-gamepad empty-icon"></i>
            <div class="empty-text">لا توجد ألعاب مضافة بعد</div>
            <a href="<?= site_url('games/create') ?>" class="add-game-btn">
                <i class="fas fa-plus-circle"></i>
                إضافة أول لعبة
            </a>
        </div>
    <?php else: ?>
        <?php foreach ($games as $game): ?>
        <div class="game-card">
            <div class="game-card-header">
                <span class="game-id">ID: #<?= $game['id'] ?></span>
                <div class="game-status <?= $game['status'] == 1 ? 'status-active' : 'status-inactive' ?>">
                    <i class="fas fa-<?= $game['status'] == 1 ? 'check-circle' : 'times-circle' ?>"></i>
                </div>
            </div>
            
            <div class="game-info">
                <div class="info-item">
                    <span class="info-label">كود اللعبة</span>
                    <span class="game-code-value"><?= $game['game_code'] ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">اسم اللعبة</span>
                    <span class="info-value"><?= $game['game_name'] ?></span>
                </div>
            </div>
            
            <div class="game-actions">
                <a href="<?= site_url('games/toggleStatus/' . $game['id']) ?>" 
                   class="action-btn action-toggle" 
                   title="<?= $game['status'] == 1 ? 'تعطيل' : 'تفعيل' ?>">
                    <i class="fas fa-<?= $game['status'] == 1 ? 'ban' : 'check' ?>"></i>
                </a>
                <a href="<?= site_url('games/edit/' . $game['id']) ?>" 
                   class="action-btn action-edit" 
                   title="تعديل">
                    <i class="fas fa-edit"></i>
                </a>
                <a href="<?= site_url('games/delete/' . $game['id']) ?>" 
                   class="action-btn action-delete" 
                   title="حذف"
                   onclick="return confirm('هل أنت متأكد من حذف هذه اللعبة؟')">
                    <i class="fas fa-trash"></i>
                </a>
            </div>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?= $this->endSection() ?>