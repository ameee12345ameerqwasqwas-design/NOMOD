<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>

<style>
    .cosmic-card {
        background: rgba(189, 189, 189, 0.2);
        border-radius: 12px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
        border: 1px solid rgba(66, 66, 66, 0.4);
        backdrop-filter: blur(10px);
        margin-bottom: 20px;
        overflow: hidden;
    }

    .cosmic-header {
        background: linear-gradient(45deg, #424242, #424242);
        color: #FFFFFF;
        border-radius: 12px 12px 0 0;
        padding: 20px 25px;
        font-weight: 600;
        border-bottom: 1px solid rgba(66, 66, 66, 0.4);
    }

    .cosmic-form-control {
        border-radius: 8px;
        border: 1px solid rgba(66, 66, 66, 0.4);
        padding: 12px 15px;
        transition: all 0.3s ease;
        background: rgba(238, 238, 238, 0.15);
        color: #000000;
        width: 100%;
        font-weight: 500;
    }

    .cosmic-form-control:focus {
        border-color: #000000;
        box-shadow: 0 0 0 0.2rem rgba(0, 0, 0, 0.25);
        background: rgba(238, 238, 238, 0.2);
        color: #000000;
    }

    .cosmic-btn-primary {
        background: linear-gradient(45deg, #424242, #000000);
        border: none;
        border-radius: 8px;
        color: #FFFFFF;
        font-weight: 600;
        transition: all 0.3s ease;
        padding: 12px 24px;
        border: 1px solid rgba(66, 66, 66, 0.5);
    }

    .cosmic-btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.4);
        background: linear-gradient(45deg, #000000, #424242);
        color: #FFFFFF;
    }

    .cosmic-btn-secondary {
        background: rgba(66, 66, 66, 0.2);
        border: 1px solid rgba(66, 66, 66, 0.4);
        color: #000000;
        border-radius: 8px;
        font-weight: 600;
        transition: all 0.3s ease;
        padding: 12px 24px;
    }

    .cosmic-btn-secondary:hover {
        background: rgba(66, 66, 66, 0.4);
        color: #000000;
        border-color: rgba(66, 66, 66, 0.6);
    }

    .page-title {
        font-size: 1.3rem;
        font-weight: 700;
        color: #FFFFFF;
        display: flex;
        align-items: center;
        gap: 0.75rem;
        margin: 0;
    }

    .icon-glow {
        filter: drop-shadow(0 0 3px rgba(255, 255, 255, 0.3));
    }

    .form-label {
        color: #000000;
        font-weight: 600;
        margin-bottom: 8px;
        display: block;
        font-size: 0.95rem;
    }

    .form-text {
        color: rgba(0, 0, 0, 0.7);
        font-size: 0.85rem;
        margin-top: 5px;
        font-weight: 500;
    }

    .invalid-feedback {
        color: #FF0000;
        font-size: 0.85rem;
        margin-top: 5px;
        display: block;
        font-weight: 500;
    }

    .alert-danger {
        background: rgba(244, 67, 54, 0.2);
        border: 1px solid rgba(255, 0, 0, 0.3);
        color: #000000;
        border-radius: 8px;
        font-weight: 600;
    }

    .alert-danger i {
        color: #FF0000;
    }

    .form-control.is-invalid {
        border-color: #FF0000;
        background: rgba(255, 0, 0, 0.05);
    }
</style>

<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="cosmic-card">
                <div class="cosmic-header text-center">
                    <h5 class="page-title mb-0">
                        <i class="fas fa-plus-circle icon-glow"></i>
                        إضافة لعبة جديدة
                    </h5>
                </div>
                <div class="card-body p-4">
                    <?php if (session()->getFlashdata('msgDanger')): ?>
                        <div class="alert alert-danger mb-4 d-flex align-items-center">
                            <i class="fas fa-exclamation-circle me-2"></i>
                            <div><?= session()->getFlashdata('msgDanger') ?></div>
                        </div>
                    <?php endif; ?>
                    
                    <form method="post">
                        <?= csrf_field() ?>
                        
                        <div class="mb-4">
                            <label for="game_code" class="form-label">كود اللعبة *</label>
                            <input type="text" class="cosmic-form-control <?= isset($validation) && $validation->hasError('game_code') ? 'is-invalid' : '' ?>" 
                                   id="game_code" name="game_code" 
                                   value="<?= old('game_code') ?>" 
                                   placeholder="كود الجيم" required>
                            <?php if (isset($validation) && $validation->hasError('game_code')): ?>
                                <div class="invalid-feedback"><?= $validation->getError('game_code') ?></div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="mb-4">
                            <label for="game_name" class="form-label">اسم اللعبة *</label>
                            <input type="text" class="cosmic-form-control <?= isset($validation) && $validation->hasError('game_name') ? 'is-invalid' : '' ?>" 
                                   id="game_name" name="game_name" 
                                   value="<?= old('game_name') ?>" 
                                   placeholder="اسم الجيم" required>
                            <?php if (isset($validation) && $validation->hasError('game_name')): ?>
                                <div class="invalid-feedback"><?= $validation->getError('game_name') ?></div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="mb-4">
                            <label for="status" class="form-label">الحالة *</label>
                            <select class="cosmic-form-control <?= isset($validation) && $validation->hasError('status') ? 'is-invalid' : '' ?>" 
                                    id="status" name="status" required>
                                <option value="1" <?= old('status') == '1' ? 'selected' : 'selected' ?>>نشط</option>
                                <option value="0" <?= old('status') == '0' ? 'selected' : '' ?>>غير نشط</option>
                            </select>
                            <?php if (isset($validation) && $validation->hasError('status')): ?>
                                <div class="invalid-feedback"><?= $validation->getError('status') ?></div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="d-flex gap-3 mt-4 pt-3 border-top" style="border-color: rgba(66, 66, 66, 0.3) !important;">
                            <button type="submit" class="btn cosmic-btn-primary flex-fill">
                                <i class="fas fa-plus-circle me-2"></i>
                                إضافة اللعبة
                            </button>
                            <a href="<?= site_url('games') ?>" class="btn cosmic-btn-secondary">
                                <i class="fas fa-times me-2"></i>
                                إلغاء
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>