<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>

<style>
/* ── Login Page – Blood Red / Gazelle / Gold ── */
body {
    background: #0a0202 !important;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
}

.login-wrap {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    width: 100%;
    padding: 20px;
    position: relative;
    z-index: 10;
}

/* Sliding card – starts below, slides up */
.login-card {
    background: rgba(14, 3, 3, 0.9);
    backdrop-filter: blur(20px);
    -webkit-backdrop-filter: blur(20px);
    border: 1px solid rgba(139, 0, 0, 0.4);
    border-radius: 24px;
    width: 100%;
    max-width: 440px;
    padding: 44px 38px;
    position: relative;
    overflow: hidden;
    box-shadow: 0 25px 60px rgba(0,0,0,0.7), 0 0 40px rgba(139,0,0,0.15);
    animation: cardSlideIn 0.65s cubic-bezier(0.19, 1, 0.22, 1) both;
    transform-origin: center bottom;
}

@keyframes cardSlideIn {
    0%   { opacity: 0; transform: translateY(60px) scale(0.95); }
    100% { opacity: 1; transform: translateY(0) scale(1); }
}

/* gold top bar */
.login-card::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0;
    height: 2px;
    background: linear-gradient(90deg, transparent, #8B0000, #FFD700, #8B0000, transparent);
    background-size: 200% 100%;
    animation: barGlow 3s linear infinite;
}

@keyframes barGlow {
    0% { background-position: -200% 0; }
    100% { background-position: 200% 0; }
}

/* glow orb */
.login-card::after {
    content: '';
    position: absolute;
    top: -60px; right: -60px;
    width: 160px; height: 160px;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(139,0,0,0.3) 0%, transparent 70%);
    pointer-events: none;
    animation: orbPulse 4s ease-in-out infinite;
}

@keyframes orbPulse { 0%,100%{opacity:0.4} 50%{opacity:0.8} }

/* Logo */
.login-logo {
    text-align: center;
    margin-bottom: 30px;
}

.login-logo .logo-icon {
    width: 68px; height: 68px;
    border-radius: 20px;
    background: linear-gradient(135deg, #8B0000, #C8956C);
    display: inline-flex; align-items: center; justify-content: center;
    font-size: 1.8rem; color: #FFD700;
    box-shadow: 0 8px 30px rgba(139,0,0,0.5);
    margin-bottom: 14px;
    animation: logoBob 3s ease-in-out infinite;
}

@keyframes logoBob { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-6px)} }

.login-logo h2 {
    color: #FFD700;
    font-size: 1.55rem;
    font-weight: 700;
    margin: 0;
    letter-spacing: 0.5px;
    text-shadow: 0 0 15px rgba(255,215,0,0.3);
}

.login-logo p {
    color: #C8956C;
    font-size: 0.82rem;
    margin-top: 4px;
}

/* Form labels */
.login-card label {
    color: #C8956C !important;
    font-size: 0.82rem;
    font-weight: 600;
    margin-bottom: 6px;
    display: block;
    letter-spacing: 0.3px;
}

/* Inputs */
.login-input {
    background: rgba(30, 6, 6, 0.8) !important;
    border: 1px solid rgba(139, 0, 0, 0.4) !important;
    color: #fff !important;
    border-radius: 50px !important;
    padding: 12px 42px 12px 18px !important;
    transition: all 0.3s ease;
    width: 100%;
    font-size: 0.9rem;
}

.login-input::placeholder { color: rgba(200, 149, 108, 0.4) !important; }

.login-input:focus {
    background: rgba(40, 8, 8, 0.9) !important;
    border-color: #FFD700 !important;
    box-shadow: 0 0 0 3px rgba(255, 215, 0, 0.12) !important;
    outline: none;
}

.login-input.shake { animation: shake 0.45s ease; }
@keyframes shake {
    0%,100%{transform:translateX(0)}
    15%,45%,75%{transform:translateX(-6px)}
    30%,60%,90%{transform:translateX(6px)}
}

.input-wrap { position: relative; }
.input-wrap .input-icon {
    position: absolute;
    right: 16px; top: 50%;
    transform: translateY(-50%);
    color: rgba(200,149,108,0.6);
    cursor: pointer;
    font-size: 0.95rem;
    transition: color 0.2s;
}
.input-wrap .input-icon:hover { color: #FFD700; }

/* Password box slide */
.password-box {
    max-height: 0;
    overflow: hidden;
    opacity: 0;
    transform: translateY(-10px);
    transition: max-height 0.4s cubic-bezier(0.19,1,0.22,1), opacity 0.3s ease, transform 0.3s ease;
}

.password-box.visible {
    max-height: 200px;
    opacity: 1;
    transform: translateY(0);
}

/* Login button */
.btn-login {
    background: linear-gradient(135deg, #8B0000, #A31515);
    color: #FFD700;
    border: 1px solid rgba(255,215,0,0.3);
    border-radius: 50px;
    padding: 13px;
    font-weight: 700;
    width: 100%;
    font-size: 0.95rem;
    letter-spacing: 0.5px;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 6px 20px rgba(139,0,0,0.4);
    opacity: 0;
    transform: translateY(10px);
    pointer-events: none;
}

.btn-login.show {
    opacity: 1;
    transform: translateY(0);
    pointer-events: auto;
    animation: btnAppear 0.35s ease;
}

@keyframes btnAppear {
    0%{transform:translateY(10px);opacity:0}
    100%{transform:translateY(0);opacity:1}
}

.btn-login:hover {
    background: linear-gradient(135deg, #A31515, #C8956C);
    box-shadow: 0 8px 28px rgba(139,0,0,0.6), 0 0 15px rgba(255,215,0,0.2);
    transform: translateY(-2px);
    color: #fff;
}

/* Remember me / links */
.form-check-input:checked { background-color: #8B0000 !important; border-color: #8B0000 !important; }
.form-check-label { color: #C8956C !important; font-size: 0.82rem; }

.forgot-link { color: rgba(200,149,108,0.8); text-decoration: none; font-size: 0.8rem; transition: color 0.2s; }
.forgot-link:hover { color: #FFD700; text-decoration: underline; }

.register-link { color: #FFD700; text-decoration: none; font-weight: 600; }
.register-link:hover { color: #C8956C; text-decoration: underline; }

.footer-note { color: rgba(200,149,108,0.5); font-size: 0.75rem; margin-top: 18px; text-align: center; }
</style>

<div class="login-wrap">
    <div class="login-card" id="loginCard">
        <!-- Logo -->
        <div class="login-logo">
            <div class="logo-icon"><i class="fas fa-shield-alt"></i></div>
            <h2>Welcome Back</h2>
            <p><?= BASE_NAME ?> Control Panel</p>
        </div>

        <?= form_open() ?>

        <!-- Username -->
        <div class="mb-3">
            <label for="username"><i class="fas fa-user me-1" style="color:#8B0000;"></i> Username</label>
            <div class="input-wrap">
                <input type="text" class="login-input" name="username" id="username"
                       placeholder="Enter your username" required minlength="4"
                       value="<?= esc($username_value) ?>" autocomplete="username">
                <i class="bi bi-person-fill input-icon"></i>
            </div>
            <?php if (!empty($errors['username'])) : ?>
                <small class="text-warning" style="font-size:0.75rem;"><?= esc($errors['username']) ?></small>
            <?php endif; ?>
        </div>

        <!-- Password (slides in) -->
        <div class="password-box" id="passwordBox">
            <div class="mb-3">
                <label for="password"><i class="fas fa-lock me-1" style="color:#8B0000;"></i> Password</label>
                <div class="input-wrap">
                    <input type="password" class="login-input" name="password" id="password"
                           placeholder="Enter your password" required minlength="6" autocomplete="current-password">
                    <i class="bi bi-eye-fill input-icon" id="togglePwd"></i>
                </div>
                <?php if (!empty($errors['password'])) : ?>
                    <small class="text-warning" style="font-size:0.75rem;"><?= esc($errors['password']) ?></small>
                <?php endif; ?>
            </div>

            <input type="hidden" name="ip" value="<?= esc($user_agent) ?>">

            <div class="d-flex justify-content-between align-items-center mb-3">
                <div class="form-check mb-0">
                    <input type="checkbox" class="form-check-input" name="stay_log" id="stay_log" value="yes" <?= $stay_log_checked ?>>
                    <label class="form-check-label" for="stay_log">Remember me</label>
                </div>
                <a href="<?= site_url('reset') ?>" class="forgot-link">Forgot password?</a>
            </div>
        </div>

        <!-- Login Button -->
        <div class="mb-3">
            <button type="submit" class="btn-login" id="loginBtn">
                <i class="fas fa-sign-in-alt me-2"></i>Login
            </button>
        </div>

        <div class="text-center" style="color:rgba(200,149,108,0.7);font-size:0.85rem;">
            Don't have an account?
            <a href="<?= site_url('register') ?>" class="register-link">Register</a>
        </div>

        <div class="footer-note">&copy; <?= date('Y') ?> <?= BASE_NAME ?> &mdash; All rights reserved</div>

        <?= form_close() ?>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const usernameInput = document.getElementById('username');
    const passwordBox   = document.getElementById('passwordBox');
    const loginBtn      = document.getElementById('loginBtn');
    const pwdInput      = document.getElementById('password');
    const togglePwd     = document.getElementById('togglePwd');

    usernameInput.addEventListener('input', function() {
        if (this.value.length >= 3) {
            passwordBox.classList.add('visible');
        } else {
            passwordBox.classList.remove('visible');
            loginBtn.classList.remove('show');
        }
    });

    pwdInput.addEventListener('input', function() {
        if (this.value.length >= 1) {
            loginBtn.classList.add('show');
        } else {
            loginBtn.classList.remove('show');
        }
    });

    togglePwd.addEventListener('click', function() {
        const isPwd = pwdInput.getAttribute('type') === 'password';
        pwdInput.setAttribute('type', isPwd ? 'text' : 'password');
        this.classList.toggle('bi-eye-fill');
        this.classList.toggle('bi-eye-slash-fill');
    });

    /* If there are validation errors, show the password box right away */
    <?php if (!empty($errors)) : ?>
    passwordBox.classList.add('visible');
    loginBtn.classList.add('show');
    <?php endif; ?>
});
</script>

<?= $this->endSection() ?>
