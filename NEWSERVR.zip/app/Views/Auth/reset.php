<?= $this->extend('Layout/Starter') ?>

<?= $this->section('content') ?>

<div class="row justify-content-center pt-0">
    <div class="col-12">
        <?= $this->include('Layout/msgStatus') ?>
        
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.20.0/font/bootstrap-icons.css">
        </head>
        <body>
        </body>
        </html>
        
        <div class="card shadow-sm mb-3" style="background: none; border: none;">
            <div class="card-body" style="background: linear-gradient(45deg, #424242, #424242); padding: 10px; text-align: center; border-radius: 5px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);">
                <span style="color: #BDBDBD; font-weight: bold; font-size: 1.2rem;">𝐑𝐞𝐬𝐞𝐭 𝐇𝐞𝐫𝐞</span>
            </div>
        </div>

        <?= form_open() ?>

        <div class="form-group mb-3">
            <label for="username" style="color: #EEEEEE; font-weight: bold;">𝐔𝐬𝐞𝐫𝐧𝐚𝐦𝐞</label>
            <input type="text" class="form-control mt-2" name="username" id="username" aria-describedby="help-username" 
                   placeholder="𝗘𝗻𝘁𝗲𝗿 𝘆𝗼𝘂𝗿 𝘂𝘀𝗲𝗿𝗻𝗮𝗺𝗲 𝗵𝗲𝗿𝗲" minlength="4" maxlength="111" value="<?= old('username') ?>" 
                   required oninput="handleUsernameInput()" 
                   style="background: linear-gradient(45deg, #424242, #424242); color: #BDBDBD; border: none; border-radius: 5px;">
            <link rel="stylesheet" href="<?= site_url('assets/css/reset-user-placeholder.css') ?>">
            <?php if ($validation->hasError('username')) : ?>
                <small id="help-username" class="form-text text-danger"><?= $validation->getError('username') ?></small>
            <?php endif; ?>
        </div>

        <div id="passwordSection" style="display: none; opacity: 0; transition: opacity 0.5s;">
            <div class="form-group mb-3">
                <label for="password" style="color: #EEEEEE; font-weight: bold;">𝐏𝐚𝐬𝐬𝐰𝐨𝐫𝐝</label>
                <div class="input-group">
                    <input type="password" class="form-control" name="password" id="password" aria-describedby="help-password" 
                           placeholder="𝗘𝗻𝘁𝗲𝗿 𝘆𝗼𝘂𝗿 𝗽𝗮𝘀𝘀𝘄𝗼𝗿𝗱 𝗵𝗲𝗿𝗲" minlength="5" maxlength="111" required oninput="applyBoldPassword()"
                           style="background: linear-gradient(45deg, #424242, #424242); color: #BDBDBD; border: none; border-radius: 5px;">
                    <link rel="stylesheet" href="<?= site_url('assets/css/reset-pass-placeholder.css') ?>">
                    <div class="input-group-append">
                        <button class="btn btn-outline-secondary" type="button" id="showPasswordButton" 
                                onclick="togglePasswordVisibility()" 
                                style="background: linear-gradient(45deg, #424242, #424242); color: #BDBDBD; border: none; font-weight: bold;">
                            <i id="showPasswordIcon" class="bi bi-eye"></i>
                        </button>
                    </div>
                </div>

                <?php if ($validation->hasError('password')) : ?>
                    <small id="help-password" class="form-text text-danger"><?= $validation->getError('password') ?></small>
                <?php endif; ?>
            </div>
        </div>

        <!-- Include Bootstrap Icons CDN -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

        <script src="<?= site_url('assets/js/reset-pass.js') ?>"></script>

        <!-- Include Font Awesome -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

        <div class="form-group mb-3">
            <button type="submit" class="btn btn-sm w-100" 
                    style="background: linear-gradient(45deg, #424242, #424242); 
                           color: #BDBDBD; 
                           font-weight: bold; 
                           border: none; 
                           text-transform: uppercase; 
                           box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2); 
                           transition: background-color 0.3s ease, box-shadow 0.3s ease;"
                    onmouseover="this.style.background = 'linear-gradient(45deg, #424242, #424242)'; this.style.boxShadow = '0 6px 8px rgba(0, 0, 0, 0.3)';"
                    onmouseout="this.style.background = 'linear-gradient(45deg, #424242, #424242)'; this.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.2)';">
                <i class=""></i> 𝐂𝐋𝐈𝐂𝐊 𝐇𝐄𝐑𝐄
            </button>
        </div>

        <?= form_close() ?>
        
        <link rel="stylesheet" href="<?= site_url('assets/css/btn-reset.css') ?>">
        <p class="text-center text-dark after-card" style="font-family: monospace;">
            <a href="<?= site_url('login') ?>" class="btn-reset" 
               style="color: #BDBDBD; 
                      background: linear-gradient(45deg, #424242, #424242); 
                      text-align: center; 
                      display: inline-block; 
                      border-radius: 5px; 
                      font-weight: bold; 
                      text-transform: uppercase; 
                      text-decoration: none; 
                      outline: none; 
                      border: none;">
               <strong> Login Here </strong>
            </a>
        </p>
    </div>
</div>

<pre>

<?= $this->endSection() ?>