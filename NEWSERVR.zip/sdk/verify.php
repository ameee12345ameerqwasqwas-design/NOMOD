<?php
require_once "config.php";

header("Content-Type: application/json");

$key = $_POST['license_key'] ?? '';
$package = $_POST['package'] ?? '';
$signature = $_POST['signature'] ?? '';
$appName = $_POST['app_name'] ?? '';
$appIcon = $_POST['app_icon'] ?? '';
$version = $_POST['version'] ?? '';
$deviceId = $_POST['device_id'] ?? '';
$sha1 = $_POST['sha1'] ?? '';
$sha256 = $_POST['sha256'] ?? '';
$md5 = $_POST['md5'] ?? '';
$versionCode = isset($_POST['version_code']) ? intval($_POST['version_code']) : 0;

if (empty($key) || empty($package) || empty($signature)) {
    echo json_encode(["status" => "fail", "message" => "missing_parameters"]);
    exit;
}

$key = mysqli_real_escape_string($conn, $key);
$package = mysqli_real_escape_string($conn, $package);
$signature = mysqli_real_escape_string($conn, $signature);
$appName = mysqli_real_escape_string($conn, $appName);
$appIcon = mysqli_real_escape_string($conn, $appIcon);
$version = mysqli_real_escape_string($conn, $version);
$deviceId = mysqli_real_escape_string($conn, $deviceId);
$sha1 = mysqli_real_escape_string($conn, $sha1);
$sha256 = mysqli_real_escape_string($conn, $sha256);
$md5 = mysqli_real_escape_string($conn, $md5);

$query = "SELECT * FROM licenses WHERE license_key = '$key' LIMIT 1";
$result = $conn->query($query);

if ($result->num_rows === 0) {
    echo json_encode(["status" => "fail", "message" => "invalid_key"]);
    exit;
}

$license = $result->fetch_assoc();
$license_id = $license['id'];
$is_plus = ($license['is_plus'] == 1);

if ($license['status'] === "blocked") {
    echo json_encode(["status" => "fail", "message" => "license_blocked"]);
    exit;
}

if (!empty($license['package_name']) && $license['package_name'] !== $package) {
    echo json_encode(["status" => "fail", "message" => "package_mismatch"]);
    exit;
}

if (!empty($license['signature']) && $license['signature'] !== $signature) {
    echo json_encode(["status" => "fail", "message" => "signature_invalid"]);
    exit;
}

// تصحيح مشكلة التواريخ - تحويل expiry من milliseconds إلى seconds للمقارنة مع time()
$expiry_seconds = intval($license['expiry'] / 1000);
$now_seconds = time();

if ($now_seconds > $expiry_seconds) {
    echo json_encode(["status" => "expired", "message" => "License expired"]);
    exit;
}

$daysLeft = floor(($expiry_seconds - $now_seconds) / 86400);

$checkQuery = "SELECT id FROM license_apps WHERE license_id = $license_id AND package_name = '$package' AND signature = '$signature'";
$checkResult = $conn->query($checkQuery);

if ($checkResult->num_rows === 0) {
    $countQuery = "SELECT COUNT(*) as app_count FROM license_apps WHERE license_id = $license_id";
    $countResult = $conn->query($countQuery);
    $appCount = $countResult->fetch_assoc()['app_count'];
    
    if ($license['max_devices'] > 0 && $appCount >= $license['max_devices']) {
        echo json_encode(["status" => "fail", "message" => "max_apps_reached"]);
        exit;
    }
    
    $insertQuery = "
        INSERT INTO license_apps 
        (license_id, package_name, signature, app_name, version, version_code, device_identifier, sha1, sha256, md5) 
        VALUES ($license_id, '$package', '$signature', '$appName', '$version', $versionCode, '$deviceId', '$sha1', '$sha256', '$md5')
    ";
    if (!$conn->query($insertQuery)) {
        error_log("Failed to insert license_app: " . $conn->error);
    }
} else {
    $updateQuery = "
        UPDATE license_apps 
        SET last_seen_at = NOW(), 
            version = '$version', 
            version_code = $versionCode, 
            device_identifier = '$deviceId',
            app_name = '$appName'
        WHERE license_id = $license_id AND package_name = '$package' AND signature = '$signature'
    ";
    $conn->query($updateQuery);
}

$logQuery = "
    INSERT INTO verification_logs 
    (license_key, package_name, signature, device_identifier, result) 
    VALUES ('$key', '$package', '$signature', '$deviceId', 'success')
";
$conn->query($logQuery);

$response = [
    "status" => "ok",
    "expiry" => $license['expiry'],
    "days_left" => $daysLeft,
    "message" => $daysLeft > 0 ? "Remaining in BBox ($daysLeft days)" : "Remaining in BBox (Last day)"
];

if ($is_plus) {
    $response["is_plus"] = "1";
    $response["type"] = "plus";
} else {
    $response["is_plus"] = "0";
    $response["type"] = "normal";
}

echo json_encode($response);
$conn->close();
?>