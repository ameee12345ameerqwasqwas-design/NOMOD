<?php
require_once "includes/check_login.php";
require_once "config.php";

$message = '';
$messageType = '';

function generateKey($duration) {
    if ($duration == 24) $durationCode = "1D";
    elseif ($duration == 48) $durationCode = "2D";
    elseif ($duration == 168) $durationCode = "7D";
    elseif ($duration == 720) $durationCode = "30D";
    elseif ($duration == 1440) $durationCode = "60D";
    elseif ($duration == 8760) $durationCode = "365D";
    else $durationCode = $duration . "H";
    
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $random = '';
    for ($i = 0; $i < 5; $i++) {
        $random .= $characters[rand(0, strlen($characters) - 1)];
    }
    
    return $durationCode . "x" . $random;
}

if (isset($_POST['action']) && $_POST['action'] === 'create') {
    $package = $_POST['package'] ?? '';
    $signature = $_POST['signature'] ?? '';
    $duration = intval($_POST['duration'] ?? 0);
    $max_devices = intval($_POST['max_devices'] ?? 1);
    $constant_key = $_POST['constant_key'] ?? '';
    $is_plus = isset($_POST['is_plus']) ? 1 : 0;

    if ($duration > 0) {
        $expiry = round(microtime(true) * 1000) + ($duration * 3600000);

        if (!empty($constant_key)) {
            $key = $constant_key;
            $check = $conn->query("SELECT id FROM licenses WHERE license_key = '$key'");
            if ($check->num_rows > 0) {
                $message = "هذا المفتاح موجود بالفعل!";
                $messageType = "error";
            } else {
                $key = $constant_key;
            }
        } else {
            $key = generateKey($duration);
        }

        if (empty($message)) {
            $stmt = $conn->prepare("INSERT INTO licenses (license_key, package_name, signature, expiry, max_devices, is_plus, status) VALUES (?, ?, ?, ?, ?, ?, 'active')");
            $stmt->bind_param("sssiii", $key, $package, $signature, $expiry, $max_devices, $is_plus);

            if ($stmt->execute()) {
                $message = "تم إنشاء الترخيص بنجاح!";
                $messageType = "success";
                $_SESSION['last_created_keys'] = [$key];
            } else {
                $message = "فشل إنشاء الترخيص: " . $stmt->error;
                $messageType = "error";
            }
            $stmt->close();
        }
    } else {
         $message = "يرجى تحديد مدة صحيحة";
         $messageType = "error";
    }
}

if (isset($_POST['action']) && $_POST['action'] === 'edit') {
    $id = intval($_POST['id'] ?? 0);
    $package = $_POST['package'] ?? '';
    $signature = $_POST['signature'] ?? '';
    $expiry = intval($_POST['expiry'] ?? 0);
    $status = $_POST['status'] ?? '';
    $max_devices = intval($_POST['max_devices'] ?? 1);
    $is_plus = isset($_POST['is_plus']) ? 1 : 0;

    if ($id > 0 && $expiry > 0 && in_array($status, ['active', 'blocked'])) {
        $stmt = $conn->prepare("UPDATE licenses SET package_name = ?, signature = ?, expiry = ?, status = ?, max_devices = ?, is_plus = ? WHERE id = ?");
        $stmt->bind_param("ssisiii", $package, $signature, $expiry, $status, $max_devices, $is_plus, $id);

        if ($stmt->execute()) {
            $message = "تم تعديل الترخيص بنجاح!";
            $messageType = "success";
        } else {
            $message = "فشل تعديل الترخيص: " . $stmt->error;
            $messageType = "error";
        }
        $stmt->close();
    }
}

if (isset($_POST['action']) && $_POST['action'] === 'add_time') {
    $id = intval($_POST['id'] ?? 0);
    $hours = intval($_POST['hours'] ?? 0);
    
    if ($id > 0 && $hours > 0) {
        $stmt = $conn->prepare("SELECT expiry FROM licenses WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->bind_result($expiry);
        $stmt->fetch();
        $stmt->close();
        
        if ($expiry) {
            $new_expiry = $expiry + ($hours * 3600000);
            $update = $conn->prepare("UPDATE licenses SET expiry = ? WHERE id = ?");
            $update->bind_param("ii", $new_expiry, $id);
            if ($update->execute()) {
                $message = "تم إضافة " . $hours . " ساعة إلى المدة بنجاح!";
                $messageType = "success";
            }
            $update->close();
        }
    }
}

if (isset($_POST['action']) && $_POST['action'] === 'restart') {
    $id = intval($_POST['id'] ?? 0);
    
    if ($id > 0) {
        $stmt = $conn->prepare("DELETE FROM license_apps WHERE license_id = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            $message = "تم حذف جميع التطبيقات المرتبطة بنجاح!";
            $messageType = "success";
        }
        $stmt->close();
    }
}

if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $action = $_GET['action'];
    
    if ($id > 0) {
        if ($action === 'block') {
            $stmt = $conn->prepare("UPDATE licenses SET status = 'blocked' WHERE id = ?");
        } elseif ($action === 'unblock') {
            $stmt = $conn->prepare("UPDATE licenses SET status = 'active' WHERE id = ?");
        } elseif ($action === 'delete') {
            $stmt = $conn->prepare("DELETE FROM licenses WHERE id = ?");
        } elseif ($action === 'restart') {
            $stmt = $conn->prepare("DELETE FROM license_apps WHERE license_id = ?");
        }
        
        if (isset($stmt)) {
            $stmt->bind_param("i", $id);
            if ($stmt->execute()) {
                $message = "تمت العملية بنجاح!";
                $messageType = "success";
            }
            $stmt->close();
        }
    }
}

$licenses = [];
$result = $conn->query("SELECT * FROM licenses ORDER BY id DESC");
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $licenses[] = $row;
    }
}
$last_keys = isset($_SESSION['last_created_keys']) ? $_SESSION['last_created_keys'] : [];
unset($_SESSION['last_created_keys']);
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>لوحة التحكم - نظام الترخيص</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800&display=swap');
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Tajawal', sans-serif;
            background: #0a0a0a;
            color: #e0e0e0;
            min-height: 100vh;
        }
        .glass-effect {
            background: rgba(18, 18, 18, 0.95);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.05);
        }
        .glass-card {
            background: rgba(20, 20, 20, 0.95);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.03);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
        }
        .gradient-header {
            background: linear-gradient(135deg, #000000 0%, #1a1a1a 100%);
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }
        .card-mobile {
            background: rgba(18, 18, 18, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 24px;
            margin-bottom: 20px;
            overflow: hidden;
            border: 1px solid rgba(255, 255, 255, 0.03);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.5);
        }
        .stats-card {
            background: rgba(18, 18, 18, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            padding: 16px;
            border: 1px solid rgba(255, 255, 255, 0.03);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
        }
        .license-card-mobile {
            background: rgba(18, 18, 18, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 24px;
            margin-bottom: 20px;
            overflow: hidden;
            border: 1px solid rgba(255, 255, 255, 0.03);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.5);
        }
        .status-badge {
            padding: 6px 16px;
            border-radius: 100px;
            font-size: 12px;
            font-weight: 800;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            letter-spacing: 0.5px;
        }
        .plus-badge {
            background: rgba(245, 158, 11, 0.2);
            color: #fbbf24;
            border: 1px solid rgba(245, 158, 11, 0.3);
        }
        input, select, textarea {
            background: rgba(30, 30, 30, 0.8) !important;
            border: 1px solid rgba(255, 255, 255, 0.05) !important;
            color: #ffffff !important;
            border-radius: 16px !important;
            padding: 14px 16px !important;
            font-size: 14px !important;
            transition: all 0.2s ease;
        }
        input:focus, select:focus {
            border-color: #6366f1 !important;
            outline: none;
            background: rgba(40, 40, 40, 0.9) !important;
            box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
        }
        input::placeholder {
            color: #6b7280 !important;
        }
        .bg-gray-50, .bg-gray-100 {
            background: rgba(30, 30, 30, 0.8) !important;
        }
        .text-gray-500, .text-gray-600, .text-gray-800 {
            color: #d1d5db !important;
        }
        .border-gray-200 {
            border-color: rgba(255, 255, 255, 0.05) !important;
        }
        button {
            transition: all 0.2s ease;
        }
        button:hover {
            transform: translateY(-1px);
            filter: brightness(1.1);
        }
        .bg-white {
            background: rgba(30, 30, 30, 0.9) !important;
        }
        .text-indigo-600 {
            color: #818cf8 !important;
        }
        .bg-indigo-600 {
            background: #4f46e5 !important;
        }
        .bg-indigo-600:hover {
            background: #6366f1 !important;
        }
        .modal-content {
            background: rgba(18, 18, 18, 0.98);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.05);
        }
        .checkbox-container {
            display: flex;
            align-items: center;
            gap: 10px;
            background: rgba(30, 30, 30, 0.8);
            padding: 12px 16px;
            border-radius: 16px;
            border: 1px solid rgba(255, 255, 255, 0.05);
        }
        .checkbox-container input {
            width: 20px;
            height: 20px;
            margin: 0;
            cursor: pointer;
        }
        .checkbox-container label {
            cursor: pointer;
            font-weight: bold;
            color: #fbbf24;
        }
    </style>
</head>
<body class="pb-10">

    <div class="gradient-header text-white px-4 py-6">
        <div class="flex items-center justify-between">
            <div>
                <h1 class="text-2xl font-black tracking-wide">نظام التراخيص</h1>
                <p class="text-gray-400 text-sm mt-1">مرحباً، <?php echo $_SESSION['admin']; ?></p>
            </div>
            <a href="logout.php" class="bg-white bg-opacity-5 px-4 py-2 rounded-xl text-sm font-bold backdrop-blur-lg border border-white border-opacity-10">
                <i class="fas fa-sign-out-alt ml-1"></i>
                خروج
            </a>
        </div>
    </div>

    <div class="px-4 py-4">

        <?php if ($message): ?>
        <div class="mb-4 p-4 rounded-2xl <?php echo $messageType === 'success' ? 'bg-green-900 bg-opacity-20 border-r-4 border-green-500 text-green-200' : 'bg-red-900 bg-opacity-20 border-r-4 border-red-500 text-red-200'; ?> text-sm backdrop-blur-lg">
            <i class="fas <?php echo $messageType === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> ml-1"></i>
            <?php echo $message; ?>
        </div>
        <?php endif; ?>

        <?php if (!empty($last_keys)): ?>
        <div class="mb-4 bg-green-900 bg-opacity-20 p-4 rounded-2xl border-r-4 border-green-500 backdrop-blur-lg">
            <p class="text-sm font-bold text-green-200 mb-2"><i class="fas fa-check-circle ml-1"></i> تم إنشاء المفتاح:</p>
            <?php foreach ($last_keys as $k): ?>
            <div class="bg-black bg-opacity-30 p-3 rounded-xl border border-green-800 flex justify-between items-center">
                <span class="font-mono text-xs font-bold text-green-200"><?php echo $k; ?></span>
                <button onclick="copyToClipboard('<?php echo $k; ?>')" class="text-green-400 bg-black bg-opacity-30 p-2 rounded-lg text-xs hover:bg-opacity-50">
                    <i class="fas fa-copy"></i>
                </button>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <div class="card-mobile">
            <div class="bg-gradient-to-r from-gray-900 to-black px-4 py-4 border-b border-white border-opacity-5">
                <h2 class="text-white font-bold flex items-center gap-2">
                    <i class="fas fa-plus-circle text-indigo-400"></i>
                    إنشاء ترخيص جديد
                </h2>
            </div>
            <form method="POST" class="p-4 space-y-4">
                <input type="hidden" name="action" value="create">
                
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs font-bold text-gray-400 mb-2">مدة الترخيص</label>
                        <select name="duration" required class="w-full">
                            <option value="">اختر المدة</option>
                            <option value="1">1 ساعة</option>
                            <option value="2">2 ساعة</option>
                            <option value="6">6 ساعات</option>
                            <option value="12">12 ساعة</option>
                            <option value="24">1 يوم</option>
                            <option value="48">2 يوم</option>
                            <option value="168">7 أيام</option>
                            <option value="720">30 يوم</option>
                            <option value="1440">60 يوم</option>
                            <option value="8760">365 يوم</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-gray-400 mb-2">عدد التطبيقات</label>
                        <select name="max_devices" class="w-full">
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="5">5</option>
                            <option value="10">10</option>
                            <option value="20">20</option>
                            <option value="30">30</option>
                            <option value="50">50</option>
                            <option value="0">غير محدود</option>
                        </select>
                    </div>
                </div>

                <div class="checkbox-container">
                    <input type="checkbox" name="is_plus" id="is_plus" value="1">
                    <label for="is_plus">
                        <i class="fas fa-crown text-yellow-500 ml-1"></i>
                        ترخيص PLUS (مميز)
                    </label>
                </div>

                <div>
                    <label class="block text-xs font-bold text-gray-400 mb-2">مفتاح مخصص (اختياري)</label>
                    <input type="text" name="constant_key" placeholder="اكتب المفتاح هنا..." class="w-full">
                </div>

                <div>
                    <button type="button" onclick="toggleAdvancedOptions()" class="text-indigo-400 text-sm font-bold flex items-center gap-1 hover:text-indigo-300">
                        <i class="fas fa-cog"></i>
                        خيارات متقدمة
                    </button>
                </div>

                <div id="advancedOptions" class="hidden bg-black bg-opacity-30 p-4 rounded-2xl">
                    <div class="space-y-3">
                        <div>
                            <label class="block text-xs font-bold text-gray-400 mb-2">Package Name</label>
                            <input type="text" name="package" placeholder="com.example.app" class="w-full">
                        </div>
                        <div>
                            <label class="block text-xs font-bold text-gray-400 mb-2">Signature</label>
                            <input type="text" name="signature" placeholder="التوقيع" class="w-full">
                        </div>
                        <p class="text-xs text-gray-500">إذا تركتها فارغة يعمل على أي Package</p>
                    </div>
                </div>

                <button type="submit" class="w-full bg-indigo-600 text-white py-4 rounded-xl font-bold text-sm hover:bg-indigo-700 transition-all">
                    <i class="fas fa-magic ml-1"></i>
                    إنشاء الترخيص
                </button>
            </form>
        </div>

        <?php
        $active_count = 0;
        $blocked_count = 0;
        $expired_count = 0;
        $plus_count = 0;
        $stats_now = round(microtime(true) * 1000);
        
        foreach ($licenses as $license) {
            if ($license['is_plus'] == 1) {
                $plus_count++;
            }
            if ($license['expiry'] < $stats_now) {
                $expired_count++;
            } elseif ($license['status'] == 'active') {
                $active_count++;
            } elseif ($license['status'] == 'blocked') {
                $blocked_count++;
            }
        }
        ?>
        
        <div class="grid grid-cols-5 gap-3 my-6">
            <div class="stats-card text-center">
                <span class="text-green-400 text-xl font-black"><?php echo $active_count; ?></span>
                <p class="text-xs text-gray-500 mt-1">نشط</p>
            </div>
            <div class="stats-card text-center">
                <span class="text-red-400 text-xl font-black"><?php echo $blocked_count; ?></span>
                <p class="text-xs text-gray-500 mt-1">محظور</p>
            </div>
            <div class="stats-card text-center">
                <span class="text-yellow-400 text-xl font-black"><?php echo $expired_count; ?></span>
                <p class="text-xs text-gray-500 mt-1">منتهي</p>
            </div>
            <div class="stats-card text-center">
                <span class="text-blue-400 text-xl font-black"><?php echo count($licenses); ?></span>
                <p class="text-xs text-gray-500 mt-1">إجمالي</p>
            </div>
            <div class="stats-card text-center">
                <span class="text-amber-400 text-xl font-black"><?php echo $plus_count; ?></span>
                <p class="text-xs text-gray-500 mt-1">PLUS</p>
            </div>
        </div>

        <div class="mt-6">
            <h2 class="text-lg font-black text-white mb-4 flex items-center gap-2">
                <i class="fas fa-key text-indigo-400"></i>
                التراخيص الحالية
            </h2>

            <?php if (empty($licenses)): ?>
            <div class="glass-card rounded-2xl p-10 text-center">
                <i class="fas fa-box-open text-4xl text-gray-600 mb-3"></i>
                <p class="text-gray-400 text-sm">لا توجد تراخيص</p>
                <p class="text-xs text-gray-600 mt-2">قم بإنشاء أول ترخيص من الأعلى</p>
            </div>
            <?php endif; ?>

            <?php foreach ($licenses as $license): 
                $now = round(microtime(true) * 1000);
                $isExpired = $license['expiry'] < $now;
                $isPlus = $license['is_plus'] == 1;
                
                if ($license['status'] == 'active' && !$isExpired) {
                    $statusColor = 'green';
                    $statusText = 'نشط';
                    $statusIcon = 'check-circle';
                    $badgeClass = 'bg-green-900 bg-opacity-20 text-green-200 border border-green-800';
                } elseif ($license['status'] == 'blocked') {
                    $statusColor = 'red';
                    $statusText = 'محظور';
                    $statusIcon = 'ban';
                    $badgeClass = 'bg-red-900 bg-opacity-20 text-red-200 border border-red-800';
                } else {
                    $statusColor = 'yellow';
                    $statusText = 'منتهي';
                    $statusIcon = 'clock';
                    $badgeClass = 'bg-yellow-900 bg-opacity-20 text-yellow-200 border border-yellow-800';
                }
                
                $appCount = 0;
                $countResult = $conn->query("SELECT COUNT(*) as count FROM license_apps WHERE license_id = " . $license['id']);
                if ($countResult && $countResult->num_rows > 0) {
                    $appCount = $countResult->fetch_assoc()['count'];
                }
                $maxApps = $license['max_devices'] == 0 ? '∞' : $license['max_devices'];
                $isFull = ($appCount >= $license['max_devices'] && $license['max_devices'] != 0);
                
                $daysLeft = floor(($license['expiry'] - $now) / (1000 * 60 * 60 * 24));
                if ($daysLeft < 0) $daysLeft = 0;
            ?>

            <div class="license-card-mobile" data-id="<?php echo $license['id']; ?>" data-key="<?php echo $license['license_key']; ?>" data-package="<?php echo $license['package_name']; ?>" data-signature="<?php echo $license['signature']; ?>" data-expiry="<?php echo $license['expiry']; ?>" data-status="<?php echo $license['status']; ?>" data-max-devices="<?php echo $license['max_devices']; ?>" data-is-plus="<?php echo $license['is_plus']; ?>">
                
                <div class="bg-black bg-opacity-30 px-4 py-3 border-b border-white border-opacity-5 flex justify-between items-center">
                    <div class="flex items-center gap-2 flex-1">
                        <i class="fas fa-cube text-gray-600"></i>
                        <span class="font-bold text-sm truncate max-w-[150px] text-white">
                            <?php echo empty($license['package_name']) ? 'أي Package' : htmlspecialchars($license['package_name']); ?>
                        </span>
                        <?php if ($isPlus): ?>
                        <span class="plus-badge text-xs px-2 py-0.5 rounded-full flex items-center gap-1">
                            <i class="fas fa-crown text-xs"></i>
                            PLUS
                        </span>
                        <?php endif; ?>
                    </div>
                    <span class="status-badge <?php echo $badgeClass; ?>">
                        <i class="fas fa-<?php echo $statusIcon; ?> text-xs"></i>
                        <?php echo $statusText; ?>
                    </span>
                </div>

                <div class="p-4">
                    <div class="bg-black bg-opacity-30 rounded-2xl p-4 mb-3 border border-white border-opacity-5">
                        <div class="flex justify-between items-center mb-2">
                            <span class="text-xs font-bold text-gray-500">مفتاح الترخيص</span>
                            <button onclick="copyToClipboard('<?php echo $license['license_key']; ?>')" class="text-indigo-400 hover:text-indigo-300">
                                <i class="fas fa-copy text-sm"></i>
                            </button>
                        </div>
                        <div class="font-mono text-xs font-bold bg-black bg-opacity-50 p-3 rounded-xl border border-white border-opacity-5 break-all text-gray-300">
                            <?php echo $license['license_key']; ?>
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-2 mb-3">
                        <div class="bg-black bg-opacity-30 p-3 rounded-xl border border-white border-opacity-5">
                            <span class="text-xs text-gray-500 block mb-1">التوقيع</span>
                            <span class="font-mono text-xs font-bold truncate block <?php echo empty($license['signature']) ? 'text-orange-400' : 'text-gray-300'; ?>">
                                <?php echo empty($license['signature']) ? 'أي توقيع' : htmlspecialchars(substr($license['signature'], 0, 15)) . '...'; ?>
                            </span>
                        </div>
                        <div class="bg-black bg-opacity-30 p-3 rounded-xl border border-white border-opacity-5">
                            <span class="text-xs text-gray-500 block mb-1">التطبيقات</span>
                            <span class="font-bold text-sm <?php echo $isFull ? 'text-red-400' : 'text-green-400'; ?>">
                                <?php echo $appCount . '/' . $maxApps; ?>
                            </span>
                        </div>
                        <div class="bg-black bg-opacity-30 p-3 rounded-xl border border-white border-opacity-5">
                            <span class="text-xs text-gray-500 block mb-1">ينتهي في</span>
                            <span class="font-bold text-sm <?php echo $isExpired ? 'text-red-400' : 'text-green-400'; ?>">
                                <?php echo date('Y-m-d H:i', $license['expiry'] / 1000); ?>
                            </span>
                        </div>
                        <div class="bg-black bg-opacity-30 p-3 rounded-xl border border-white border-opacity-5">
                            <span class="text-xs text-gray-500 block mb-1">الأيام المتبقية</span>
                            <span class="font-bold text-sm <?php echo $daysLeft < 3 ? 'text-orange-400' : 'text-blue-400'; ?>">
                                <?php echo $daysLeft; ?> يوم
                            </span>
                        </div>
                    </div>

                    <div class="grid grid-cols-5 gap-1.5 mt-4">
                        <?php if ($license['status'] != 'blocked' && !$isExpired): ?>
                        <a href="?action=block&id=<?php echo $license['id']; ?>" onclick="return confirm('حظر الترخيص؟')" class="bg-red-900 bg-opacity-20 text-red-200 p-2 rounded-xl text-xs font-bold text-center hover:bg-opacity-30 border border-red-800">
                            <i class="fas fa-ban block text-sm mb-0.5"></i>
                            <span>حظر</span>
                        </a>
                        <?php elseif ($license['status'] == 'blocked'): ?>
                        <a href="?action=unblock&id=<?php echo $license['id']; ?>" onclick="return confirm('تفعيل الترخيص؟')" class="bg-green-900 bg-opacity-20 text-green-200 p-2 rounded-xl text-xs font-bold text-center hover:bg-opacity-30 border border-green-800">
                            <i class="fas fa-check-circle block text-sm mb-0.5"></i>
                            <span>تفعيل</span>
                        </a>
                        <?php endif; ?>

                        <?php if ($license['status'] == 'blocked' || ($license['status'] == 'active' && !$isExpired)): ?>
                        <button onclick="openEditModal(<?php echo $license['id']; ?>)" class="bg-blue-900 bg-opacity-20 text-blue-200 p-2 rounded-xl text-xs font-bold text-center hover:bg-opacity-30 border border-blue-800">
                            <i class="fas fa-edit block text-sm mb-0.5"></i>
                            <span>تعديل</span>
                        </button>
                        <?php endif; ?>
                        
                        <a href="?action=restart&id=<?php echo $license['id']; ?>" onclick="return confirm('حذف جميع التطبيقات المرتبطة؟')" class="bg-yellow-900 bg-opacity-20 text-yellow-200 p-2 rounded-xl text-xs font-bold text-center hover:bg-opacity-30 border border-yellow-800">
                            <i class="fas fa-sync-alt block text-sm mb-0.5"></i>
                            <span>ريستارت</span>
                        </a>
                        
                        <a href="?action=delete&id=<?php echo $license['id']; ?>" onclick="return confirm('حذف الترخيص؟')" class="bg-gray-900 bg-opacity-20 text-gray-200 p-2 rounded-xl text-xs font-bold text-center hover:bg-opacity-30 border border-gray-700">
                            <i class="fas fa-trash block text-sm mb-0.5"></i>
                            <span>حذف</span>
                        </a>

                        <a href="activations.php?license_id=<?php echo $license['id']; ?>" class="bg-indigo-900 bg-opacity-20 text-indigo-200 p-2 rounded-xl text-xs font-bold text-center hover:bg-opacity-30 border border-indigo-800">
                            <i class="fas fa-mobile-alt block text-sm mb-0.5"></i>
                            <span>تطبيقات</span>
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div id="editModal" class="hidden fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-50 p-4 backdrop-blur-sm" onclick="closeEditModalOnClick(event)">
        <div class="glass-card rounded-2xl w-full max-w-md" onclick="event.stopPropagation()">
            <div class="bg-gradient-to-l from-gray-900 to-black text-white p-4 rounded-t-2xl border-b border-white border-opacity-5">
                <h3 class="font-black flex items-center gap-2">
                    <i class="fas fa-edit"></i>
                    تعديل الترخيص
                </h3>
            </div>
            <form method="POST" class="p-4">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id" id="edit_id">
                <input type="hidden" name="expiry" id="edit_expiry">
                
                <div class="space-y-4">
                    <div>
                        <label class="block text-xs font-bold text-gray-400 mb-2">Package Name</label>
                        <input type="text" name="package" id="edit_package" class="w-full">
                    </div>
                    
                    <div>
                        <label class="block text-xs font-bold text-gray-400 mb-2">Signature</label>
                        <input type="text" name="signature" id="edit_signature" class="w-full">
                    </div>

                    <div class="checkbox-container">
                        <input type="checkbox" name="is_plus" id="edit_is_plus" value="1">
                        <label for="edit_is_plus">
                            <i class="fas fa-crown text-yellow-500 ml-1"></i>
                            ترخيص PLUS (مميز)
                        </label>
                    </div>
                    
                    <div>
                        <label class="block text-xs font-bold text-gray-400 mb-2">تاريخ الانتهاء</label>
                        <input type="text" id="edit_expiry_display" readonly class="w-full bg-black bg-opacity-50 mb-3">
                        <div class="grid grid-cols-4 gap-2">
                            <button type="button" onclick="addTimeToEdit(1)" class="bg-blue-900 bg-opacity-20 text-blue-200 p-3 rounded-xl text-xs font-bold hover:bg-opacity-30 border border-blue-800">+1 س</button>
                            <button type="button" onclick="addTimeToEdit(24)" class="bg-green-900 bg-opacity-20 text-green-200 p-3 rounded-xl text-xs font-bold hover:bg-opacity-30 border border-green-800">+1 ي</button>
                            <button type="button" onclick="addTimeToEdit(168)" class="bg-yellow-900 bg-opacity-20 text-yellow-200 p-3 rounded-xl text-xs font-bold hover:bg-opacity-30 border border-yellow-800">+1 أ</button>
                            <button type="button" onclick="addTimeToEdit(720)" class="bg-purple-900 bg-opacity-20 text-purple-200 p-3 rounded-xl text-xs font-bold hover:bg-opacity-30 border border-purple-800">+1 ش</button>
                        </div>
                    </div>
                    
                    <div>
                        <label class="block text-xs font-bold text-gray-400 mb-2">الحالة</label>
                        <select name="status" id="edit_status" class="w-full">
                            <option value="active">نشط</option>
                            <option value="blocked">محظور</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-gray-400 mb-2">عدد التطبيقات</label>
                        <input type="number" name="max_devices" id="edit_max_devices" min="0" class="w-full">
                    </div>
                    
                    <div class="flex gap-2 pt-3">
                        <button type="submit" class="flex-1 bg-indigo-600 text-white py-3 rounded-xl font-bold text-sm hover:bg-indigo-700">حفظ</button>
                        <button type="button" onclick="closeEditModal()" class="flex-1 bg-gray-800 text-white py-3 rounded-xl font-bold text-sm hover:bg-gray-700 border border-gray-700">إلغاء</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <script>
        function toggleAdvancedOptions() {
            const options = document.getElementById('advancedOptions');
            options.classList.toggle('hidden');
        }

        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(() => {
                alert('✅ تم النسخ');
            });
        }

        function addTimeToEdit(hours) {
            const expiryInput = document.getElementById('edit_expiry');
            const currentExpiry = parseInt(expiryInput.value);
            const newExpiry = currentExpiry + (hours * 3600000);
            expiryInput.value = newExpiry;
            const newDate = new Date(newExpiry);
            document.getElementById('edit_expiry_display').value = newDate.toLocaleString('ar-EG');
        }

        function openEditModal(id) {
            const card = document.querySelector(`.license-card-mobile[data-id="${id}"]`);
            
            document.getElementById('edit_id').value = id;
            document.getElementById('edit_package').value = card.dataset.package;
            document.getElementById('edit_signature').value = card.dataset.signature;
            document.getElementById('edit_status').value = card.dataset.status;
            document.getElementById('edit_max_devices').value = card.dataset.maxDevices;
            
            const isPlus = card.dataset.isPlus === '1';
            document.getElementById('edit_is_plus').checked = isPlus;
            
            const expiry = parseInt(card.dataset.expiry);
            document.getElementById('edit_expiry').value = expiry;
            document.getElementById('edit_expiry_display').value = new Date(expiry).toLocaleString('ar-EG');
            
            document.getElementById('editModal').classList.remove('hidden');
        }

        function closeEditModal() {
            document.getElementById('editModal').classList.add('hidden');
        }

        function closeEditModalOnClick(event) {
            if (event.target === document.getElementById('editModal')) {
                closeEditModal();
            }
        }
    </script>

</body>
</html>