<?php
require_once "includes/check_login.php";
require_once "config.php";

$license_id = isset($_GET['license_id']) ? intval($_GET['license_id']) : 0;

if ($license_id === 0) {
    header("Location: panel.php");
    exit;
}

$license = null;
$stmt = $conn->prepare("SELECT id, license_key, package_name, signature, expiry, max_devices, is_plus, status, created_at FROM licenses WHERE id = ?");
$stmt->bind_param("i", $license_id);
$stmt->execute();
$stmt->bind_result($id, $license_key, $package_name, $signature, $expiry, $max_devices, $is_plus, $status, $created_at);
if ($stmt->fetch()) {
    $license = [
        'id' => $id,
        'license_key' => $license_key,
        'package_name' => $package_name,
        'signature' => $signature,
        'expiry' => $expiry,
        'max_devices' => $max_devices,
        'is_plus' => $is_plus,
        'status' => $status,
        'created_at' => $created_at
    ];
}
$stmt->close();

if (!$license) {
    header("Location: panel.php");
    exit;
}

$apps = [];
$stmt = $conn->prepare("
    SELECT package_name, signature, app_name, version, version_code, device_identifier, sha1, sha256, md5, first_activated_at, last_seen_at 
    FROM license_apps 
    WHERE license_id = ? 
    ORDER BY last_seen_at DESC
");
$stmt->bind_param("i", $license_id);
$stmt->execute();
$stmt->bind_result($package_name, $signature, $app_name, $version, $version_code, $device_identifier, $sha1, $sha256, $md5, $first_activated_at, $last_seen_at);
while ($stmt->fetch()) {
    $apps[] = [
        'package_name' => $package_name,
        'signature' => $signature,
        'app_name' => $app_name,
        'version' => $version,
        'version_code' => $version_code,
        'device_identifier' => $device_identifier,
        'sha1' => $sha1,
        'sha256' => $sha256,
        'md5' => $md5,
        'first_activated_at' => $first_activated_at,
        'last_seen_at' => $last_seen_at
    ];
}
$stmt->close();

$now = round(microtime(true) * 1000);
$daysLeft = floor(($license['expiry'] - $now) / (1000 * 60 * 60 * 24));
if ($daysLeft < 0) $daysLeft = 0;
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>التطبيقات المرتبطة - <?php echo htmlspecialchars($license['license_key']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800&display=swap');
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Tajawal', sans-serif;
            background: #0a0a0a;
            color: #e0e0e0;
            min-height: 100vh;
        }
        .glass-header {
            background: linear-gradient(135deg, #000000 0%, #1a1a1a 100%);
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }
        .glass-card {
            background: rgba(18, 18, 18, 0.95);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.03);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4);
        }
        .license-info-card {
            background: rgba(18, 18, 18, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 24px;
            border: 1px solid rgba(255, 255, 255, 0.03);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.5);
        }
        .apps-card {
            background: rgba(18, 18, 18, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 24px;
            border: 1px solid rgba(255, 255, 255, 0.03);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.5);
        }
        .mobile-card {
            background: rgba(18, 18, 18, 0.95);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            margin-bottom: 16px;
            overflow: hidden;
            border: 1px solid rgba(255, 255, 255, 0.03);
        }
        .mobile-header {
            background: rgba(0, 0, 0, 0.3);
            padding: 12px 16px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }
        .mobile-content {
            padding: 16px;
        }
        .table-container {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th {
            background: rgba(0, 0, 0, 0.3);
            color: #9ca3af;
            font-weight: 700;
            font-size: 12px;
            padding: 12px 16px;
            text-align: right;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }
        td {
            padding: 16px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.03);
            color: #e0e0e0;
        }
        tr:hover {
            background: rgba(255, 255, 255, 0.02);
        }
        .badge {
            padding: 4px 12px;
            border-radius: 100px;
            font-size: 11px;
            font-weight: 700;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        .badge-blue {
            background: rgba(59, 130, 246, 0.1);
            color: #93c5fd;
            border: 1px solid rgba(59, 130, 246, 0.2);
        }
        .badge-green {
            background: rgba(16, 185, 129, 0.1);
            color: #6ee7b7;
            border: 1px solid rgba(16, 185, 129, 0.2);
        }
        .badge-red {
            background: rgba(239, 68, 68, 0.1);
            color: #fca5a5;
            border: 1px solid rgba(239, 68, 68, 0.2);
        }
        .badge-orange {
            background: rgba(249, 115, 22, 0.1);
            color: #fdba74;
            border: 1px solid rgba(249, 115, 22, 0.2);
        }
        .badge-plus {
            background: rgba(245, 158, 11, 0.15);
            color: #fbbf24;
            border: 1px solid rgba(245, 158, 11, 0.3);
        }
        .info-box {
            background: rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(255, 255, 255, 0.03);
            border-radius: 16px;
            padding: 12px;
        }
        .info-label {
            color: #6b7280;
            font-size: 11px;
            margin-bottom: 4px;
        }
        .info-value {
            color: #ffffff;
            font-weight: 700;
            font-size: 13px;
        }
        .font-mono {
            font-family: 'Courier New', monospace;
        }
        button {
            transition: all 0.2s ease;
        }
        button:hover {
            transform: translateY(-1px);
            filter: brightness(1.1);
        }
        .bg-indigo-500 {
            background: #4f46e5;
        }
        .bg-indigo-500:hover {
            background: #6366f1;
        }
        .bg-gray-500 {
            background: #4b5563;
        }
        .bg-gray-500:hover {
            background: #6b7280;
        }
        .modal-content {
            background: rgba(18, 18, 18, 0.98);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.05);
        }
        .plus-border {
            border-right-color: #f59e0b;
        }
    </style>
</head>
<body class="min-h-screen">

    <div class="glass-header text-white shadow-xl">
        <div class="container mx-auto px-4 py-4 md:px-6 md:py-5">
            <div class="flex flex-wrap items-center justify-between gap-3">
                <div class="flex items-center gap-3 md:gap-4">
                    <div class="bg-white bg-opacity-5 p-2 md:p-3 rounded-xl md:rounded-2xl border border-white border-opacity-5">
                        <i class="fas fa-mobile-alt text-xl md:text-3xl text-indigo-400"></i>
                    </div>
                    <div>
                        <h1 class="text-lg md:text-3xl font-black text-white">التطبيقات المرتبطة</h1>
                        <p class="text-xs md:text-sm text-gray-400">عرض وإدارة التطبيقات المفعلة</p>
                    </div>
                </div>
                <div>
                    <a href="panel.php" class="bg-white bg-opacity-5 text-white px-3 py-2 md:px-6 md:py-3 rounded-lg md:rounded-xl hover:bg-opacity-10 transition-all font-bold text-sm md:text-base flex items-center gap-1 md:gap-2 border border-white border-opacity-5">
                        <i class="fas fa-arrow-right text-xs md:text-sm"></i>
                        <span>العودة</span>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="container mx-auto px-3 py-4 md:px-6 md:py-8">

        <div class="license-info-card p-4 md:p-6 mb-4 md:mb-6 border-r-4 <?php echo $license['is_plus'] ? 'border-amber-500' : 'border-indigo-500'; ?>">
            <div class="flex items-center gap-2 mb-4 md:mb-5">
                <div class="<?php echo $license['is_plus'] ? 'bg-amber-900 bg-opacity-20 border-amber-800' : 'bg-indigo-900 bg-opacity-20 border-indigo-800'; ?> p-1.5 md:p-2 rounded-lg border">
                    <i class="fas fa-info-circle <?php echo $license['is_plus'] ? 'text-amber-400' : 'text-indigo-400'; ?> text-sm md:text-base"></i>
                </div>
                <h2 class="text-base md:text-lg font-black text-white">معلومات الترخيص</h2>
                <?php if ($license['is_plus']): ?>
                <span class="badge-plus badge mr-2">
                    <i class="fas fa-crown text-xs"></i>
                    PLUS
                </span>
                <?php endif; ?>
            </div>
            
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3 md:gap-4">
                <div class="info-box">
                    <div class="info-label">مفتاح الترخيص</div>
                    <div class="info-value font-mono break-all"><?php echo htmlspecialchars($license['license_key']); ?></div>
                </div>
                <div class="info-box">
                    <div class="info-label">Package</div>
                    <div class="info-value <?php echo empty($license['package_name']) ? 'text-orange-400' : ''; ?>">
                        <?php echo empty($license['package_name']) ? 'أي Package' : htmlspecialchars($license['package_name']); ?>
                    </div>
                </div>
                <div class="info-box">
                    <div class="info-label">التوقيع</div>
                    <div class="info-value font-mono truncate <?php echo empty($license['signature']) ? 'text-orange-400' : ''; ?>">
                        <?php echo empty($license['signature']) ? 'أي توقيع' : htmlspecialchars(substr($license['signature'], 0, 20)) . '...'; ?>
                    </div>
                </div>
                <div class="info-box">
                    <div class="info-label">عدد التطبيقات</div>
                    <div class="info-value">
                        <span class="<?php echo (count($apps) >= $license['max_devices'] && $license['max_devices'] != 0) ? 'text-red-400' : 'text-green-400'; ?>">
                            <?php echo count($apps) . ' / ' . ($license['max_devices'] == 0 ? '∞' : $license['max_devices']); ?>
                        </span>
                    </div>
                </div>
                <div class="info-box">
                    <div class="info-label">الأيام المتبقية</div>
                    <div class="info-value <?php echo $daysLeft < 3 ? 'text-orange-400' : 'text-blue-400'; ?>">
                        <?php echo $daysLeft; ?> يوم
                    </div>
                </div>
                <div class="info-box">
                    <div class="info-label">نوع الترخيص</div>
                    <div class="info-value <?php echo $license['is_plus'] ? 'text-amber-400' : 'text-indigo-400'; ?>">
                        <i class="fas <?php echo $license['is_plus'] ? 'fa-crown' : 'fa-key'; ?> ml-1"></i>
                        <?php echo $license['is_plus'] ? 'PLUS (مميز)' : 'عادي'; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="apps-card p-4 md:p-6">
            <div class="flex items-center justify-between mb-4 md:mb-6">
                <div class="flex items-center gap-2">
                    <div class="bg-indigo-900 bg-opacity-20 p-1.5 md:p-2 rounded-lg border border-indigo-800">
                        <i class="fas fa-list text-indigo-400 text-sm md:text-base"></i>
                    </div>
                    <h2 class="text-base md:text-lg font-black text-white">قائمة التطبيقات المفعلة</h2>
                </div>
                <div class="bg-black bg-opacity-30 px-2 py-1 md:px-3 md:py-1.5 rounded-lg border border-white border-opacity-5">
                    <span class="text-xs md:text-sm font-bold text-gray-400">إجمالي: <?php echo count($apps); ?></span>
                </div>
            </div>

            <?php if (empty($apps)): ?>
            <div class="text-center py-8 md:py-12">
                <div class="bg-black bg-opacity-30 rounded-2xl p-8 md:p-12 border border-white border-opacity-5">
                    <i class="fas fa-mobile-alt text-4xl md:text-6xl text-gray-600 mb-3 md:mb-4"></i>
                    <p class="text-gray-400 text-sm md:text-base font-bold">لا توجد تطبيقات مفعلة لهذا الترخيص بعد</p>
                    <p class="text-xs text-gray-600 mt-2">عند تفعيل أي تطبيق سيظهر هنا</p>
                </div>
            </div>
            <?php else: ?>

            <div class="hidden md:block">
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>التطبيق</th>
                                <th>Package</th>
                                <th>التوقيع</th>
                                <th>الإصدار</th>
                                <th>التفاصيل</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($apps as $index => $app): ?>
                            <tr>
                                <td class="font-bold text-gray-400"><?php echo $index + 1; ?></td>
                                <td>
                                    <div class="font-bold text-white"><?php echo htmlspecialchars($app['app_name']); ?></div>
                                    <div class="text-xs text-gray-500">آخر ظهور: <?php echo date('Y-m-d H:i', strtotime($app['last_seen_at'])); ?></div>
                                </td>
                                <td class="font-mono text-gray-300 max-w-xs truncate" title="<?php echo htmlspecialchars($app['package_name']); ?>">
                                    <?php echo htmlspecialchars($app['package_name']); ?>
                                </td>
                                <td class="font-mono text-gray-300 max-w-xs truncate" title="<?php echo htmlspecialchars($app['signature']); ?>">
                                    <?php echo htmlspecialchars(substr($app['signature'], 0, 20)) . '...'; ?>
                                </td>
                                <td>
                                    <span class="badge badge-blue">
                                        <?php echo htmlspecialchars($app['version']); ?> (<?php echo $app['version_code']; ?>)
                                    </span>
                                </td>
                                <td>
                                    <button onclick="showAppDetails(<?php echo $index; ?>)" 
                                            class="bg-indigo-900 bg-opacity-20 text-indigo-200 px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-opacity-30 border border-indigo-800 flex items-center gap-1">
                                        <i class="fas fa-eye text-xs"></i>
                                        <span>المزيد</span>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="md:hidden space-y-3">
                <?php foreach ($apps as $index => $app): ?>
                <div class="mobile-card">
                    <div class="mobile-header flex justify-between items-center">
                        <div class="flex items-center gap-2">
                            <div class="bg-indigo-900 bg-opacity-20 w-6 h-6 rounded-lg flex items-center justify-center border border-indigo-800">
                                <span class="text-xs font-bold text-indigo-300"><?php echo $index + 1; ?></span>
                            </div>
                            <span class="font-bold text-white"><?php echo htmlspecialchars($app['app_name']); ?></span>
                        </div>
                        <span class="badge badge-blue">
                            v<?php echo htmlspecialchars($app['version']); ?>
                        </span>
                    </div>
                    <div class="mobile-content">
                        <div class="space-y-2 text-sm">
                            <div>
                                <span class="text-xs text-gray-500 block">Package:</span>
                                <span class="font-mono text-xs font-bold text-gray-300 break-all"><?php echo htmlspecialchars($app['package_name']); ?></span>
                            </div>
                            <div>
                                <span class="text-xs text-gray-500 block">التوقيع:</span>
                                <span class="font-mono text-xs text-gray-400 break-all"><?php echo htmlspecialchars($app['signature']); ?></span>
                            </div>
                            <div class="flex justify-between items-center pt-2">
                                <span class="text-xs text-gray-500">آخر ظهور: <?php echo date('Y-m-d H:i', strtotime($app['last_seen_at'])); ?></span>
                                <button onclick="showAppDetails(<?php echo $index; ?>)" 
                                        class="bg-indigo-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1 hover:bg-indigo-700">
                                    <i class="fas fa-eye"></i>
                                    <span>المزيد</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <div id="detailsModal" class="hidden fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-50 p-4 backdrop-blur-sm" onclick="closeModal(event)">
                <div class="modal-content rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto border border-white border-opacity-5" onclick="event.stopPropagation()">
                    <div class="sticky top-0 bg-gradient-to-l from-gray-900 to-black text-white p-4 rounded-t-2xl flex justify-between items-center border-b border-white border-opacity-5">
                        <h3 class="text-lg font-black flex items-center gap-2">
                            <i class="fas fa-info-circle text-indigo-400"></i>
                            تفاصيل التطبيق
                        </h3>
                        <button onclick="closeModal()" class="text-gray-400 hover:text-white">
                            <i class="fas fa-times text-xl"></i>
                        </button>
                    </div>
                    <div id="modalContent" class="p-6 space-y-4">
                    </div>
                    <div class="border-t border-white border-opacity-5 p-4 flex justify-end">
                        <button onclick="closeModal()" class="bg-gray-800 text-white px-6 py-2 rounded-xl hover:bg-gray-700 transition-all font-bold border border-gray-700">
                            إغلاق
                        </button>
                    </div>
                </div>
            </div>

            <?php endif; ?>
        </div>
    </div>

    <script>
        const apps = <?php echo json_encode($apps, JSON_UNESCAPED_UNICODE); ?>;

        function showAppDetails(index) {
            const app = apps[index];
            const modal = document.getElementById('detailsModal');
            const modalContent = document.getElementById('modalContent');
            
            const firstActivated = new Date(app.first_activated_at).toLocaleString('ar-EG');
            const lastSeen = new Date(app.last_seen_at).toLocaleString('ar-EG');
            
            modalContent.innerHTML = `
                <div class="bg-black bg-opacity-30 p-4 rounded-xl border-r-4 border-indigo-500 border border-white border-opacity-5">
                    <div class="flex items-center gap-3 mb-2">
                        <div class="bg-indigo-900 bg-opacity-20 p-2 rounded-lg border border-indigo-800">
                            <i class="fas fa-apple-alt text-indigo-400"></i>
                        </div>
                        <div>
                            <h4 class="font-black text-white text-lg">${app.app_name}</h4>
                            <p class="text-xs text-gray-400">${app.package_name}</p>
                        </div>
                    </div>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="bg-black bg-opacity-30 p-3 rounded-xl border border-white border-opacity-5">
                        <span class="text-xs text-gray-500 block mb-1">الإصدار</span>
                        <span class="font-bold text-white">${app.version} (${app.version_code})</span>
                    </div>
                    <div class="bg-black bg-opacity-30 p-3 rounded-xl border border-white border-opacity-5">
                        <span class="text-xs text-gray-500 block mb-1">معرف الجهاز</span>
                        <span class="font-mono text-xs font-bold text-gray-300 break-all">${app.device_identifier}</span>
                    </div>
                </div>

                <div class="bg-black bg-opacity-30 p-4 rounded-xl border border-white border-opacity-5">
                    <span class="text-xs text-gray-500 block mb-2">التوقيع (Signature)</span>
                    <div class="font-mono text-xs bg-black bg-opacity-50 p-3 rounded-lg border border-white border-opacity-5 break-all text-gray-300">${app.signature}</div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="bg-black bg-opacity-30 p-3 rounded-xl border border-white border-opacity-5">
                        <span class="text-xs text-gray-500 block mb-1">SHA1</span>
                        <span class="font-mono text-xs font-bold text-gray-300 break-all">${app.sha1}</span>
                    </div>
                    <div class="bg-black bg-opacity-30 p-3 rounded-xl border border-white border-opacity-5">
                        <span class="text-xs text-gray-500 block mb-1">SHA256</span>
                        <span class="font-mono text-xs font-bold text-gray-300 break-all">${app.sha256}</span>
                    </div>
                    <div class="bg-black bg-opacity-30 p-3 rounded-xl border border-white border-opacity-5">
                        <span class="text-xs text-gray-500 block mb-1">MD5</span>
                        <span class="font-mono text-xs font-bold text-gray-300 break-all">${app.md5}</span>
                    </div>
                    <div class="bg-black bg-opacity-30 p-3 rounded-xl border border-white border-opacity-5">
                        <span class="text-xs text-gray-500 block mb-1">كود الإصدار</span>
                        <span class="font-bold text-white">${app.version_code}</span>
                    </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="bg-black bg-opacity-30 p-3 rounded-xl border border-white border-opacity-5">
                        <span class="text-xs text-gray-500 block mb-1">تاريخ التفعيل</span>
                        <span class="font-bold text-white">${firstActivated}</span>
                    </div>
                    <div class="bg-black bg-opacity-30 p-3 rounded-xl border border-white border-opacity-5">
                        <span class="text-xs text-gray-500 block mb-1">آخر ظهور</span>
                        <span class="font-bold text-white">${lastSeen}</span>
                    </div>
                </div>
            `;
            
            modal.classList.remove('hidden');
        }

        function closeModal(event) {
            if (event && event.target === document.getElementById('detailsModal')) {
                document.getElementById('detailsModal').classList.add('hidden');
            } else if (!event) {
                document.getElementById('detailsModal').classList.add('hidden');
            }
        }

        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(() => {
                alert('✅ تم النسخ!');
            });
        }
    </script>

</body>
</html>