<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = "localhost";
$db   = "pivmzsod_aar";
$user = "pivmzsod_aar";
$pass = "xg7JP5z2qVDtUfQwyeF3";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("DB ERROR: " . $conn->connect_error);
}
?>