<?php
session_start();
require_once "config.php";

if (isset($_SESSION['admin'])) {
    header("Location: panel.php");
    exit;
}

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    $stmt = $conn->prepare("SELECT password FROM admins WHERE username=? LIMIT 1");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->bind_result($hashed_password);

    if ($stmt->fetch() && password_verify($password, $hashed_password)) {
        $_SESSION['admin'] = $username;
        header("Location: panel.php");
        exit;
    }

    $error = "خطأ في اسم المستخدم أو كلمة المرور";
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
    <title>تسجيل الدخول - نظام التراخيص</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800&display=swap');
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Tajawal', sans-serif;
            background: #0a0a0a;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }
        body::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: radial-gradient(circle at 20% 50%, rgba(79, 70, 229, 0.1) 0%, transparent 50%),
                        radial-gradient(circle at 80% 50%, rgba(99, 102, 241, 0.1) 0%, transparent 50%);
            pointer-events: none;
        }
        .glass-card {
            background: rgba(18, 18, 18, 0.95);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.03);
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.8);
        }
        .login-card {
            background: rgba(18, 18, 18, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 32px;
            border: 1px solid rgba(255, 255, 255, 0.03);
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.8);
            position: relative;
            overflow: hidden;
        }
        .login-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 1px;
            background: linear-gradient(90deg, transparent, rgba(99, 102, 241, 0.5), transparent);
        }
        @media (max-width: 640px) {
            .login-card {
                margin: 16px;
                padding: 24px !important;
            }
        }
        input {
            background: rgba(30, 30, 30, 0.8) !important;
            border: 1px solid rgba(255, 255, 255, 0.05) !important;
            color: #ffffff !important;
            border-radius: 16px !important;
            padding: 14px 16px !important;
            font-size: 14px !important;
            transition: all 0.2s ease;
        }
        input:focus {
            border-color: #6366f1 !important;
            outline: none;
            background: rgba(40, 40, 40, 0.9) !important;
            box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
        }
        input::placeholder {
            color: #6b7280 !important;
        }
        label {
            color: #9ca3af !important;
            font-size: 13px;
            margin-bottom: 8px;
            display: block;
        }
        button {
            transition: all 0.2s ease;
            background: linear-gradient(135deg, #4f46e5 0%, #6366f1 100%);
            border: none;
            position: relative;
            overflow: hidden;
        }
        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px -5px rgba(99, 102, 241, 0.4);
        }
        button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent);
            transition: left 0.5s ease;
        }
        button:hover::before {
            left: 100%;
        }
        .icon-box {
            background: rgba(99, 102, 241, 0.1);
            border: 1px solid rgba(99, 102, 241, 0.2);
        }
    </style>
</head>
<body class="p-4">

    <div class="login-card w-full max-w-md p-6 md:p-8">
        <!-- الشعار -->
        <div class="text-center mb-6 md:mb-8">
            <div class="icon-box w-16 h-16 md:w-20 md:h-20 rounded-2xl mx-auto mb-3 md:mb-4 flex items-center justify-center">
                <i class="fas fa-key text-2xl md:text-3xl text-indigo-400"></i>
            </div>
            <h1 class="text-xl md:text-2xl font-black text-white">نظام إدارة التراخيص</h1>
            <p class="text-xs md:text-sm text-gray-500 mt-2">قم بتسجيل الدخول للوصول إلى لوحة التحكم</p>
        </div>

        <!-- رسالة الخطأ -->
        <?php if ($error): ?>
        <div class="bg-red-900 bg-opacity-20 border-r-4 border-red-500 text-red-200 px-4 py-3 rounded-xl mb-4 md:mb-6 text-sm flex items-center gap-2 backdrop-blur-lg">
            <i class="fas fa-exclamation-circle text-red-400"></i>
            <span><?php echo $error; ?></span>
        </div>
        <?php endif; ?>

        <!-- نموذج تسجيل الدخول -->
        <form method="POST" class="space-y-5 md:space-y-6">
            <div>
                <label class="block">
                    <i class="fas fa-user ml-1 text-indigo-400"></i>
                    اسم المستخدم
                </label>
                <input type="text" name="username" required 
                    placeholder="أدخل اسم المستخدم"
                    class="w-full"
                    autocomplete="off">
            </div>
            
            <div>
                <label class="block">
                    <i class="fas fa-lock ml-1 text-indigo-400"></i>
                    كلمة المرور
                </label>
                <input type="password" name="password" required 
                    placeholder="أدخل كلمة المرور"
                    class="w-full">
            </div>
            
            <button type="submit" 
                class="w-full text-white font-bold py-3 px-4 rounded-xl text-sm md:text-base flex items-center justify-center gap-2 mt-4 relative overflow-hidden group">
                <i class="fas fa-sign-in-alt"></i>
                <span>تسجيل الدخول</span>
            </button>
        </form>

        <!-- توقيع -->
        <div class="text-center mt-8 md:mt-10">
            <p class="text-xs text-gray-600">
                جميع الحقوق محفوظة © 2024
            </p>
        </div>
    </div>

</body>
</html>